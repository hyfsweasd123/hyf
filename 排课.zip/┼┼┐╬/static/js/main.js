/**
 * 中学排课系统通用 JavaScript 功能
 */

// 当文档加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 初始化工具提示
    initializeTooltips();
    
    // 设置表单验证
    setupFormValidation();
    
    // 设置表格排序
    setupTableSorting();
    
    // 设置确认删除对话框
    setupDeleteConfirmation();
    
    // 设置警告信息自动消失
    setupAlertDismissal();
});

/**
 * 初始化 Bootstrap 工具提示
 */
function initializeTooltips() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * 设置表单验证
 */
function setupFormValidation() {
    // 获取所有需要验证的表单
    var forms = document.querySelectorAll('.needs-validation');
    
    // 循环处理每个表单
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
}

/**
 * 设置表格排序功能
 */
function setupTableSorting() {
    // 获取所有可排序的表格
    var tables = document.querySelectorAll('.sortable');
    
    // 为每个表格添加排序功能
    tables.forEach(function(table) {
        var headers = table.querySelectorAll('th.sortable');
        
        headers.forEach(function(header) {
            header.addEventListener('click', function() {
                var column = header.cellIndex;
                var rows = Array.from(table.querySelectorAll('tbody tr'));
                var isAsc = header.classList.contains('asc');
                
                // 移除所有表头的排序类
                headers.forEach(function(h) {
                    h.classList.remove('asc', 'desc');
                });
                
                // 添加新的排序类
                header.classList.add(isAsc ? 'desc' : 'asc');
                
                // 排序行
                rows.sort(function(a, b) {
                    var textA = a.cells[column].textContent.trim();
                    var textB = b.cells[column].textContent.trim();
                    
                    // 尝试将文本转换为数字进行比较
                    var numA = parseFloat(textA);
                    var numB = parseFloat(textB);
                    
                    if (!isNaN(numA) && !isNaN(numB)) {
                        return isAsc ? numB - numA : numA - numB;
                    } else {
                        return isAsc ? textB.localeCompare(textA) : textA.localeCompare(textB);
                    }
                });
                
                // 重新添加排序后的行
                var tbody = table.querySelector('tbody');
                rows.forEach(function(row) {
                    tbody.appendChild(row);
                });
            });
        });
    });
}

/**
 * 设置删除确认对话框
 */
function setupDeleteConfirmation() {
    // 获取所有删除按钮
    var deleteButtons = document.querySelectorAll('.btn-delete');
    
    // 为每个删除按钮添加点击事件
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(event) {
            if (!confirm('确定要删除此项吗？此操作无法撤销!')) {
                event.preventDefault();
            }
        });
    });
}

/**
 * 设置警告信息自动消失
 */
function setupAlertDismissal() {
    // 获取所有警告框
    var alerts = document.querySelectorAll('.alert-dismissible:not(.no-auto-dismiss)');
    
    // 设置自动消失
    alerts.forEach(function(alert) {
        setTimeout(function() {
            var closeButton = alert.querySelector('.btn-close');
            if (closeButton) {
                closeButton.click();
            }
        }, 5000); // 5秒后自动关闭
    });
}

/**
 * 格式化日期显示
 * @param {Date|string} date - 日期对象或日期字符串
 * @returns {string} 格式化后的日期字符串
 */
function formatDate(date) {
    date = date instanceof Date ? date : new Date(date);
    var year = date.getFullYear();
    var month = ('0' + (date.getMonth() + 1)).slice(-2);
    var day = ('0' + date.getDate()).slice(-2);
    
    return year + '-' + month + '-' + day;
}

/**
 * 格式化时间显示
 * @param {Date|string} date - 日期对象或日期字符串
 * @returns {string} 格式化后的时间字符串
 */
function formatTime(date) {
    date = date instanceof Date ? date : new Date(date);
    var hours = ('0' + date.getHours()).slice(-2);
    var minutes = ('0' + date.getMinutes()).slice(-2);
    
    return hours + ':' + minutes;
}

/**
 * 格式化日期时间显示
 * @param {Date|string} date - 日期对象或日期字符串
 * @returns {string} 格式化后的日期时间字符串
 */
function formatDateTime(date) {
    return formatDate(date) + ' ' + formatTime(date);
}

/**
 * 将表单数据转换为 JSON 对象
 * @param {HTMLFormElement} form - 表单元素
 * @returns {Object} 包含表单数据的 JSON 对象
 */
function formToJSON(form) {
    var formData = new FormData(form);
    var json = {};
    
    formData.forEach(function(value, key) {
        if (json[key]) {
            if (!Array.isArray(json[key])) {
                json[key] = [json[key]];
            }
            json[key].push(value);
        } else {
            json[key] = value;
        }
    });
    
    return json;
}

/**
 * 发送 AJAX 请求
 * @param {string} url - 请求 URL
 * @param {string} method - 请求方法 (GET, POST, PUT, DELETE)
 * @param {Object} data - 要发送的数据
 * @param {Function} successCallback - 成功回调函数
 * @param {Function} errorCallback - 错误回调函数
 */
function sendAjaxRequest(url, method, data, successCallback, errorCallback) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    
    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 300) {
            try {
                var response = JSON.parse(xhr.responseText);
                if (successCallback) {
                    successCallback(response);
                }
            } catch (e) {
                if (successCallback) {
                    successCallback(xhr.responseText);
                }
            }
        } else {
            if (errorCallback) {
                errorCallback(xhr.status, xhr.statusText);
            }
        }
    };
    
    xhr.onerror = function() {
        if (errorCallback) {
            errorCallback(xhr.status, xhr.statusText);
        }
    };
    
    xhr.send(JSON.stringify(data));
} 