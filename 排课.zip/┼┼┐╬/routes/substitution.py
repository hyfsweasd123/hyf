from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from database import db
from models import Teacher, Subject, Class, SubstitutionArrangement, TemporarySubstitution, Schedule
from datetime import datetime, timedelta
import calendar

# 创建蓝图
substitution_bp = Blueprint('substitution', __name__, url_prefix='/substitution')

@substitution_bp.route('/')
@substitution_bp.route('/index')
@login_required
def index():
    """代课安排首页"""
    # 获取所有正在进行的代课安排
    active_arrangements = SubstitutionArrangement.query.filter_by(status='active').all()
    # 获取最近的临时代课记录(未来7天)
    today = datetime.now().date()
    next_week = today + timedelta(days=7)
    recent_temp_substitutions = TemporarySubstitution.query.filter(
        TemporarySubstitution.date >= today,
        TemporarySubstitution.date <= next_week
    ).order_by(TemporarySubstitution.date).all()
    
    return render_template('substitution/index.html', 
                        active_arrangements=active_arrangements,
                        recent_temp_substitutions=recent_temp_substitutions)

# 常规代课安排路由
@substitution_bp.route('/arrangements')
@login_required
def arrangements():
    """查看所有代课安排"""
    arrangements = SubstitutionArrangement.query.order_by(SubstitutionArrangement.start_date.desc()).all()
    return render_template('substitution/arrangements.html', arrangements=arrangements)

@substitution_bp.route('/arrangements/new', methods=['GET', 'POST'])
@login_required
def new_arrangement():
    """创建新的代课安排"""
    if request.method == 'POST':
        original_teacher_id = request.form.get('original_teacher_id', type=int)
        substitute_teacher_id = request.form.get('substitute_teacher_id', type=int)
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')
        reason = request.form.get('reason')
        
        # 验证必填项
        if not all([original_teacher_id, substitute_teacher_id, class_id, subject_id, start_date, end_date]):
            flash('请填写所有必填项', 'danger')
            return redirect(url_for('substitution.new_arrangement'))
        
        # 转换日期
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        except ValueError:
            flash('日期格式不正确', 'danger')
            return redirect(url_for('substitution.new_arrangement'))
        
        # 检查日期有效性
        if start_date > end_date:
            flash('开始日期不能晚于结束日期', 'danger')
            return redirect(url_for('substitution.new_arrangement'))
        
        # 检查教师是否相同
        if original_teacher_id == substitute_teacher_id:
            flash('原任教师和代课教师不能是同一人', 'danger')
            return redirect(url_for('substitution.new_arrangement'))
        
        # 创建代课安排
        new_arrangement = SubstitutionArrangement(
            original_teacher_id=original_teacher_id,
            substitute_teacher_id=substitute_teacher_id,
            class_id=class_id,
            subject_id=subject_id,
            start_date=start_date,
            end_date=end_date,
            reason=reason,
            status='active'
        )
        
        try:
            db.session.add(new_arrangement)
            db.session.commit()
            flash('代课安排创建成功', 'success')
            return redirect(url_for('substitution.arrangements'))
        except Exception as e:
            db.session.rollback()
            flash(f'创建失败: {str(e)}', 'danger')
            return redirect(url_for('substitution.new_arrangement'))
    
    # GET请求，显示表单
    teachers = Teacher.query.order_by(Teacher.name).all()
    classes = Class.query.order_by(Class.grade, Class.name).all()
    subjects = Subject.query.order_by(Subject.name).all()
    
    return render_template('substitution/new_arrangement.html', 
                        teachers=teachers,
                        classes=classes,
                        subjects=subjects)

@substitution_bp.route('/arrangements/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_arrangement(id):
    """编辑代课安排"""
    arrangement = SubstitutionArrangement.query.get_or_404(id)
    
    if request.method == 'POST':
        original_teacher_id = request.form.get('original_teacher_id', type=int)
        substitute_teacher_id = request.form.get('substitute_teacher_id', type=int)
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')
        reason = request.form.get('reason')
        status = request.form.get('status')
        
        # 验证必填项
        if not all([original_teacher_id, substitute_teacher_id, class_id, subject_id, start_date, end_date, status]):
            flash('请填写所有必填项', 'danger')
            return redirect(url_for('substitution.edit_arrangement', id=id))
        
        # 转换日期
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        except ValueError:
            flash('日期格式不正确', 'danger')
            return redirect(url_for('substitution.edit_arrangement', id=id))
        
        # 检查日期有效性
        if start_date > end_date:
            flash('开始日期不能晚于结束日期', 'danger')
            return redirect(url_for('substitution.edit_arrangement', id=id))
        
        # 检查教师是否相同
        if original_teacher_id == substitute_teacher_id:
            flash('原任教师和代课教师不能是同一人', 'danger')
            return redirect(url_for('substitution.edit_arrangement', id=id))
        
        # 更新代课安排
        arrangement.original_teacher_id = original_teacher_id
        arrangement.substitute_teacher_id = substitute_teacher_id
        arrangement.class_id = class_id
        arrangement.subject_id = subject_id
        arrangement.start_date = start_date
        arrangement.end_date = end_date
        arrangement.reason = reason
        arrangement.status = status
        
        try:
            db.session.commit()
            flash('代课安排更新成功', 'success')
            return redirect(url_for('substitution.arrangements'))
        except Exception as e:
            db.session.rollback()
            flash(f'更新失败: {str(e)}', 'danger')
            return redirect(url_for('substitution.edit_arrangement', id=id))
    
    # GET请求，显示表单
    teachers = Teacher.query.order_by(Teacher.name).all()
    classes = Class.query.order_by(Class.grade, Class.name).all()
    subjects = Subject.query.order_by(Subject.name).all()
    
    return render_template('substitution/edit_arrangement.html', 
                        arrangement=arrangement,
                        teachers=teachers,
                        classes=classes,
                        subjects=subjects)

@substitution_bp.route('/arrangements/<int:id>/delete', methods=['POST'])
@login_required
def delete_arrangement(id):
    """删除代课安排"""
    arrangement = SubstitutionArrangement.query.get_or_404(id)
    
    try:
        db.session.delete(arrangement)
        db.session.commit()
        flash('代课安排已删除', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'删除失败: {str(e)}', 'danger')
    
    return redirect(url_for('substitution.arrangements'))

@substitution_bp.route('/arrangements/<int:id>/complete', methods=['POST'])
@login_required
def complete_arrangement(id):
    """完成代课安排"""
    arrangement = SubstitutionArrangement.query.get_or_404(id)
    
    if arrangement.status == 'completed':
        flash('该代课安排已经标记为完成', 'warning')
        return redirect(url_for('substitution.arrangements'))
    
    arrangement.status = 'completed'
    
    try:
        db.session.commit()
        flash('代课安排已标记为完成', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'操作失败: {str(e)}', 'danger')
    
    return redirect(url_for('substitution.arrangements'))

# 临时代课路由
@substitution_bp.route('/temporary')
@login_required
def temporary():
    """查看临时代课记录"""
    # 获取状态筛选参数
    status = request.args.get('status', 'all')
    
    # 构建查询
    query = TemporarySubstitution.query
    
    # 根据状态筛选
    if status != 'all':
        query = query.filter_by(status=status)
    
    # 排序：先按日期降序，再按课时升序
    substitutions = query.order_by(TemporarySubstitution.date.desc(), TemporarySubstitution.period).all()
    
    return render_template('substitution/temporary.html', 
                        substitutions=substitutions,
                        current_status=status)

@substitution_bp.route('/temporary/new', methods=['GET', 'POST'])
@login_required
def new_temporary():
    """创建新的临时代课记录"""
    if request.method == 'POST':
        original_teacher_id = request.form.get('original_teacher_id', type=int)
        substitute_teacher_id = request.form.get('substitute_teacher_id', type=int)
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        date = request.form.get('date')
        day_of_week = request.form.get('day_of_week', type=int)
        period = request.form.get('period', type=int)
        reason = request.form.get('reason')
        
        # 验证必填项
        if not all([original_teacher_id, substitute_teacher_id, class_id, subject_id, date, day_of_week, period]):
            flash('请填写所有必填项', 'danger')
            return redirect(url_for('substitution.new_temporary'))
        
        # 转换日期
        try:
            date_obj = datetime.strptime(date, '%Y-%m-%d').date()
            # 验证星期几是否与日期匹配
            weekday = date_obj.weekday() + 1  # datetime.weekday() 0-6 对应周一到周日，而我们使用 1-7
            if weekday != day_of_week:
                flash(f'选择的日期与星期几不匹配。{date}是星期{weekday}，而非星期{day_of_week}', 'danger')
                return redirect(url_for('substitution.new_temporary'))
        except ValueError:
            flash('日期格式不正确', 'danger')
            return redirect(url_for('substitution.new_temporary'))
        
        # 检查教师是否相同
        if original_teacher_id == substitute_teacher_id:
            flash('原任教师和代课教师不能是同一人', 'danger')
            return redirect(url_for('substitution.new_temporary'))
        
        # 创建临时代课记录
        new_substitution = TemporarySubstitution(
            original_teacher_id=original_teacher_id,
            substitute_teacher_id=substitute_teacher_id,
            class_id=class_id,
            subject_id=subject_id,
            date=date_obj,
            day_of_week=day_of_week,
            period=period,
            reason=reason,
            status='pending'
        )
        
        try:
            db.session.add(new_substitution)
            db.session.commit()
            flash('临时代课记录创建成功', 'success')
            return redirect(url_for('substitution.temporary'))
        except Exception as e:
            db.session.rollback()
            flash(f'创建失败: {str(e)}', 'danger')
            return redirect(url_for('substitution.new_temporary'))
    
    # GET请求，显示表单
    teachers = Teacher.query.order_by(Teacher.name).all()
    classes = Class.query.order_by(Class.grade, Class.name).all()
    subjects = Subject.query.order_by(Subject.name).all()
    
    # 获取当前日期并作为默认值
    today = datetime.now().date()
    current_day_of_week = today.weekday() + 1  # 1-7 表示周一到周日
    
    return render_template('substitution/new_temporary.html', 
                        teachers=teachers,
                        classes=classes,
                        subjects=subjects,
                        today=today.strftime('%Y-%m-%d'),
                        current_day_of_week=current_day_of_week)

@substitution_bp.route('/temporary/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_temporary(id):
    """编辑临时代课记录"""
    substitution = TemporarySubstitution.query.get_or_404(id)
    
    # 检查状态，已完成的临时代课不能编辑
    if substitution.status == 'completed':
        flash('已完成的临时代课不能编辑', 'warning')
        return redirect(url_for('substitution.temporary'))
    
    if request.method == 'POST':
        original_teacher_id = request.form.get('original_teacher_id', type=int)
        substitute_teacher_id = request.form.get('substitute_teacher_id', type=int)
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        date = request.form.get('date')
        day_of_week = request.form.get('day_of_week', type=int)
        period = request.form.get('period', type=int)
        reason = request.form.get('reason')
        status = request.form.get('status')
        
        # 验证必填项
        if not all([original_teacher_id, substitute_teacher_id, class_id, subject_id, date, day_of_week, period, status]):
            flash('请填写所有必填项', 'danger')
            return redirect(url_for('substitution.edit_temporary', id=id))
        
        # 转换日期
        try:
            date_obj = datetime.strptime(date, '%Y-%m-%d').date()
            # 验证星期几是否与日期匹配
            weekday = date_obj.weekday() + 1  # datetime.weekday() 0-6 对应周一到周日，而我们使用 1-7
            if weekday != day_of_week:
                flash(f'选择的日期与星期几不匹配。{date}是星期{weekday}，而非星期{day_of_week}', 'danger')
                return redirect(url_for('substitution.edit_temporary', id=id))
        except ValueError:
            flash('日期格式不正确', 'danger')
            return redirect(url_for('substitution.edit_temporary', id=id))
        
        # 检查教师是否相同
        if original_teacher_id == substitute_teacher_id:
            flash('原任教师和代课教师不能是同一人', 'danger')
            return redirect(url_for('substitution.edit_temporary', id=id))
        
        # 更新临时代课记录
        substitution.original_teacher_id = original_teacher_id
        substitution.substitute_teacher_id = substitute_teacher_id
        substitution.class_id = class_id
        substitution.subject_id = subject_id
        substitution.date = date_obj
        substitution.day_of_week = day_of_week
        substitution.period = period
        substitution.reason = reason
        substitution.status = status
        
        try:
            db.session.commit()
            flash('临时代课记录更新成功', 'success')
            return redirect(url_for('substitution.temporary'))
        except Exception as e:
            db.session.rollback()
            flash(f'更新失败: {str(e)}', 'danger')
            return redirect(url_for('substitution.edit_temporary', id=id))
    
    # GET请求，显示表单
    teachers = Teacher.query.order_by(Teacher.name).all()
    classes = Class.query.order_by(Class.grade, Class.name).all()
    subjects = Subject.query.order_by(Subject.name).all()
    
    return render_template('substitution/edit_temporary.html', 
                        substitution=substitution,
                        teachers=teachers,
                        classes=classes,
                        subjects=subjects)

@substitution_bp.route('/temporary/<int:id>/delete', methods=['POST'])
@login_required
def delete_temporary(id):
    """删除临时代课记录"""
    substitution = TemporarySubstitution.query.get_or_404(id)
    
    # 检查状态，已完成的临时代课不能删除
    if substitution.status == 'completed':
        flash('已完成的临时代课不能删除', 'warning')
        return redirect(url_for('substitution.temporary'))
    
    try:
        db.session.delete(substitution)
        db.session.commit()
        flash('临时代课记录已删除', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'删除失败: {str(e)}', 'danger')
    
    return redirect(url_for('substitution.temporary'))

@substitution_bp.route('/temporary/<int:id>/approve', methods=['POST'])
@login_required
def approve_temporary(id):
    """审批临时代课记录"""
    # 检查当前用户是否有权限审批
    if current_user.role != 'admin':
        flash('您没有权限执行此操作', 'danger')
        return redirect(url_for('substitution.temporary'))
        
    substitution = TemporarySubstitution.query.get_or_404(id)
    
    # 检查状态，只有待审批的临时代课可以批准
    if substitution.status != 'pending':
        flash('只有待审批的临时代课可以批准', 'warning')
        return redirect(url_for('substitution.temporary'))
    
    substitution.status = 'approved'
    
    try:
        db.session.commit()
        flash('临时代课已批准', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'操作失败: {str(e)}', 'danger')
    
    return redirect(url_for('substitution.temporary'))

@substitution_bp.route('/temporary/<int:id>/reject', methods=['POST'])
@login_required
def reject_temporary(id):
    """拒绝临时代课记录"""
    # 检查当前用户是否有权限
    if current_user.role != 'admin':
        flash('您没有权限执行此操作', 'danger')
        return redirect(url_for('substitution.temporary'))
        
    substitution = TemporarySubstitution.query.get_or_404(id)
    
    # 检查状态，只有待审批的临时代课可以拒绝
    if substitution.status != 'pending':
        flash('只有待审批的临时代课可以拒绝', 'warning')
        return redirect(url_for('substitution.temporary'))
    
    substitution.status = 'rejected'
    
    try:
        db.session.commit()
        flash('临时代课已拒绝', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'操作失败: {str(e)}', 'danger')
    
    return redirect(url_for('substitution.temporary'))

@substitution_bp.route('/temporary/<int:id>/complete', methods=['POST'])
@login_required
def complete_temporary(id):
    """完成临时代课记录"""
    substitution = TemporarySubstitution.query.get_or_404(id)
    
    # 检查状态，只有已批准的临时代课可以标记为完成
    if substitution.status != 'approved':
        flash('只有已批准的临时代课可以标记为完成', 'warning')
        return redirect(url_for('substitution.temporary'))
    
    substitution.status = 'completed'
    
    try:
        db.session.commit()
        flash('临时代课已标记为完成', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'操作失败: {str(e)}', 'danger')
    
    return redirect(url_for('substitution.temporary'))

# 辅助函数：获取指定班级、日期和时段的课程
@substitution_bp.route('/get_class_schedule', methods=['POST'])
@login_required
def get_class_schedule():
    """获取指定班级、日期和时段的课程信息"""
    if request.is_json:
        data = request.get_json()
        class_id = data.get('class_id')
        day_of_week = data.get('day_of_week')
        period = data.get('period')
        
        if not all([class_id, day_of_week, period]):
            return jsonify({'success': False, 'message': '参数不完整'})
        
        # 查询课表
        schedule = Schedule.query.filter_by(
            class_id=class_id,
            day_of_week=day_of_week,
            period=period
        ).first()
        
        if schedule:
            return jsonify({
                'success': True,
                'schedule': {
                    'subject_id': schedule.subject_id,
                    'subject_name': schedule.subject.name if schedule.subject else None,
                    'teacher_id': schedule.teacher_id,
                    'teacher_name': schedule.teacher.name if schedule.teacher else None
                }
            })
        else:
            return jsonify({'success': False, 'message': '未找到课程安排'})
    
    return jsonify({'success': False, 'message': '无效的请求格式'})

# 日历视图
@substitution_bp.route('/calendar')
@login_required
def calendar_view():
    """代课日历视图"""
    year = request.args.get('year', type=int, default=datetime.now().year)
    month = request.args.get('month', type=int, default=datetime.now().month)
    
    # 获取当月第一天和最后一天
    first_day = datetime(year, month, 1).date()
    if month == 12:
        last_day = datetime(year + 1, 1, 1).date() - timedelta(days=1)
    else:
        last_day = datetime(year, month + 1, 1).date() - timedelta(days=1)
    
    # 获取当月所有临时代课记录
    temp_substitutions = TemporarySubstitution.query.filter(
        TemporarySubstitution.date >= first_day,
        TemporarySubstitution.date <= last_day
    ).all()
    
    # 获取当月所有长期代课记录
    arrangements = SubstitutionArrangement.query.filter(
        ((SubstitutionArrangement.start_date <= last_day) & (SubstitutionArrangement.end_date >= first_day))
    ).all()
    
    # 构建日历数据
    cal = calendar.monthcalendar(year, month)
    
    # 准备按日期组织的代课信息
    substitution_data = {}
    
    # 添加临时代课数据
    for sub in temp_substitutions:
        day = sub.date.day
        if day not in substitution_data:
            substitution_data[day] = {'temporary': [], 'arrangements': []}
        substitution_data[day]['temporary'].append(sub)
    
    # 添加长期代课数据
    for arr in arrangements:
        # 计算该安排在当月的哪些天有效
        start_day = max(arr.start_date.day if arr.start_date.month == month and arr.start_date.year == year else 1, 1)
        end_day = min(arr.end_date.day if arr.end_date.month == month and arr.end_date.year == year else last_day.day, last_day.day)
        
        for day in range(start_day, end_day + 1):
            if day not in substitution_data:
                substitution_data[day] = {'temporary': [], 'arrangements': []}
            substitution_data[day]['arrangements'].append(arr)
    
    # 获取前一个月和后一个月的链接
    prev_month = month - 1 if month > 1 else 12
    prev_year = year if month > 1 else year - 1
    
    next_month = month + 1 if month < 12 else 1
    next_year = year if month < 12 else year + 1
    
    return render_template('substitution/calendar.html',
                        year=year,
                        month=month,
                        calendar=cal,
                        substitution_data=substitution_data,
                        prev_month=prev_month,
                        prev_year=prev_year,
                        next_month=next_month,
                        next_year=next_year,
                        month_name=calendar.month_name[month],
                        now=datetime.now()) 