from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file, session
from flask_login import login_required, current_user
from database import db
from models import Schedule, TeachingPlan, Teacher, Subject, Class, ClassCombination, ScheduleSetting, SubjectBlock, CommonCourse, PrintSetting, SelfStudySchedule, SelfStudyPlan
import random
import io
import csv
import xlsxwriter
from itertools import product
from collections import defaultdict
import os
import zipfile
from datetime import datetime
import json

schedule_bp = Blueprint('schedule', __name__)

@schedule_bp.route('/schedule/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('dashboard'))
    
    # 获取或创建排课设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
        db.session.add(setting)
        db.session.commit()
    
    if request.method == 'POST':
        periods_per_day = request.form.get('periods_per_day', type=int)
        days_per_week = request.form.get('days_per_week', type=int)
        morning_periods = request.form.get('morning_periods', type=int)
        afternoon_periods = request.form.get('afternoon_periods', type=int)
        major_subjects_morning = 'major_subjects_morning' in request.form
        
        # 验证
        if periods_per_day != morning_periods + afternoon_periods:
            flash('每天课时数必须等于上午课时数加下午课时数!', 'danger')
            return render_template('schedule/settings.html', setting=setting)
        
        setting.periods_per_day = periods_per_day
        setting.days_per_week = days_per_week
        setting.morning_periods = morning_periods
        setting.afternoon_periods = afternoon_periods
        setting.major_subjects_morning = major_subjects_morning
        
        db.session.commit()
        
        flash('排课设置保存成功!', 'success')
        return redirect(url_for('schedule.settings'))
    
    return render_template('schedule/settings.html', setting=setting)

@schedule_bp.route('/schedule/view')
@login_required
def view():
    classes = Class.query.order_by(Class.grade).all()
    teachers = Teacher.query.all()
    
    selected_class_id = request.args.get('class_id', type=int)
    selected_teacher_id = request.args.get('teacher_id', type=int)
    
    # 获取排课设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
        db.session.add(setting)
        db.session.commit()
    
    view_type = request.args.get('view_type', 'class')
    
    if view_type == 'class' and selected_class_id:
        # 获取班级课表
        schedule_data = get_class_schedule(selected_class_id, setting)
        return render_template('schedule/view.html', 
                              classes=classes, 
                              teachers=teachers, 
                              setting=setting, 
                              view_type=view_type, 
                              selected_class_id=selected_class_id,
                              schedule_data=schedule_data)
    
    elif view_type == 'teacher' and selected_teacher_id:
        # 获取教师课表
        schedule_data = get_teacher_schedule(selected_teacher_id, setting)
        return render_template('schedule/view.html', 
                              classes=classes, 
                              teachers=teachers, 
                              setting=setting, 
                              view_type=view_type, 
                              selected_teacher_id=selected_teacher_id,
                              schedule_data=schedule_data)
    
    # 默认返回所有班级列表和教师列表
    return render_template('schedule/view.html', 
                          classes=classes, 
                          teachers=teachers, 
                          setting=setting,
                          view_type=view_type)

@schedule_bp.route('/schedule/auto_generate', methods=['GET', 'POST'])
@login_required
def auto_generate():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('dashboard'))
    
    # 获取所有班级用于前端选择
    classes = Class.query.order_by(Class.grade, Class.name).all()
    
    # 提取唯一的年级列表并排序
    grades = sorted(set(class_obj.grade for class_obj in classes))
    
    if request.method == 'POST':
        # 获取排课范围
        scope = request.form.get('scope', 'all')
        
        # 获取用户选择的约束条件
        selected_constraints = request.form.getlist('constraints')
        
        # 获取排课设置
        setting = ScheduleSetting.query.first()
        if not setting:
            setting = ScheduleSetting()
            db.session.add(setting)
            db.session.commit()
        
        # 根据不同排课范围确定要清除和排课的班级
        target_classes = []
        
        if scope == 'all':
            # 为所有班级排课
            target_classes = Class.query.all()
            # 清除所有课表
            Schedule.query.delete()
            flash('已清除所有班级的课表数据', 'info')
            
        elif scope == 'grade':
            # 按年级排课
            grade_id = request.form.get('grade_id', type=int)
            if not grade_id:
                flash('请选择一个有效的年级!', 'danger')
                return render_template('schedule/auto_generate.html', classes=classes, grades=grades)
                
            target_classes = Class.query.filter_by(grade=grade_id).all()
            if not target_classes:
                flash(f'未找到{grade_id}年级的班级!', 'danger')
                return render_template('schedule/auto_generate.html', classes=classes, grades=grades)
                
            # 仅清除该年级班级的课表
            class_ids = [cls.id for cls in target_classes]
            deleted_count = Schedule.query.filter(Schedule.class_id.in_(class_ids)).delete(synchronize_session=False)
            flash(f'已清除{grade_id}年级班级的课表数据，共{deleted_count}条记录', 'info')
            
        elif scope == 'class':
            # 按班级排课
            class_id = request.form.get('class_id', type=int)
            if not class_id:
                flash('请选择一个有效的班级!', 'danger')
                return render_template('schedule/auto_generate.html', classes=classes, grades=grades)
                
            class_obj = Class.query.get(class_id)
            if not class_obj:
                flash('未找到指定的班级!', 'danger')
                return render_template('schedule/auto_generate.html', classes=classes, grades=grades)
                
            target_classes = [class_obj]
            
            # 仅清除该班级的课表
            deleted_count = Schedule.query.filter_by(class_id=class_id).delete()
            flash(f'已清除{class_obj.name}班级的课表数据，共{deleted_count}条记录', 'info')
        
        # 获取目标班级的授课计划
        all_plans = []
        for class_obj in target_classes:
            class_plans = TeachingPlan.query.filter_by(class_id=class_obj.id).all()
            all_plans.extend(class_plans)
        
        if not all_plans:
            flash('未找到任何授课计划，无法进行排课!', 'danger')
            return render_template('schedule/auto_generate.html', classes=classes, grades=grades)
        
        # 进行自动排课
        success, message = auto_schedule(all_plans, setting, selected_constraints)
        
        if success:
            if scope == 'all':
                flash('为所有班级自动排课成功!', 'success')
            elif scope == 'grade':
                flash(f'为{grade_id}年级自动排课成功!', 'success')
            else:
                flash(f'为{class_obj.name}自动排课成功!', 'success')
        else:
            flash(f'自动排课失败: {message}', 'danger')
        
        return redirect(url_for('schedule.view'))
    
    return render_template('schedule/auto_generate.html', classes=classes, grades=grades)

@schedule_bp.route('/schedule/clear_all', methods=['POST'])
@login_required
def clear_all_schedules():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('schedule.auto_generate'))
    
    # 清除所有课表数据
    try:
        count = Schedule.query.count()
        Schedule.query.delete()
        db.session.commit()
        flash(f'成功删除所有课表数据，共{count}条记录!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'删除课表数据失败: {str(e)}', 'danger')
    
    return redirect(url_for('schedule.auto_generate'))

@schedule_bp.route('/schedule/manual', methods=['GET', 'POST'])
@login_required
def manual():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('dashboard'))
    
    # 添加测试班级功能
    add_test = request.args.get('add_test', type=int)
    if add_test == 1:
        # 检查是否已有班级数据
        existing_classes = Class.query.all()
        if len(existing_classes) == 0:
            # 创建测试班级数据
            test_classes = [
                # 初中班级
                {"name": "初一(1)班", "grade": 7},
                {"name": "初一(2)班", "grade": 7},
                {"name": "初二(1)班", "grade": 8},
                {"name": "初二(2)班", "grade": 8},
                {"name": "初三(1)班", "grade": 9},
                {"name": "初三(2)班", "grade": 9},
                
                # 高中班级
                {"name": "高一(1)班", "grade": 10},
                {"name": "高一(2)班", "grade": 10},
                {"name": "高二(1)班", "grade": 11},
                {"name": "高二(2)班", "grade": 11},
                {"name": "高三(1)班", "grade": 12},
                {"name": "高三(2)班", "grade": 12},
            ]
            
            # 添加班级数据
            for class_data in test_classes:
                class_obj = Class(
                    name=class_data["name"],
                    grade=class_data["grade"]
                )
                db.session.add(class_obj)
            
            # 提交到数据库
            db.session.commit()
            flash(f'成功添加 {len(test_classes)} 个测试班级', 'success')
        else:
            flash(f'已存在 {len(existing_classes)} 个班级，不再添加测试数据', 'info')
    
    # 获取所有班级并按年级和名称排序
    classes = Class.query.order_by(Class.grade, Class.name).all()
    
    # 调试输出，查看班级数据
    print(f"DEBUG: 找到 {len(classes)} 个班级:")
    for cls in classes:
        print(f"DEBUG: - {cls.name} (年级: {cls.grade})")
    
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
        # flash('未找到排课设置，将使用默认设置。请前往设置页面进行配置。', 'warning')

    period_display_names = []
    if setting:
        num_map = ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二"]
        for p in range(1, setting.periods_per_day + 1):
            if p <= setting.morning_periods:
                num_str = num_map[p - 1] if 0 < p <= len(num_map) else str(p)
                period_display_names.append(f"上午第{num_str}节")
            else:
                afternoon_p = p - setting.morning_periods
                num_str_afternoon = num_map[afternoon_p - 1] if 0 < afternoon_p <= len(num_map) else str(afternoon_p)
                period_display_names.append(f"下午第{num_str_afternoon}节")
    
    selected_class_id = request.args.get('class_id', type=int)
    selected_class = None
    schedule_data = None
    plans = []
    plans_json = []

    if selected_class_id:
        selected_class = Class.query.get_or_404(selected_class_id)
        schedule_data = get_class_schedule(selected_class_id, setting)
        plans = TeachingPlan.query.filter_by(class_id=selected_class_id).all()
        
        # 预先将 plans 转换为可序列化的 JSON 数据
        if plans:
            for plan in plans:
                try:
                    # 手动调用 to_dict() 并将结果添加到列表中
                    plan_dict = {
                        'id': plan.id,
                        'class_id': plan.class_id,
                        'subject_id': plan.subject_id,
                        'subject': {
                            'id': plan.subject.id if plan.subject else None,
                            'name': plan.subject.name if plan.subject else None
                        },
                        'teacher_id': plan.teacher_id,
                        'teacher': {
                            'id': plan.teacher.id if plan.teacher else None,
                            'name': plan.teacher.name if plan.teacher else None,
                            'staff_id': plan.teacher.staff_id if plan.teacher else None
                        },
                        'hours_per_week': plan.hours_per_week,
                        'is_combined': plan.is_combined,
                        'combination_id': plan.combination_id,
                        'week_type': plan.week_type,
                        'extra_hours': plan.extra_hours,
                        'extra_week_type': plan.extra_week_type
                    }
                    plans_json.append(plan_dict)
                except Exception as e:
                    print(f"Error converting plan ID {plan.id} to dict: {e}")

    return render_template('schedule/manual.html', 
                          classes=classes, 
                          selected_class=selected_class,
                          setting=setting, 
                          schedule_data=schedule_data,
                          plans=plans,
                          plans_json=plans_json,
                          period_display_names=period_display_names)

@schedule_bp.route('/schedule/add_lesson', methods=['POST'])
@login_required
def add_lesson():
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': '您没有权限进行此操作!'})
    
    class_id = request.form.get('class_id', type=int)
    plan_id = request.form.get('plan_id', type=int)
    day = request.form.get('day', type=int)
    period = request.form.get('period', type=int)
    
    if not all([class_id, plan_id, day, period]):
        return jsonify({'success': False, 'message': '参数不完整!'})
    
    # 获取授课计划
    plan = TeachingPlan.query.get_or_404(plan_id)
    
    # 检查该时段是否已有课程
    existing_schedule = Schedule.query.filter_by(class_id=class_id, day_of_week=day, period=period).first()
    if existing_schedule:
        return jsonify({'success': False, 'message': '该时段已有课程!'})
    
    # 检查该时段是否有公共课程设置
    common_course = CommonCourse.query.filter_by(day_of_week=day, period=period).first()
    if common_course:
        if common_course.apply_to_all_classes or common_course.class_id == class_id:
            return jsonify({'success': False, 'message': f'该时段已设置为公共课程 "{common_course.name}"!'})
    
    # 检查教师在该时段是否已有其他课程
    teacher_conflict = Schedule.query.filter_by(teacher_id=plan.teacher_id, day_of_week=day, period=period).first()
    if teacher_conflict:
        teacher_class = Class.query.get(teacher_conflict.class_id)
        return jsonify({'success': False, 'message': f'教师在该时段已有课程({teacher_class.name})!'})
    
    # 如果是合班，检查合班中的其他班级在该时段是否有冲突
    if plan.is_combined and plan.combination_id:
        combination = ClassCombination.query.get(plan.combination_id)
        for other_class in combination.classes:
            if other_class.id != class_id:
                other_conflict = Schedule.query.filter_by(class_id=other_class.id, day_of_week=day, period=period).first()
                if other_conflict:
                    return jsonify({'success': False, 'message': f'合班中的 {other_class.name} 在该时段已有课程!'})
    
    # 创建课表记录
    schedule = Schedule(
        class_id=class_id,
        subject_id=plan.subject_id,
        teacher_id=plan.teacher_id,
        day_of_week=day,
        period=period,
        is_combined=plan.is_combined,
        combination_id=plan.combination_id
    )
    
    db.session.add(schedule)
    
    # 如果是合班，为合班中的其他班级也创建相同的课表记录
    if plan.is_combined and plan.combination_id:
        combination = ClassCombination.query.get(plan.combination_id)
        for other_class in combination.classes:
            if other_class.id != class_id:
                other_schedule = Schedule(
                    class_id=other_class.id,
                    subject_id=plan.subject_id,
                    teacher_id=plan.teacher_id,
                    day_of_week=day,
                    period=period,
                    is_combined=True,
                    combination_id=plan.combination_id
                )
                db.session.add(other_schedule)
    
    db.session.commit()
    
    # 获取已排课时数和总课时数
    scheduled_count = Schedule.query.filter_by(class_id=class_id, subject_id=plan.subject_id).count()
    total_hours = plan.hours_per_week
    
    return jsonify({
        'success': True, 
        'message': '添加课程成功!',
        'subject_name': plan.subject.name,
        'teacher_name': plan.teacher.name,
        'scheduled_count': scheduled_count,
        'total_hours': total_hours,
        'is_combined': plan.is_combined
    })

@schedule_bp.route('/schedule/remove_lesson', methods=['POST'])
@login_required
def remove_lesson():
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': '您没有权限进行此操作!'})
    
    class_id = request.form.get('class_id', type=int)
    day = request.form.get('day', type=int)
    period = request.form.get('period', type=int)
    
    if not all([class_id, day, period]):
        return jsonify({'success': False, 'message': '参数不完整!'})
    
    # 获取该时段的课程
    schedule = Schedule.query.filter_by(class_id=class_id, day_of_week=day, period=period).first()
    
    if not schedule:
        return jsonify({'success': False, 'message': '该时段没有课程!'})
    
    subject_id = schedule.subject_id
    is_combined = schedule.is_combined
    combination_id = schedule.combination_id
    
    # 如果是合班，删除其他班级的相同课程
    if is_combined and combination_id:
        Schedule.query.filter_by(combination_id=combination_id, day_of_week=day, period=period).delete()
    else:
        db.session.delete(schedule)
    
    db.session.commit()
    
    # 获取已排课时数和总课时数
    plan = TeachingPlan.query.filter_by(class_id=class_id, subject_id=subject_id).first()
    scheduled_count = Schedule.query.filter_by(class_id=class_id, subject_id=subject_id).count()
    total_hours = plan.hours_per_week if plan else 0
    
    return jsonify({
        'success': True, 
        'message': '删除课程成功!',
        'scheduled_count': scheduled_count,
        'total_hours': total_hours
    })

@schedule_bp.route('/schedule/export/<int:class_id>')
@login_required
def export_class_schedule(class_id):
    # 获取班级信息
    class_obj = Class.query.get_or_404(class_id)
    
    # 获取排课设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
    
    # 获取班级课表数据
    schedule_data = get_class_schedule(class_id, setting)
    
    # 创建 CSV 数据
    output = io.StringIO()
    writer = csv.writer(output)
    
    # 写入标题行
    header = ['时间']
    for day in range(1, setting.days_per_week + 1):
        day_names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
        header.append(day_names[day-1])
    writer.writerow(header)
    
    # 写入课表数据
    for period in range(1, setting.periods_per_day + 1):
        row = [f'第{period}节']
        for day in range(1, setting.days_per_week + 1):
            cell_data = schedule_data.get(day, {}).get(period, '')
            cell_text = ''
            if cell_data:
                cell_text = f"{cell_data['subject']}\n{cell_data['teacher']}"
                if cell_data['is_combined']:
                    cell_text += "\n(合班)"
            row.append(cell_text)
        writer.writerow(row)
    
    # 准备响应
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'{class_obj.name}_课表.csv'
    )

@schedule_bp.route('/schedule/export_teacher/<int:teacher_id>')
@login_required
def export_teacher_schedule(teacher_id):
    # 获取教师信息
    teacher = Teacher.query.get_or_404(teacher_id)
    
    # 获取排课设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
    
    # 获取教师课表数据
    schedule_data = get_teacher_schedule(teacher_id, setting)
    
    # 创建 CSV 数据
    output = io.StringIO()
    writer = csv.writer(output)
    
    # 写入标题行
    header = ['时间']
    for day in range(1, setting.days_per_week + 1):
        day_names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
        header.append(day_names[day-1])
    writer.writerow(header)
    
    # 写入课表数据
    for period in range(1, setting.periods_per_day + 1):
        row = [f'第{period}节']
        for day in range(1, setting.days_per_week + 1):
            cell = schedule_data.get((day, period), '')
            row.append(cell)
        writer.writerow(row)
    
    # 准备响应
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'{teacher.name}_课表.csv'
    )

@schedule_bp.route('/schedule/check_teacher', methods=['POST'])
@login_required
def check_teacher():
    day = request.form.get('day', type=int)
    period = request.form.get('period', type=int)
    
    # 获取该时段有课的教师列表
    busy_teachers = []
    schedules = Schedule.query.filter_by(day_of_week=day, period=period).all()
    
    for schedule in schedules:
        if schedule.teacher_id not in [t['id'] for t in busy_teachers]:
            teacher = Teacher.query.get(schedule.teacher_id)
            class_obj = Class.query.get(schedule.class_id)
            subject = Subject.query.get(schedule.subject_id)
            
            busy_teachers.append({
                'id': teacher.id,
                'name': teacher.name,
                'class_name': class_obj.name,
                'subject_name': subject.name
            })
    
    # 获取该时段空闲的教师列表
    free_teachers = []
    all_teachers = Teacher.query.all()
    
    for teacher in all_teachers:
        if teacher.id not in [t['id'] for t in busy_teachers]:
            free_teachers.append({
                'id': teacher.id,
                'name': teacher.name,
                'subjects': [{'id': s.id, 'name': s.name} for s in teacher.subjects]
            })
    
    return jsonify({
        'busy_teachers': busy_teachers,
        'free_teachers': free_teachers
    })

@schedule_bp.route('/schedule/calculate_available_slots', methods=['POST'])
@login_required
def calculate_available_slots():
    try:
        if current_user.role != 'admin':
            return jsonify({'success': False, 'message': '没有权限执行此操作'})
        
        class_id = request.form.get('class_id', type=int)
        plan_id = request.form.get('plan_id', type=int)
        
        if not class_id or not plan_id:
            return jsonify({'success': False, 'message': '参数缺失'})
        
        # 获取当前课程安排计划
        plan = TeachingPlan.query.get(plan_id)
        if not plan:
            return jsonify({'success': False, 'message': f'未找到ID为{plan_id}的教学计划'})
        
        # 获取排课设置
        setting = ScheduleSetting.query.first()
        if not setting:
            return jsonify({'success': False, 'message': '未找到排课设置'})
        
        # 获取教师已排课的所有课程
        teacher_id = plan.teacher_id
        teacher_schedules = Schedule.query.filter_by(teacher_id=teacher_id).all()
        
        # 获取班级已排课的时段
        class_schedules = Schedule.query.filter_by(class_id=class_id).all()
        
        # 构建已占用的时段集合
        occupied_slots = set()
        
        # 添加教师已排课的时段
        for schedule in teacher_schedules:
            occupied_slots.add((schedule.day_of_week, schedule.period))
        
        # 添加班级已排课的时段
        for schedule in class_schedules:
            occupied_slots.add((schedule.day_of_week, schedule.period))
        
        # 计算可用时段
        available_slots = []
        for day in range(1, setting.days_per_week + 1):
            for period in range(1, setting.periods_per_day + 1):
                if (day, period) not in occupied_slots:
                    available_slots.append({'day': day, 'period': period})
        
        return jsonify({
            'success': True, 
            'available_slots': available_slots,
            'plan_id': plan_id
        })
    except Exception as e:
        # 记录错误信息便于调试
        import traceback
        print(f"计算可用单元格错误: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'success': False, 'message': f'服务器错误: {str(e)}'})

@schedule_bp.route('/schedule/get_swappable_slots', methods=['POST'])
@login_required
def get_swappable_slots():
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': '您没有权限进行此操作!'})

    class_id = request.form.get('class_id', type=int)
    source_day = request.form.get('source_day', type=int)
    source_period = request.form.get('source_period', type=int)

    if not all([class_id, source_day, source_period]):
        return jsonify({'success': False, 'message': '参数不完整!'})

    source_schedule_item = Schedule.query.filter_by(
        class_id=class_id, day_of_week=source_day, period=source_period
    ).first()

    if not source_schedule_item:
        return jsonify({'success': False, 'message': '未找到要换的原始课程!'})

    setting = ScheduleSetting.query.first()
    if not setting:
        return jsonify({'success': False, 'message': '未找到排课设置!'})

    swappable_empty_slots = []
    swappable_lessons = []

    # 查找可交换的空位
    for day in range(1, setting.days_per_week + 1):
        for period in range(1, setting.periods_per_day + 1):
            if day == source_day and period == source_period:
                continue # 跳过原始课程位置

            # 检查此位置是否设置为公共课程
            common_course = CommonCourse.query.filter_by(day_of_week=day, period=period).first()
            if common_course and (common_course.apply_to_all_classes or common_course.class_id == class_id):
                continue # 跳过公共课程时段

            # 检查此空位是否已被占用
            is_slot_occupied_by_class = Schedule.query.filter_by(class_id=class_id, day_of_week=day, period=period).first()
            if is_slot_occupied_by_class:
                continue # 班级在该时段已有课
            
            # 检查教师在该时段是否有空
            is_teacher_busy = Schedule.query.filter_by(teacher_id=source_schedule_item.teacher_id, day_of_week=day, period=period).first()
            if is_teacher_busy:
                continue # 教师在该时段已有课
            
            # TODO: 检查合班课的冲突 (如果source_schedule_item是合班课)
            if source_schedule_item.is_combined and source_schedule_item.combination_id:
                combination = ClassCombination.query.get(source_schedule_item.combination_id)
                conflict_in_combined = False
                if combination: # Ensure combination exists
                    for other_class_in_combo in combination.classes:
                        if other_class_in_combo.id != class_id: 
                            if Schedule.query.filter_by(class_id=other_class_in_combo.id, day_of_week=day, period=period).first():
                                conflict_in_combined = True
                                break
                    if conflict_in_combined:
                        continue
                # else: if combination not found, treat as non-combined for this check or log warning
            
            swappable_empty_slots.append({'day': day, 'period': period})

    # 查找可交换的其他课程 (简化版：只在本班级内查找)
    all_other_lessons_in_class = Schedule.query.filter(
        Schedule.class_id == class_id,
        Schedule.id != source_schedule_item.id
    ).all()

    for target_lesson in all_other_lessons_in_class:
        # 1. 源课程换到目标课程时段，源课程的老师是否有空?
        source_teacher_free_at_target_slot = not Schedule.query.filter(
            Schedule.teacher_id == source_schedule_item.teacher_id,
            Schedule.day_of_week == target_lesson.day_of_week,
            Schedule.period == target_lesson.period,
            Schedule.id != source_schedule_item.id  # 排除自己
        ).first()
        
        # 2. 目标课程换到源课程时段，目标课程的老师是否有空?
        target_teacher_free_at_source_slot = not Schedule.query.filter(
            Schedule.teacher_id == target_lesson.teacher_id,
            Schedule.day_of_week == source_schedule_item.day_of_week,
            Schedule.period == source_schedule_item.period,
            Schedule.id != target_lesson.id # 排除自己
        ).first()

        # TODO: 更复杂的合班逻辑，如果源或目标是合班课，需要检查所有相关班级和教师的冲突
        can_swap_lessons = source_teacher_free_at_target_slot and target_teacher_free_at_source_slot
        
        if can_swap_lessons:
            # 进一步检查合班情况
            source_is_combined = source_schedule_item.is_combined
            target_is_combined = target_lesson.is_combined

            if source_is_combined != target_is_combined: # 一个是合班一个不是，通常不允许直接对调，除非逻辑更复杂
                # For now, let's assume they can be swapped if both slots are valid for both teachers
                # This simplification might lead to issues if not handled carefully in swap_lesson
                pass 

            if source_is_combined and source_schedule_item.combination_id:
                source_combo = ClassCombination.query.get(source_schedule_item.combination_id)
                if source_combo: # Ensure combination exists
                    for s_cls in source_combo.classes:
                        if s_cls.id != class_id: 
                            query = Schedule.query.filter(
                                Schedule.class_id == s_cls.id, 
                                Schedule.day_of_week == target_lesson.day_of_week, 
                                Schedule.period == target_lesson.period
                            )
                            existing_lesson_for_combo_class_at_target = query.first()
                            if existing_lesson_for_combo_class_at_target and \
                               (not target_lesson.is_combined or not target_lesson.combination_id or target_lesson.combination_id != source_schedule_item.combination_id or existing_lesson_for_combo_class_at_target.id != target_lesson.id) :
                                can_swap_lessons = False; break
                    if not can_swap_lessons: continue
                # else: if combination not found, might be an issue or treat as non-combined
            
            if target_is_combined and target_lesson.combination_id:
                target_combo = ClassCombination.query.get(target_lesson.combination_id)
                if target_combo: # Ensure combination exists
                    for t_cls in target_combo.classes:
                        if t_cls.id != class_id:
                            query = Schedule.query.filter(
                                Schedule.class_id == t_cls.id, 
                                Schedule.day_of_week == source_day, 
                                Schedule.period == source_period
                            )
                            existing_lesson_for_combo_class_at_source = query.first()
                            if existing_lesson_for_combo_class_at_source and \
                               (not source_schedule_item.is_combined or not source_schedule_item.combination_id or source_schedule_item.combination_id != target_lesson.combination_id or existing_lesson_for_combo_class_at_source.id != source_schedule_item.id) :
                                can_swap_lessons = False; break
                    if not can_swap_lessons: continue
                # else: if combination not found, might be an issue or treat as non-combined

            if can_swap_lessons:
                 swappable_lessons.append({
                    'day': target_lesson.day_of_week,
                    'period': target_lesson.period,
                    'subject_id': target_lesson.subject_id,
                    'teacher_id': target_lesson.teacher_id,
                    'subject_name': target_lesson.subject.name,
                    'teacher_name': target_lesson.teacher.name
                })

    return jsonify({
        'success': True, 
        'swappable_slots': swappable_empty_slots, 
        'swappable_lessons': swappable_lessons,
        'source_lesson': {
            'subject_id': source_schedule_item.subject_id,
            'teacher_id': source_schedule_item.teacher_id,
            'subject_name': source_schedule_item.subject.name,
            'teacher_name': source_schedule_item.teacher.name
        }
    })

@schedule_bp.route('/schedule/swap_lesson', methods=['POST'])
@login_required
def swap_lesson():
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': '您没有权限进行此操作!'})

    source_class_id = request.form.get('source_class_id', type=int)
    source_day = request.form.get('source_day', type=int)
    source_period = request.form.get('source_period', type=int)
    # source_subject_id = request.form.get('source_subject_id', type=int) # Not strictly needed if fetching source_lesson
    # source_teacher_id = request.form.get('source_teacher_id', type=int) # Not strictly needed

    target_class_id = request.form.get('target_class_id', type=int)
    target_day = request.form.get('target_day', type=int)
    target_period = request.form.get('target_period', type=int)
    target_subject_id = request.form.get('target_subject_id', type=int, default=None)
    target_teacher_id = request.form.get('target_teacher_id', type=int, default=None)

    if not all([source_class_id, source_day, source_period, target_class_id, target_day, target_period]):
        return jsonify({'success': False, 'message': '参数不完整!'})

    source_lesson = Schedule.query.filter_by(class_id=source_class_id, day_of_week=source_day, period=source_period).first()
    if not source_lesson:
        return jsonify({'success': False, 'message': '源课程不存在!'})
        
    # 检查目标时段是否设置了公共课程
    common_course = CommonCourse.query.filter_by(day_of_week=target_day, period=target_period).first()
    if common_course:
        if common_course.apply_to_all_classes or common_course.class_id == target_class_id:
            return jsonify({'success': False, 'message': f'目标时段已设置为公共课程 "{common_course.name}"，无法交换!'})

    # 检查目标位置是否有课程
    target_slot_occupation = Schedule.query.filter_by(class_id=target_class_id, day_of_week=target_day, period=target_period).first()
    
    # Case 1: 尝试与空位交换
    if target_subject_id is None and target_teacher_id is None:
        # 如果目标时段已被占用，但没有提供target_subject_id和target_teacher_id
        # 这可能是前端和后端状态不一致导致的，例如在用户点击时，该位置刚被另一个操作占用
        if target_slot_occupation:
            print(f"警告: 目标时段({target_day}, {target_period})被标记为空位，但实际已被占用。尝试自动调整为课程对换。")
            
            # 检查是否可以与占用的课程进行交换
            # 1. 检查源课程老师在目标时段的其他课程冲突
            teacher_conflict = Schedule.query.filter(
                Schedule.teacher_id == source_lesson.teacher_id, 
                Schedule.day_of_week == target_day, 
                Schedule.period == target_period,
                Schedule.id != target_slot_occupation.id  # 排除目标课程本身
            ).first()
            if teacher_conflict:
                return jsonify({'success': False, 'message': f'教师 {source_lesson.teacher.name} 在目标时段已有其他课程!'})
            
            # 2. 检查目标课程老师在源课程时段的其他课程冲突
            other_teacher_conflict = Schedule.query.filter(
                Schedule.teacher_id == target_slot_occupation.teacher_id,
                Schedule.day_of_week == source_day,
                Schedule.period == source_period,
                Schedule.id != source_lesson.id  # 排除源课程本身
            ).first()
            if other_teacher_conflict:
                return jsonify({'success': False, 'message': f'教师 {target_slot_occupation.teacher.name} 在源课程时段已有其他课程!'})
            
            # 使用已占用课程的信息创建目标课程对象，转为课程对换处理
            target_lesson = target_slot_occupation
        else:
            # 目标位置确实是空的，检查教师冲突
            teacher_conflict_at_target = Schedule.query.filter(
                Schedule.teacher_id == source_lesson.teacher_id,
                Schedule.day_of_week == target_day,
                Schedule.period == target_period
            ).first()
            if teacher_conflict_at_target:
                return jsonify({'success': False, 'message': f'教师 {source_lesson.teacher.name} 在目标时段已有其他安排!'})
            
            # 处理合班课情况
            if source_lesson.is_combined and source_lesson.combination_id:
                source_combination = ClassCombination.query.get(source_lesson.combination_id)
                for s_class in source_combination.classes:
                    if s_class.id != source_class_id: # 对合班中的其他班级
                        # 检查目标时段是否空闲
                        if Schedule.query.filter_by(class_id=s_class.id, day_of_week=target_day, period=target_period).first():
                            return jsonify({'success': False, 'message': f'合班中的班级 {s_class.name} 在目标时段已有课程!'})
                        # 更新或创建它们的课表条目
                        other_class_schedule = Schedule.query.filter_by(class_id=s_class.id, day_of_week=source_day, period=source_period).first()
                        if other_class_schedule:
                            other_class_schedule.day_of_week = target_day
                            other_class_schedule.period = target_period
                        else: # 如果数据一致性良好，这种情况不应该发生
                            db.session.add(Schedule(class_id=s_class.id, subject_id=source_lesson.subject_id, teacher_id=source_lesson.teacher_id, day_of_week=target_day, period=target_period, is_combined=True, combination_id=source_lesson.combination_id))
            
            # 移动源课程到目标时段
            source_lesson.day_of_week = target_day
            source_lesson.period = target_period
            db.session.commit()
            return jsonify({'success': True, 'message': '课程成功移动到新时段!'})
            
    # Case 2: 与另一个课程交换
    # 如果前面的逻辑将空位交换自动调整为课程交换，或者前端直接传递了目标课程信息，则执行此逻辑
    if (target_subject_id is not None and target_teacher_id is not None) or target_slot_occupation:
        # 如果通过自动调整获取了target_lesson，则使用它；否则通过ID查询
        target_lesson = target_slot_occupation if target_slot_occupation else Schedule.query.filter_by(class_id=target_class_id, day_of_week=target_day, period=target_period).first()
        
        if not target_lesson:
            return jsonify({'success': False, 'message': '目标课程不存在!'})
        
        if source_lesson.id == target_lesson.id:
            return jsonify({'success': False, 'message': '不能和自己换课!'})

        # --- Start a transaction for safety ---
        try:
            # Store original details before modifying
            original_source_day = source_lesson.day_of_week
            original_source_period = source_lesson.period
            original_target_day = target_lesson.day_of_week
            original_target_period = target_lesson.period

            # Detach them temporarily to avoid unique constraint issues if any, or update carefully
            # A simpler way: just update days and periods. We need to ensure no intermediate conflicts.
            
            # Step 1: Check if source_lesson can move to target_lesson's slot
            # Teacher conflict for source_lesson's teacher at target slot (excluding target_lesson itself if same teacher)
            source_teacher_conflict = Schedule.query.filter(
                Schedule.teacher_id == source_lesson.teacher_id,
                Schedule.day_of_week == original_target_day,
                Schedule.period == original_target_period,
                Schedule.id != target_lesson.id # Exclude the target lesson itself from check
            ).first()
            if source_teacher_conflict:
                raise ValueError(f'教师 {source_lesson.teacher.name} 在目标课程时段已有其他安排!')

            # Step 2: Check if target_lesson can move to source_lesson's slot
            # Teacher conflict for target_lesson's teacher at source slot (excluding source_lesson itself if same teacher)
            target_teacher_conflict = Schedule.query.filter(
                Schedule.teacher_id == target_lesson.teacher_id,
                Schedule.day_of_week == original_source_day,
                Schedule.period == original_source_period,
                Schedule.id != source_lesson.id # Exclude the source lesson itself from check
            ).first()
            if target_teacher_conflict:
                raise ValueError(f'教师 {target_lesson.teacher.name} 在源课程时段已有其他安排!')

            # Combined class checks
            if source_lesson.is_combined and source_lesson.combination_id:
                source_combo = ClassCombination.query.get(source_lesson.combination_id)
                for s_cls in source_combo.classes:
                    if s_cls.id != source_class_id: # For other classes in the combination
                        # Check if target slot is free for them (excluding target lesson if it's part of this combo)
                        existing_conflict_for_source_combo = Schedule.query.filter(
                            Schedule.class_id == s_cls.id, 
                            Schedule.day_of_week == original_target_day, 
                            Schedule.period == original_target_period, 
                            Schedule.id != target_lesson.id 
                            ).first()
                        if existing_conflict_for_source_combo and \
                           (not target_lesson.is_combined or not target_lesson.combination_id or target_lesson.combination_id != source_lesson.combination_id or existing_conflict_for_source_combo.id != target_lesson.id):
                            raise ValueError(f'源合班课程中的班级 {s_cls.name} 在目标时段有冲突!')
            
            if target_lesson.is_combined and target_lesson.combination_id:
                target_combo = ClassCombination.query.get(target_lesson.combination_id)
                for t_cls in target_combo.classes:
                    if t_cls.id != target_class_id:
                        existing_conflict_for_target_combo = Schedule.query.filter(
                            Schedule.class_id == t_cls.id, 
                            Schedule.day_of_week == original_source_day, 
                            Schedule.period == original_source_period,
                            Schedule.id != source_lesson.id).first()
                        if existing_conflict_for_target_combo and \
                           (not source_lesson.is_combined or not source_lesson.combination_id or source_lesson.combination_id != target_lesson.combination_id or existing_conflict_for_target_combo.id != source_lesson.id):
                            raise ValueError(f'目标合班课程中的班级 {t_cls.name} 在源时段有冲突!')
            
            # Perform the swap for main lessons
            source_lesson.day_of_week = original_target_day
            source_lesson.period = original_target_period
            target_lesson.day_of_week = original_source_day
            target_lesson.period = original_source_period
            
            db.session.flush() # Flush to check for immediate db-level unique constraints if any

            # Update combined classes
            if source_lesson.is_combined and source_lesson.combination_id:
                source_combo_schedules = Schedule.query.filter(
                    Schedule.combination_id == source_lesson.combination_id,
                    Schedule.day_of_week == original_source_day, 
                    Schedule.period == original_source_period,
                    Schedule.class_id != source_class_id
                ).all()
                for sch in source_combo_schedules:
                    sch.day_of_week = original_target_day
                    sch.period = original_target_period
            
            if target_lesson.is_combined and target_lesson.combination_id:
                target_combo_schedules = Schedule.query.filter(
                    Schedule.combination_id == target_lesson.combination_id,
                    Schedule.day_of_week == original_target_day, 
                    Schedule.period == original_target_period,
                    Schedule.class_id != target_class_id
                ).all()
                for sch in target_combo_schedules:
                    sch.day_of_week = original_source_day
                    sch.period = original_source_period
            
            db.session.commit()
            return jsonify({'success': True, 'message': '课程对调成功!'})
        
        except ValueError as ve:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(ve)})
        except Exception as e:
            db.session.rollback()
            # Log the full error for debugging
            import traceback
            print(f"Error swapping lessons: {e}")
            print(traceback.format_exc())
            return jsonify({'success': False, 'message': f'发生内部错误: {str(e)}'})
    
    # 如果代码执行到这里，说明参数传递或逻辑有问题
    return jsonify({'success': False, 'message': '无效的请求参数或状态!'})

@schedule_bp.route('/schedule/teacher_popup_schedule/<int:teacher_id>')
@login_required
def teacher_popup_schedule(teacher_id):
    try:
        if current_user.role != 'admin':
            return jsonify({'success': False, 'message': '您没有权限进行此操作!'})

        teacher = Teacher.query.get_or_404(teacher_id)
        setting = ScheduleSetting.query.first()
        if not setting:
            # 如果没有全局设置，提供一个默认的最小设置以便课表可以渲染
            setting = ScheduleSetting(days_per_week=5, periods_per_day=8, morning_periods=4, afternoon_periods=4)

        # 使用包含早晚自习的教师课表数据
        raw_schedule_data = get_teacher_schedule_with_selfstudy(teacher_id, setting)

        # 将课表数据转换为更适合JSON和前端处理的格式
        # { day: { period: lesson_text, ... }, ... }
        formatted_schedule = defaultdict(dict)
        for day, periods_data in raw_schedule_data.items():
            for period, lesson_data in periods_data.items():
                # 如果lesson_data是字典，格式化为显示文本
                if isinstance(lesson_data, dict):
                    # 格式化为 "学科-班级" 的形式
                    formatted_schedule[day][period] = f"{lesson_data['subject']}-{lesson_data['teacher']}"
                else:
                    # 如果已经是文本，直接使用
                    formatted_schedule[day][period] = lesson_data
        
        # 获取教师姓名
        teacher_name = teacher.name

        return jsonify({
            'success': True,
            'teacher_name': teacher_name,
            'schedule': formatted_schedule,
            'setting': {
                'days_per_week': setting.days_per_week,
                'periods_per_day': setting.periods_per_day,
                'morning_periods': setting.morning_periods,
                'afternoon_periods': setting.afternoon_periods
                # Add any other setting fields needed by the popup display
            }
        })
    except Exception as e:
        # 添加错误处理和日志记录
        import traceback
        print(f"teacher_popup_schedule error for teacher_id {teacher_id}: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            'success': False, 
            'message': f'获取教师课表失败: {str(e)}'
        }), 500

@schedule_bp.route('/api/subject_blocks', methods=['GET'])
@login_required
def get_subject_blocks():
    """获取所有学科禁排设置"""
    blocks = SubjectBlock.query.all()
    result = {}
    
    for block in blocks:
        key = f"{block.day_of_week}-{block.period}"
        if block.is_block_all:
            # 如果禁排所有学科
            result[key] = {
                "blockAll": True,
                "subjects": []
            }
        else:
            # 如果只禁排特定学科
            # 检查该单元格是否已有数据
            if key in result:
                # 已存在，则添加到subjects列表中
                result[key]["subjects"].append(block.subject_id)
            else:
                # 不存在，则创建新条目
                result[key] = {
                    "blockAll": False,
                    "subjects": [block.subject_id]
                }
    
    return jsonify(result)

@schedule_bp.route('/api/subject_blocks', methods=['POST'])
@login_required
def save_subject_blocks():
    """保存学科禁排设置"""
    if current_user.role != 'admin':
        return jsonify({"error": "权限不足"}), 403
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "无效的数据格式"}), 400
        
        day = data.get('day')
        period = data.get('period')
        block_all = data.get('blockAll', False)
        subject_ids = data.get('subjects', [])
        
        if not day or not period:
            return jsonify({"error": "缺少必要参数"}), 400
        
        # 删除该单元格的现有禁排设置
        SubjectBlock.query.filter_by(day_of_week=day, period=period).delete()
        
        # 添加新的禁排设置
        if block_all:
            # 禁排所有学科
            block = SubjectBlock(
                day_of_week=day,
                period=period,
                is_block_all=True
            )
            db.session.add(block)
        else:
            # 禁排选定的学科
            for subject_id in subject_ids:
                block = SubjectBlock(
                    day_of_week=day,
                    period=period,
                    subject_id=subject_id,
                    is_block_all=False
                )
                db.session.add(block)
        
        db.session.commit()
        return jsonify({"success": True})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@schedule_bp.route('/api/subject_blocks', methods=['DELETE'])
@login_required
def delete_subject_block():
    """删除学科禁排设置"""
    if current_user.role != 'admin':
        return jsonify({"error": "权限不足"}), 403
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "无效的数据格式"}), 400
        
        day = data.get('day')
        period = data.get('period')
        
        if not day or not period:
            return jsonify({"error": "缺少必要参数"}), 400
        
        # 删除该单元格的所有禁排设置
        deleted_count = SubjectBlock.query.filter_by(day_of_week=day, period=period).delete()
        
        db.session.commit()
        return jsonify({"success": True, "deleted_count": deleted_count})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# 公共课程API
@schedule_bp.route('/api/common_courses', methods=['GET'])
@login_required
def get_common_courses():
    """获取所有公共课程设置"""
    common_courses = CommonCourse.query.all()
    result = {}
    
    for course in common_courses:
        key = f"{course.day_of_week}-{course.period}"
        result[key] = {
            "id": course.id,
            "name": course.name,
            "description": course.description,
            "applyToAllClasses": course.apply_to_all_classes,
            "classId": course.class_id,
            "weekType": course.week_type
        }
    
    return jsonify(result)

@schedule_bp.route('/api/common_courses', methods=['POST'])
@login_required
def save_common_course():
    """保存公共课程设置"""
    if current_user.role != 'admin':
        return jsonify({"error": "权限不足"}), 403
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "无效的数据格式"}), 400
        
        name = data.get('name')
        day = data.get('day')
        period = data.get('period')
        description = data.get('description', '')
        apply_to_all_classes = data.get('applyToAllClasses', True)
        class_id = data.get('classId') if not apply_to_all_classes else None
        week_type = data.get('weekType', 'all')
        
        if not all([name, day, period]):
            return jsonify({"error": "缺少必要参数"}), 400
        
        # 检查该时段是否已有公共课程
        existing_course = CommonCourse.query.filter_by(day_of_week=day, period=period).first()
        if existing_course:
            # 更新已有公共课程
            existing_course.name = name
            existing_course.description = description
            existing_course.apply_to_all_classes = apply_to_all_classes
            existing_course.class_id = class_id
            existing_course.week_type = week_type
        else:
            # 创建新公共课程
            new_course = CommonCourse(
                name=name,
                day_of_week=day,
                period=period,
                description=description,
                apply_to_all_classes=apply_to_all_classes,
                class_id=class_id,
                week_type=week_type
            )
            db.session.add(new_course)
        
        db.session.commit()
        return jsonify({"success": True})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@schedule_bp.route('/api/common_courses', methods=['DELETE'])
@login_required
def delete_common_course():
    """删除公共课程设置"""
    if current_user.role != 'admin':
        return jsonify({"error": "权限不足"}), 403
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "无效的数据格式"}), 400
        
        day = data.get('day')
        period = data.get('period')
        
        if not day or not period:
            return jsonify({"error": "缺少必要参数"}), 400
        
        # 删除该单元格的公共课程设置
        deleted = CommonCourse.query.filter_by(day_of_week=day, period=period).delete()
        
        db.session.commit()
        return jsonify({"success": True, "deleted": deleted})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# 班级API
@schedule_bp.route('/api/classes', methods=['GET'])
@login_required
def get_classes():
    """获取所有班级列表"""
    classes = Class.query.order_by(Class.grade, Class.name).all()
    result = []
    
    for class_obj in classes:
        result.append({
            "id": class_obj.id,
            "name": class_obj.name,
            "grade": class_obj.grade
        })
    
    return jsonify(result)

# 辅助函数

def get_class_schedule(class_id, setting):
    """获取指定班级的课表数据"""
    schedule_data = {}
    
    schedules = Schedule.query.filter_by(class_id=class_id).all()
    
    # 初始化每个单元格
    for day in range(1, setting.days_per_week + 1):
        schedule_data[day] = {}
    
    # 初始化计划已排课时数
    scheduled_counts = {}
    
    for schedule in schedules:
        day = schedule.day_of_week
        period = schedule.period
        subject = Subject.query.get(schedule.subject_id)
        teacher = Teacher.query.get(schedule.teacher_id)
        
        if day not in schedule_data:
            schedule_data[day] = {}
        
        # 获取对应的教学计划
        plan = TeachingPlan.query.filter_by(class_id=class_id, subject_id=schedule.subject_id, teacher_id=schedule.teacher_id).first()
        
        schedule_data[day][period] = {
            'subject': subject.name,
            'teacher': teacher.name,
            'teacher_id': teacher.id,
            'subject_id': subject.id,
            'plan_id': plan.id if plan else None,
            'is_combined': schedule.is_combined
        }
        
        # 更新该学科的已排课时计数
        if plan:
            if plan.id not in scheduled_counts:
                # 计算该计划的所有已排课时
                count = Schedule.query.filter_by(class_id=class_id, subject_id=schedule.subject_id, teacher_id=schedule.teacher_id).count()
                scheduled_counts[plan.id] = count
    
    # 添加公共课程信息
    common_courses = CommonCourse.query.all()
    for course in common_courses:
        day = course.day_of_week
        period = course.period
        
        # 如果公共课程适用于所有班级或特定于该班级
        if course.apply_to_all_classes or course.class_id == class_id:
            if day not in schedule_data:
                schedule_data[day] = {}
            
            # 添加公共课程信息，使用特殊标记区分普通课程
            schedule_data[day][period] = {
                'subject': course.name,
                'description': course.description or '',
                'teacher': '公共课程',
                'teacher_id': 0,  # 虚拟ID，表示非教师课程
                'is_combined': False,
                'is_common_course': True,
                'week_type': course.week_type
            }
    
    # 添加已排课时计数到返回数据中
    schedule_data['scheduled_counts'] = scheduled_counts
    
    return schedule_data

def get_teacher_schedule(teacher_id, setting):
    """获取指定教师的课表数据"""
    schedule_data = {}
    
    schedules = Schedule.query.filter_by(teacher_id=teacher_id).all()
    
    # 初始化数据结构
    for day in range(1, setting.days_per_week + 1):
        schedule_data[day] = {}
    
    for schedule in schedules:
        day = schedule.day_of_week
        period = schedule.period
        subject = Subject.query.get(schedule.subject_id)
        class_obj = Class.query.get(schedule.class_id)
        
        # 使用与班级课表相同的数据结构
        schedule_data[day][period] = {
            'subject': subject.name,
            'teacher': class_obj.name,  # 对于教师视图，"teacher"字段实际存储班级名称
            'class_id': class_obj.id,
            'subject_id': subject.id,
            'is_combined': schedule.is_combined,
            'is_saturday_priority': subject.name.endswith('1')
        }
    
    return schedule_data

def auto_schedule(plans, setting, selected_constraints=None):
    """自动排课算法"""
    try:
        # 如果没有提供约束条件，则默认启用所有约束
        if selected_constraints is None:
            selected_constraints = [
                'teacher_conflict', 'class_conflict', 'combined_class',
                'major_morning', 'teacher_max_hours', 'saturday_priority',
                'first_period_balance'
            ]
        
        # 打印所有启用的约束条件，便于调试
        print(f"启用的约束条件: {selected_constraints}")
        
        # 约束条件检查函数
        def is_constraint_enabled(constraint_name):
            return constraint_name in selected_constraints
        
        # 获取涉及的所有班级ID
        involved_class_ids = set([plan.class_id for plan in plans])
        
        # 获取所有课位置
        slots = list(product(range(1, setting.days_per_week + 1), range(1, setting.periods_per_day + 1)))
        
        # 获取学科禁排设置
        subject_blocks = {}
        all_blocks = SubjectBlock.query.all()
        for block in all_blocks:
            key = (block.day_of_week, block.period)
            if key not in subject_blocks:
                subject_blocks[key] = {
                    'all_blocked': block.is_block_all,
                    'subjects': set()
                }
            if not block.is_block_all and block.subject_id:
                subject_blocks[key]['subjects'].add(block.subject_id)
        
        # 获取公共课程设置
        common_courses = {}
        all_common_courses = CommonCourse.query.all()
        for course in all_common_courses:
            key = (course.day_of_week, course.period)
            common_courses[key] = {
                'name': course.name,
                'apply_to_all_classes': course.apply_to_all_classes,
                'class_id': course.class_id
            }
        
        # 定义例外列表，这些科目虽然带"1"后缀但不排在星期六
        saturday_exceptions = ['篮球1', '足球1']
        
        # 将带"1"后缀的科目筛选出来，这些科目将优先排在星期六
        saturday_subjects = []
        normal_subjects = []
        
        for plan in plans:
            subject = Subject.query.get(plan.subject_id)
            # 带"1"后缀且不在例外列表的科目，将强制排在周六
            if subject and subject.name.endswith('1') and subject.name not in saturday_exceptions and is_constraint_enabled('saturday_priority'):
                saturday_subjects.append(plan)
            else:
                normal_subjects.append(plan)
        
        print(f"识别到 {len(saturday_subjects)} 个必须安排在星期六的科目（带1后缀且不包括篮球1、足球1）")
        
        # 对授课计划按优先级排序（主课优先、合班课优先）
        sorted_saturday_plans = sorted(saturday_subjects, key=lambda p: (
            -1 if Subject.query.get(p.subject_id).is_major else 0,  # 主课优先
            -1 if p.is_combined else 0,  # 合班优先
            p.hours_per_week,  # 课时多的优先
            random.random()  # 加入随机性以打破可能的死锁
        ))
        
        sorted_normal_plans = sorted(normal_subjects, key=lambda p: (
            -1 if Subject.query.get(p.subject_id).is_major else 0,  # 主课优先
            -1 if p.is_combined else 0,  # 合班优先
            p.hours_per_week,  # 课时多的优先
            random.random()  # 加入随机性以打破可能的死锁
        ))
        
        # 将排序后的两组计划合并，同时保持星期六科目的优先级
        sorted_plans = sorted_saturday_plans + sorted_normal_plans
        
        # 查找所有需要一起排课的合班计划
        combination_groups = {}
        for plan in sorted_plans:
            if plan.is_combined and plan.combination_id:
                if plan.combination_id not in combination_groups:
                    combination_groups[plan.combination_id] = []
                combination_groups[plan.combination_id].append(plan)
        
        # 初始化资源占用跟踪
        class_slots_used = defaultdict(set)    # 班级已用课位
        teacher_slots_used = defaultdict(set)  # 教师已用课位
        combo_slots_used = defaultdict(set)    # 合班已用课位
        subject_day_count = defaultdict(lambda: defaultdict(int))  # 每天每学科的课时数
        
        # 记录每个计划的已排课时
        plan_hours_scheduled = defaultdict(int)
        
        # 每个班级每天的已排课时
        class_day_count = defaultdict(lambda: defaultdict(int))
        
        # 每个教师每天的已排课时
        teacher_day_count = defaultdict(lambda: defaultdict(int))
        
        # 每个班级的第一节课分配给各科目的次数统计
        first_period_subject_count = defaultdict(lambda: defaultdict(int))
        
        # 加载现有已排课程的时段占用情况（针对未包含在plans中的班级）
        existing_schedules = Schedule.query.filter(~Schedule.class_id.in_(involved_class_ids)).all()
        for schedule in existing_schedules:
            teacher_slots_used[schedule.teacher_id].add((schedule.day_of_week, schedule.period))
            teacher_day_count[schedule.teacher_id][schedule.day_of_week] += 1
            
            # 如果是第一节课，记录科目统计
            if schedule.period == 1:
                first_period_subject_count[schedule.class_id][schedule.subject_id] += 1
        
        # 上午时段（考虑主课优先）
        morning_slots = [(d, p) for d, p in slots if p <= setting.morning_periods]
        afternoon_slots = [(d, p) for d, p in slots if p > setting.morning_periods]
        
        # 星期六时段
        saturday_slots = [(d, p) for d, p in slots if d == 6]
        
        # 第一节课时段
        first_period_slots = [(d, 1) for d in range(1, setting.days_per_week + 1)]
        
        # 剩余时段（非星期六）
        other_day_slots = [(d, p) for d, p in slots if d != 6]
        
        # 定义排课函数
        def schedule_class(plan, available_slots):
            nonlocal plan_hours_scheduled, first_period_subject_count
            
            # 如果已经排满，则返回
            if plan_hours_scheduled[plan.id] >= plan.hours_per_week:
                return True
            
            # 找出可用的时段
            valid_slots = []
            for day, period in available_slots:
                # 检查是否有学科禁排设置
                slot_key = (day, period)
                if slot_key in subject_blocks:
                    block_info = subject_blocks[slot_key]
                    # 如果禁排所有学科，则跳过
                    if block_info['all_blocked']:
                        continue
                    # 如果当前学科被禁排，则跳过
                    if plan.subject_id in block_info['subjects']:
                        continue
                
                # 检查是否有公共课程设置
                if slot_key in common_courses:
                    course_info = common_courses[slot_key]
                    # 如果适用于所有班级，则跳过
                    if course_info['apply_to_all_classes']:
                        continue
                    # 如果适用于当前班级，则跳过
                    if not course_info['apply_to_all_classes'] and course_info['class_id'] == plan.class_id:
                        continue
                
                # 仅在启用班级冲突约束时检查
                if is_constraint_enabled('class_conflict'):
                    # 检查班级在该时段是否已有课
                    if (day, period) in class_slots_used[plan.class_id]:
                        continue
                
                # 仅在启用教师冲突约束时检查
                if is_constraint_enabled('teacher_conflict'):
                    # 检查教师在该时段是否已有课
                    if (day, period) in teacher_slots_used[plan.teacher_id]:
                        continue
                
                # 仅在启用合班课约束时检查
                if is_constraint_enabled('combined_class'):
                    # 如果是合班，检查合班中的其他班级是否在该时段有课
                    # 即使这些班级不在当前排课范围内，也需要检查它们的排课情况
                    if plan.is_combined and plan.combination_id:
                        combination = ClassCombination.query.get(plan.combination_id)
                        
                        # 检查合班中所有班级的冲突
                        has_conflict = False
                        for class_obj in combination.classes:
                            # 检查该班级是否在当前时段已有课程
                            if (day, period) in class_slots_used[class_obj.id]:
                                has_conflict = True
                                break
                            
                            # 如果该班级不在当前排课范围内，查询数据库检查是否有冲突
                            if class_obj.id not in involved_class_ids:
                                existing_schedule = Schedule.query.filter_by(
                                    class_id=class_obj.id, 
                                    day_of_week=day, 
                                    period=period
                                ).first()
                                if existing_schedule:
                                    has_conflict = True
                                    break
                        
                        if has_conflict:
                            continue
                        
                        # 检查合班是否在该时段已有课
                        if (day, period) in combo_slots_used[plan.combination_id]:
                            continue
                
                # 仅在启用教师每日最大课时约束时检查
                if is_constraint_enabled('teacher_max_hours'):
                    # 检查教师每天的课时数是否超过限制
                    teacher_max_hours = Teacher.query.get(plan.teacher_id).max_hours_per_day
                    if teacher_max_hours is None:
                        teacher_max_hours = 6  # 设置默认值
                    
                    if teacher_day_count[plan.teacher_id][day] >= teacher_max_hours:
                        continue
                
                # 已取消"同一学科在一天内尽量不连排多节"的限制
                # 原代码：
                # if subject_day_count[(plan.class_id, plan.subject_id)][day] >= 2:
                #     continue
                
                # 尝试每天排课不超过教师每日最大课时 (重复检查，增加安全性)
                valid_slots.append((day, period))
            
            # 如果没有可用时段，返回失败
            if not valid_slots:
                return False
            
            # 如果启用了第一节课均匀分配约束且当前有包含第一节的可用时段
            if is_constraint_enabled('first_period_balance') and any(slot[1] == 1 for slot in valid_slots):
                # 计算当前班级中各科目在第一节课的分配次数
                subject_counts = first_period_subject_count[plan.class_id]
                if subject_counts:
                    avg_count = sum(subject_counts.values()) / len(subject_counts)
                    current_count = subject_counts.get(plan.subject_id, 0)
                    
                    # 严格均匀分配策略：
                    # 如果当前科目在第一节的次数低于平均值，优先安排第一节课
                    if current_count < avg_count:
                        first_slots = [slot for slot in valid_slots if slot[1] == 1]
                        if first_slots:
                            day, period = random.choice(first_slots)
                            
                            # 创建课表记录并更新计数
                            add_schedule_record(plan, day, period)
                            # 更新第一节课科目分配计数
                            first_period_subject_count[plan.class_id][plan.subject_id] += 1
                            return True
            
            # 随机选择一个可用时段
            day, period = random.choice(valid_slots)
            
            # 创建课表记录并更新计数
            add_schedule_record(plan, day, period)
            # 如果是第一节课，更新科目计数
            if period == 1:
                first_period_subject_count[plan.class_id][plan.subject_id] += 1
            
            return True
        
        # 辅助函数：创建课表记录并更新计数
        def add_schedule_record(plan, day, period):
            nonlocal plan_hours_scheduled
            
            # 创建课表记录
            schedule = Schedule(
                class_id=plan.class_id,
                subject_id=plan.subject_id,
                teacher_id=plan.teacher_id,
                day_of_week=day,
                period=period,
                is_combined=plan.is_combined,
                combination_id=plan.combination_id if plan.is_combined else None
            )
            
            db.session.add(schedule)
            
            # 如果是合班，为合班中在当前排课范围内的其他班级也创建相同的课表记录
            if plan.is_combined and plan.combination_id:
                combination = ClassCombination.query.get(plan.combination_id)
                for class_obj in combination.classes:
                    # 只为在当前排课范围内的班级创建课表
                    if class_obj.id != plan.class_id and class_obj.id in involved_class_ids:
                        other_schedule = Schedule(
                            class_id=class_obj.id,
                            subject_id=plan.subject_id,
                            teacher_id=plan.teacher_id,
                            day_of_week=day,
                            period=period,
                            is_combined=True,
                            combination_id=plan.combination_id
                        )
                        db.session.add(other_schedule)
                        
                        # 更新班级已用课位
                        class_slots_used[class_obj.id].add((day, period))
                        class_day_count[class_obj.id][day] += 1
                        
                        # 如果是第一节课，更新科目计数
                        if period == 1:
                            first_period_subject_count[class_obj.id][plan.subject_id] += 1
                
                # 更新合班已用课位
                combo_slots_used[plan.combination_id].add((day, period))
            
            # 更新已用课位和计数
            class_slots_used[plan.class_id].add((day, period))
            teacher_slots_used[plan.teacher_id].add((day, period))
            subject_day_count[(plan.class_id, plan.subject_id)][day] += 1
            plan_hours_scheduled[plan.id] += 1
            class_day_count[plan.class_id][day] += 1
            teacher_day_count[plan.teacher_id][day] += 1
        
        # 第一阶段：强制处理带"1"后缀的科目（篮球1和足球1除外）
        if is_constraint_enabled('saturday_priority') and saturday_subjects:
            print("第一阶段：强制将带1后缀科目排在周六（篮球1和足球1除外）")
            
            # 首先，计算所有需要排在周六的课时总数
            total_saturday_hours_needed = 0
            for plan in saturday_subjects:
                # 计算每个科目在周六需要的课时数
                total_saturday_hours_needed += min(plan.hours_per_week, len(saturday_slots))
            
            # 检查周六是否有足够的时段
            if total_saturday_hours_needed > len(saturday_slots):
                return False, f"错误：周六没有足够的时段安排所有带1后缀的科目，需要至少 {total_saturday_hours_needed} 个时段，但周六只有 {len(saturday_slots)} 个时段"
            
            # 为每个带"1"后缀的科目强制排在周六
            for plan in saturday_subjects:
                subject = Subject.query.get(plan.subject_id)
                class_obj = Class.query.get(plan.class_id)
                
                print(f"处理科目：{subject.name} (班级：{class_obj.name})，强制排在周六")
                
                # 计算在周六需要安排的课时数
                hours_needed_on_saturday = min(plan.hours_per_week, len(saturday_slots))
                hours_scheduled = 0
                
                # 找出周六所有可用时段
                available_saturday_slots = []
                for slot in saturday_slots:
                    day, period = slot
                    
                    # 检查班级和教师冲突
                    if (day, period) in class_slots_used[plan.class_id] or (day, period) in teacher_slots_used[plan.teacher_id]:
                        continue
                    
                    # 检查学科禁排
                    slot_key = (day, period)
                    if slot_key in subject_blocks:
                        block_info = subject_blocks[slot_key]
                        if block_info['all_blocked'] or plan.subject_id in block_info['subjects']:
                            continue
                    
                    # 检查公共课程
                    if slot_key in common_courses:
                        course_info = common_courses[slot_key]
                        if course_info['apply_to_all_classes'] or (not course_info['apply_to_all_classes'] and course_info['class_id'] == plan.class_id):
                            continue
                    
                    # 检查合班冲突
                    if plan.is_combined and plan.combination_id:
                        has_conflict = False
                        combination = ClassCombination.query.get(plan.combination_id)
                        for other_class in combination.classes:
                            if other_class.id != plan.class_id:
                                if (day, period) in class_slots_used[other_class.id]:
                                    has_conflict = True
                                    break
                                
                                # 检查数据库中的冲突
                                if other_class.id not in involved_class_ids:
                                    existing = Schedule.query.filter_by(
                                        class_id=other_class.id,
                                        day_of_week=day,
                                        period=period
                                    ).first()
                                    if existing:
                                        has_conflict = True
                                        break
                        
                        if has_conflict or (day, period) in combo_slots_used[plan.combination_id]:
                            continue
                    
                    # 通过所有约束检查，添加到可用时段
                    available_saturday_slots.append((day, period))
                
                # 排课：尽可能多地在周六安排
                for _ in range(hours_needed_on_saturday):
                    if not available_saturday_slots:
                        return False, f"无法为 {class_obj.name} 的 {subject.name} 在周六安排课程，没有符合约束条件的时段"
                    
                    # 选择一个可用时段
                    day, period = available_saturday_slots.pop(0)  # 使用第一个可用时段
                    
                    # 添加课表记录
                    add_schedule_record(plan, day, period)
                    hours_scheduled += 1
                    
                    print(f"成功为 {class_obj.name} 的 {subject.name} 在周六第 {period} 节安排课程")
                
                # 如果课时不够，在其他天安排剩余课时
                remaining_hours = plan.hours_per_week - hours_scheduled
                if remaining_hours > 0:
                    print(f"{class_obj.name} 的 {subject.name} 需要在其他天安排 {remaining_hours} 课时")
                    for _ in range(remaining_hours):
                        if not schedule_class(plan, other_day_slots):
                            return False, f"无法为 {class_obj.name} 的 {subject.name} 在其他天安排剩余课时"
        
        # 处理合班课的特殊情况
        # 确保合班课在所有相关班级中使用相同的时间段
        for combo_id, combo_plans in combination_groups.items():
            # 跳过已经处理过的带"1"后缀的科目
            if is_constraint_enabled('saturday_priority'):
                any_saturday_subject = False
                for p in combo_plans:
                    subject = Subject.query.get(p.subject_id)
                    if subject.name.endswith('1') and subject.name not in saturday_exceptions:
                        any_saturday_subject = True
                        break
                
                if any_saturday_subject:
                    # 检查是否已经排课
                    if plan_hours_scheduled.get(combo_plans[0].id, 0) >= combo_plans[0].hours_per_week:
                        continue
            
            # 如果不是所有相关班级都在当前排课范围内，跳过自动排课
            all_combo_classes = set()
            for combo_plan in combo_plans:
                all_combo_classes.add(combo_plan.class_id)
            
            if not all_combo_classes.issubset(involved_class_ids):
                print(f"警告：合班ID {combo_id} 的部分班级不在当前排课范围内，跳过这些合班课的自动排课")
                continue
            
            # 获取其中一个计划的课时数(合班课应该具有相同的课时数)
            main_plan = combo_plans[0]
            hours_per_week = main_plan.hours_per_week
            
            # 开始排课
            # 先排主课在上午
            if is_constraint_enabled('major_morning') and setting.major_subjects_morning:
                subject = Subject.query.get(main_plan.subject_id)
                if subject.is_major:
                    while plan_hours_scheduled[main_plan.id] < hours_per_week:
                        if not schedule_class(main_plan, morning_slots):
                            # 如果上午时段已满，尝试在下午时段排课
                            if not schedule_class(main_plan, afternoon_slots):
                                return False, f"无法为合班课 {Subject.query.get(main_plan.subject_id).name} 安排足够的课时"
            
            # 再排其他课程
            while plan_hours_scheduled[main_plan.id] < hours_per_week:
                if not schedule_class(main_plan, slots):
                    return False, f"无法为合班课 {Subject.query.get(main_plan.subject_id).name} 安排足够的课时"
            
            # 标记其他相关计划为已排课完成
            for other_plan in combo_plans[1:]:
                plan_hours_scheduled[other_plan.id] = hours_per_week
        
        # 排除已处理的合班课计划和带"1"后缀的科目
        remaining_plans = []
        for plan in sorted_normal_plans:
            # 如果已经处理过，跳过
            if plan_hours_scheduled.get(plan.id, 0) >= plan.hours_per_week:
                continue
                
            # 跳过已处理的合班课
            if plan.is_combined and plan.combination_id in combination_groups:
                continue
                
            remaining_plans.append(plan)
        
        # 开始排课
        # 先排主课在上午
        if is_constraint_enabled('major_morning') and setting.major_subjects_morning:
            for plan in remaining_plans:
                subject = Subject.query.get(plan.subject_id)
                if subject.is_major:
                    while plan_hours_scheduled[plan.id] < plan.hours_per_week:
                        if not schedule_class(plan, morning_slots):
                            # 如果上午时段已满，尝试在下午时段排课
                            if not schedule_class(plan, afternoon_slots):
                                class_name = Class.query.get(plan.class_id).name
                                subject_name = Subject.query.get(plan.subject_id).name
                                return False, f"无法为 {class_name} 的 {subject_name} 安排足够的课时"
        
        # 再排其他课程
        for plan in remaining_plans:
            # 如果是非主科，或者尚未排满的主科
            if not plan_hours_scheduled[plan.id] >= plan.hours_per_week:
                while plan_hours_scheduled[plan.id] < plan.hours_per_week:
                    if not schedule_class(plan, slots):
                        class_name = Class.query.get(plan.class_id).name
                        subject_name = Subject.query.get(plan.subject_id).name
                        return False, f"无法为 {class_name} 的 {subject_name} 安排足够的课时"
        
        db.session.commit()
        return True, "排课成功"
    
    except Exception as e:
        db.session.rollback()
        import traceback
        print(f"自动排课错误: {str(e)}")
        print(traceback.format_exc())
        return False, str(e)

@schedule_bp.route('/schedule/saturday_subjects')
@login_required
def saturday_subjects():
    """显示所有必须排在星期六的科目（带"1"后缀的科目）"""
    # 获取所有学科
    all_subjects = Subject.query.all()
    
    # 筛选出带"1"后缀的科目
    saturday_subjects = [subject for subject in all_subjects if subject.name.endswith('1')]
    
    # 按班级分组获取已排课信息
    classes = Class.query.order_by(Class.grade, Class.name).all()
    
    # 获取排课设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
        db.session.add(setting)
        db.session.commit()
    
    # 收集所有已排课信息
    schedules_by_class = {}
    for class_obj in classes:
        # 获取该班级的课表
        class_schedule = get_class_schedule(class_obj.id, setting)
        
        # 筛选出星期六的课程
        saturday_schedules = []
        if 6 in class_schedule:  # 确保有星期六的数据
            for period, cell in class_schedule[6].items():
                if 'subject' in cell and cell['subject'].endswith('1'):
                    saturday_schedules.append({
                        'period': period,
                        'subject': cell['subject'],
                        'teacher': cell['teacher']
                    })
        
        if saturday_schedules:
            schedules_by_class[class_obj] = saturday_schedules
    
    return render_template(
        'schedule/saturday_subjects.html',
        saturday_subjects=saturday_subjects,
        schedules_by_class=schedules_by_class,
        setting=setting
    )

@schedule_bp.route('/schedule/print_settings', methods=['GET', 'POST'])
@login_required
def print_settings():
    """处理打印设置"""
    # 初始化：获取或创建打印设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
        db.session.add(setting)
        db.session.commit()
    
    # 获取或创建打印设置记录
    print_settings = PrintSetting.query.first()
    if not print_settings:
        print_settings = PrintSetting()
        db.session.add(print_settings)
        db.session.commit()
    
    if request.method == 'POST':
        # 处理基本设置
        print_settings.show_additional_info = request.form.get('show_additional_info') == 'on'
        print_settings.password = request.form.get('password', '')
        print_settings.font_size = request.form.get('font_size', '14')
        print_settings.content_adjust = request.form.get('content_adjust', 'normal')
        
        # 处理学校名称设置
        print_settings.school_name = request.form.get('school_name', '六盘水市第七中学').strip()
        
        # 处理学期设置
        print_settings.semester = request.form.get('semester', '')
        
        # 处理页面格式设置
        print_settings.row_height = request.form.get('row_height', type=int) or 45
        print_settings.column_width = request.form.get('column_width', type=int) or 27
        print_settings.title_row_height = request.form.get('title_row_height', type=int) or 25
        
        # 处理课节时间设置
        period_times = {}
        for key, value in request.form.items():
            if key.startswith('period_time_') and value.strip():
                period_num = key.replace('period_time_', '')
                period_times[period_num] = value.strip()
        
        print_settings.period_times = json.dumps(period_times, ensure_ascii=False)
        
        # 处理公共时段设置
        common_periods = {}
        common_period_names = {k.replace('common_period_name_', ''): v 
                              for k, v in request.form.items() 
                              if k.startswith('common_period_name_') and v.strip()}
        
        common_period_times = {k.replace('common_period_time_', ''): v 
                              for k, v in request.form.items() 
                              if k.startswith('common_period_time_') and v.strip()}
        
        for idx in common_period_names.keys():
            if idx in common_period_times:
                common_periods[idx] = {
                    'name': common_period_names[idx],
                    'time': common_period_times[idx]
                }
        
        print_settings.common_periods = json.dumps(common_periods, ensure_ascii=False)
        
        # 保存设置
        db.session.commit()
        
        flash('打印设置已保存', 'success')
        return redirect(url_for('schedule.view', view_type=request.form.get('view_type', 'class')))
    
    # 解析存储的设置
    try:
        period_times = json.loads(print_settings.period_times) if print_settings.period_times else {}
    except:
        period_times = {}
    
    try:
        common_periods = json.loads(print_settings.common_periods) if print_settings.common_periods else {}
    except:
        common_periods = {}
    
    return render_template('schedule/print_settings.html', 
                          settings=print_settings, 
                          period_times=period_times,
                          common_periods=common_periods,
                          setting=setting)

@schedule_bp.route('/schedule/print_class/<int:class_id>')
@login_required
def print_class_schedule(class_id):
    """显示班级课表打印预览页面"""
    # 获取班级信息
    class_obj = Class.query.get_or_404(class_id)
    
    # 获取排课设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
    
    # 获取班级课表数据
    schedule_data = get_class_schedule(class_id, setting)
    
    # 获取打印设置
    print_settings = PrintSetting.query.first()
    if not print_settings:
        print_settings = PrintSetting()
        db.session.add(print_settings)
        db.session.commit()
    
    # 解析打印设置
    try:
        period_times = json.loads(print_settings.period_times) if print_settings.period_times else {}
    except:
        period_times = {}
    
    try:
        common_periods = json.loads(print_settings.common_periods) if print_settings.common_periods else {}
    except:
        common_periods = {}
    
    return render_template('schedule/print_preview.html', 
                          class_obj=class_obj, 
                          schedule_data=schedule_data, 
                          setting=setting,
                          print_settings=print_settings,
                          period_times=period_times,
                          common_periods=common_periods,
                          view_type='class')

@schedule_bp.route('/schedule/print_teacher/<int:teacher_id>')
@login_required
def print_teacher_schedule(teacher_id):
    """显示教师课表打印预览页面"""
    # 获取教师信息
    teacher = Teacher.query.get_or_404(teacher_id)
    
    # 获取排课设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
    
    # 获取教师课表数据
    schedule_data = get_teacher_schedule(teacher_id, setting)
    
    # 获取打印设置
    print_settings = PrintSetting.query.first()
    if not print_settings:
        print_settings = PrintSetting()
        db.session.add(print_settings)
        db.session.commit()
    
    # 解析打印设置
    try:
        period_times = json.loads(print_settings.period_times) if print_settings.period_times else {}
    except:
        period_times = {}
    
    try:
        common_periods = json.loads(print_settings.common_periods) if print_settings.common_periods else {}
    except:
        common_periods = {}
    
    return render_template('schedule/print_preview.html', 
                          teacher=teacher, 
                          schedule_data=schedule_data, 
                          setting=setting,
                          print_settings=print_settings,
                          period_times=period_times,
                          common_periods=common_periods,
                          view_type='teacher')

@schedule_bp.route('/schedule/export_excel/<int:class_id>')
@login_required
def export_class_excel(class_id):
    """导出班级课表为Excel格式，参照标准模板设计"""
    # 获取班级信息
    class_obj = Class.query.get_or_404(class_id)
    
    # 获取排课设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
    
    # 获取打印设置
    print_settings = PrintSetting.query.first()
    if not print_settings:
        print_settings = PrintSetting()
    
    # 解析打印设置中的课节时间和公共时段
    try:
        period_times = json.loads(print_settings.period_times) if print_settings.period_times else {}
    except:
        period_times = {}
    
    try:
        common_periods = json.loads(print_settings.common_periods) if print_settings.common_periods else {}
    except:
        common_periods = {}
    
    # 获取包含早晚自习的班级课表数据
    schedule_data = get_class_schedule_with_selfstudy(class_id, setting)
    
    # 创建Excel文件
    output = io.BytesIO()
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet(f"{class_obj.name}课表")
    
    # 定义格式
    # 主标题格式
    main_title_format = workbook.add_format({
        'bold': True, 
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 18,
        'font_name': '宋体'
    })
    
    # 副标题格式
    sub_title_format = workbook.add_format({
        'bold': True,
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 16,
        'font_name': '宋体'
    })
    
    # 日期和班主任信息格式
    info_left_format = workbook.add_format({
        'align': 'left',
        'valign': 'vcenter',
        'font_size': 12,
        'font_name': '宋体'
    })
    
    info_right_format = workbook.add_format({
        'align': 'right',
        'valign': 'vcenter',
        'font_size': 12,
        'font_name': '宋体'
    })
    
    # 表头格式
    header_format = workbook.add_format({
        'bold': True, 
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 12,
        'font_name': '宋体',
        'border': 1,
        'bg_color': '#F2F2F2'
    })
    
    # 时间列格式
    time_format = workbook.add_format({
        'bold': True,
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 11,
        'font_name': '宋体',
        'border': 1,
        'text_wrap': True
    })
    
    # 课程内容格式
    cell_format = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 11,
        'font_name': '宋体',
        'border': 1,
        'text_wrap': True
    })
    
    # 早晚自习格式
    selfstudy_format = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 11,
        'font_name': '宋体',
        'border': 1,
        'text_wrap': True,
        'bg_color': '#E8F5E8'
    })
    
    # 公共活动格式
    activity_format = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 11,
        'font_name': '宋体',
        'border': 1,
        'text_wrap': True,
        'bg_color': '#FFF2CC'
    })
    
    # 设置列宽
    worksheet.set_column(0, 0, print_settings.column_width or 27)  # 时间列设置为配置的宽度
    worksheet.set_column(1, 7, print_settings.column_width or 27)  # 星期列设置为配置的宽度
    
    current_row = 0
    
    # 主标题：学校和学期信息
    # 获取学校名称（优先使用设置中的，如果没有则使用默认值）
    school_name = print_settings.school_name if print_settings.school_name and print_settings.school_name.strip() else "六盘水市第七中学"
    # 默认学期
    default_semester = "2025年春季学期"
    
    # 构建完整的标题
    if print_settings.semester and print_settings.semester.strip():
        # 如果设置了学期，使用设置的学期
        school_semester = f"{school_name}{print_settings.semester}"
    else:
        # 如果没有设置学期，使用默认学期
        school_semester = f"{school_name}{default_semester}"
    
    worksheet.merge_range(current_row, 0, current_row, 7, school_semester, main_title_format)
    current_row += 1
    
    # 副标题：班级课程表
    class_title = f"{class_obj.name} 班级课程表"
    worksheet.merge_range(current_row, 0, current_row, 7, class_title, sub_title_format)
    current_row += 1
    
    # 空行
    current_row += 1
    
    # 执行日期和班主任信息
    today = datetime.now().strftime("%Y年%m月%d日")
    execution_date = f"课表执行日期：{today}"
    head_teacher_info = f"班主任：{class_obj.head_teacher.name if class_obj.head_teacher else '未设置'}"
    
    worksheet.write(current_row, 0, execution_date, info_left_format)
    worksheet.merge_range(current_row, 5, current_row, 7, head_teacher_info, info_right_format)
    current_row += 1
    
    # 空行
    current_row += 1
    
    # 表头
    headers = ['星期/节数', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
    for col, header in enumerate(headers):
        worksheet.write(current_row, col, header, header_format)
    current_row += 1
    
    # 定义标准时间表（参照模板）
    time_schedule = [
        (-1, '早读1\n7:20-7:40', True),  # 早晚自习
        (1, '上午第一节\n7:50-8:30', False),
        (2, '上午第二节\n8:40-9:20', False),
        ('break1', '阳光体育（课间操）\n9:20-10:00', 'activity'),  # 公共活动
        (3, '上午第三节\n10:00-10:40', False),
        (4, '上午第四节\n10:50-11:30', False),
        (5, '上午第五节\n11:40-12:20', False),
        ('lunch', '午休\n12:20-14:30', 'activity'),  # 午休
        (6, '下午第一节\n14:30-15:10', False),
        ('break2', '眼保健操\n15:10-15:15', 'activity'),  # 眼保健操
        (7, '下午第二节\n15:25-16:05', False),
        (8, '下午第三节\n16:15-16:55', False),
        (9, '下午第四节\n17:05-17:45', False),
        (setting.periods_per_day + 1, '晚修1\n19:00-22:30', True),  # 晚自习
    ]
    
    # 如果有自定义时间，使用自定义时间更新
    if period_times:
        for i, (period_num, period_label, is_selfstudy) in enumerate(time_schedule):
            if isinstance(period_num, int) and period_num > 0 and period_num <= setting.periods_per_day:
                if str(period_num) in period_times:
                    # 保持原有标签，只更新时间
                    base_label = period_label.split('\n')[0]
                    time_schedule[i] = (period_num, f"{base_label}\n{period_times[str(period_num)]}", is_selfstudy)
    
    # 写入课程表数据
    for period_num, period_label, format_type in time_schedule:
        # 写入时间列
        worksheet.write(current_row, 0, period_label, time_format)
        
        # 写入课程内容
        for day in range(1, 8):  # 星期一到星期日
            cell_text = ''
            current_format = cell_format
            
            if format_type == 'activity':
                # 公共活动时段，所有班级都显示相同内容
                if period_num == 'break1':
                    cell_text = '阳光体育\n（课间操）'
                elif period_num == 'lunch':
                    cell_text = '午休'
                elif period_num == 'break2':
                    cell_text = '眼保健操'
                current_format = activity_format
            elif isinstance(period_num, int):
                # 获取课程数据
                cell_data = schedule_data.get(day, {}).get(period_num, '')
                
                if cell_data:
                    cell_text = f"{cell_data['subject']}\n{cell_data['teacher']}"
                    if cell_data.get('is_combined', False):
                        cell_text += "\n(合班)"
                    if cell_data.get('is_common_course', False):
                        cell_text += "\n(公共课程)"
                    
                    # 选择格式
                    if format_type == True:  # 早晚自习
                        current_format = selfstudy_format
                    elif day == 6 and isinstance(cell_data, dict) and 'subject' in cell_data and cell_data['subject'].endswith('1'):
                        # 星期六的"1"结尾科目
                        current_format = selfstudy_format
                else:
                    # 空白时段
                    if format_type == True:  # 早晚自习时段但没有安排
                        current_format = selfstudy_format
            
            worksheet.write(current_row, day, cell_text, current_format)
        
        current_row += 1
    
    # 设置行高
    title_row_height = print_settings.title_row_height or 25
    row_height = print_settings.row_height or 45
    
    for row in range(current_row):
        if row <= 4:  # 标题行
            worksheet.set_row(row, title_row_height)
        else:  # 表格行
            worksheet.set_row(row, row_height)
    
    # 设置页面布局为横向A4纸张
    worksheet.set_landscape()  # 设置为横向
    worksheet.set_paper(9)     # A4纸张 (xlsxwriter中A4纸张代码为9)
    worksheet.fit_to_pages(1, 1)  # 缩放到一页打印
    worksheet.set_margins(0.5, 0.5, 0.75, 0.75)  # 设置页边距：左、右、上、下
    
    # 设置打印选项
    worksheet.set_header('&C&"微软雅黑,Bold"&18课程表')  # 页眉
    worksheet.set_footer('&C第&P页 共&N页')  # 页脚
    
    workbook.close()
    
    # 准备响应
    output.seek(0)
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'{class_obj.name}_课程表.xlsx'
    )

@schedule_bp.route('/schedule/export_excel_teacher/<int:teacher_id>')
@login_required
def export_teacher_excel(teacher_id):
    """导出教师课表为Excel格式，包含早晚自习"""
    # 获取教师信息
    teacher = Teacher.query.get_or_404(teacher_id)
    
    # 获取排课设置
    setting = ScheduleSetting.query.first()
    if not setting:
        setting = ScheduleSetting()
    
    # 获取打印设置
    print_setting = PrintSetting.query.first()
    if not print_setting:
        print_setting = PrintSetting()
    
    # 获取包含早晚自习的教师课表数据
    schedule_data = get_teacher_schedule_with_selfstudy(teacher_id, setting)
    
    # 创建Excel文件
    output = io.BytesIO()
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet(f"{teacher.name}课表")
    
    # 添加标题格式
    title_format = workbook.add_format({
        'bold': True, 
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 16,
        'font_name': '宋体',
        'bg_color': '#D9E1F2',
        'border': 1
    })
    
    # 添加副标题格式
    subtitle_format = workbook.add_format({
        'bold': True,  # 确保副标题也加粗
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 16,
        'font_name': '宋体',
        'border': 1  # 添加边框
    })
    
    # 添加表头格式 - 新增专门的表头格式
    header_format = workbook.add_format({
        'bold': True, 
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 16,
        'font_name': '宋体',
        'bg_color': '#E9ECF1',
        'border': 1
    })
    
    # 添加内容格式
    cell_format = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'text_wrap': True,
        'border': 1,
        'font_size': 16,
        'font_name': '宋体'
    })
    
    # 早晚自习格式
    selfstudy_format = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'text_wrap': True,
        'border': 1,
        'font_size': 16,
        'font_name': '宋体',
        'bg_color': '#E8F5E8'  # 浅绿色背景区分早晚自习
    })
    
    # 设置列宽
    worksheet.set_column(0, 0, 27)  # 时间列设置为27字符
    worksheet.set_column(1, 7, 27)  # 星期列设置为27字符
    
    current_row = 0
    
    # 合并标题单元格 - 教师姓名和课表标题
    worksheet.merge_range(current_row, 0, current_row, setting.days_per_week, f"{teacher.name} 完整教师课表", title_format)
    current_row += 1
    
    # 添加学期信息（如果有）
    print_setting = PrintSetting.query.first()
    if print_setting and print_setting.semester:
        worksheet.merge_range(current_row, 0, current_row, setting.days_per_week, print_setting.semester, subtitle_format)
        current_row += 1
    
    # 添加教师科目信息
    subject_names = [subject.name for subject in teacher.subjects]
    if subject_names:
        worksheet.merge_range(current_row, 0, current_row, setting.days_per_week, 
                             f"教授科目: {', '.join(subject_names)}", subtitle_format)
        current_row += 1
    
    # 空行
    current_row += 1
    
    # 写入表头
    header = ['时间']
    for d in range(1, setting.days_per_week + 1):
        day_names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
        header.append(day_names[d-1])
    
    for col, title in enumerate(header):
        worksheet.write(current_row, col, title, header_format)  # 使用专门的表头格式
    
    # 设置行高 - 表头16磅，其他行60磅
    worksheet.set_row(current_row, 16)  # 表头行设置为16磅
    
    # 创建完整的时段列表（包含早晚自习）
    all_periods = []
    
    # 添加早读
    all_periods.append((-1, '早读'))
    
    # 添加正常课时
    for p in range(1, setting.periods_per_day + 1):
        period_label = f"{'上午' if p <= setting.morning_periods else '下午'} 第{p if p <= setting.morning_periods else p - setting.morning_periods}节"
        all_periods.append((p, period_label))
    
    # 添加晚修
    all_periods.append((setting.periods_per_day + 1, '晚修'))
    
    # 写入课表数据
    row_index = current_row + 1
    for period_num, period_label in all_periods:
        # 时间列也使用加粗格式
        time_cell_format = workbook.add_format({
            'bold': True,  # 加粗
            'align': 'center',
            'valign': 'vcenter',
            'text_wrap': True,
            'border': 1,
            'font_size': 16,
            'font_name': '宋体'
        })
        worksheet.write(row_index, 0, period_label, time_cell_format)
        
        for d in range(1, setting.days_per_week + 1):
            cell_data = schedule_data.get(d, {}).get(period_num, '')
            cell_text = ''
            
            # 选择合适的格式
            current_format = cell_format
            
            if cell_data:
                if isinstance(cell_data, dict):
                    cell_text = f"{cell_data['subject']}\n{cell_data['teacher']}"
                    
                    # 如果是早晚自习，使用特殊格式
                    if cell_data.get('is_selfstudy', False):
                        current_format = selfstudy_format
                else:
                    cell_text = cell_data
            
            worksheet.write(row_index, d, cell_text, current_format)
        
        row_index += 1
    
    # 最后设置所有行的行高
    for row in range(current_row + 1, row_index):  # 数据行设置为60磅
        worksheet.set_row(row, 60)
    
    # 设置页面布局为横向A4纸张
    worksheet.set_landscape()  # 设置为横向
    worksheet.set_paper(9)     # A4纸张 (xlsxwriter中A4纸张代码为9)
    worksheet.fit_to_pages(1, 1)  # 缩放到一页打印
    worksheet.set_margins(0.5, 0.5, 0.75, 0.75)  # 设置页边距：左、右、上、下
    
    # 设置打印选项
    worksheet.set_header('&C&"微软雅黑,Bold"&18教师课表')  # 页眉
    worksheet.set_footer('&C第&P页 共&N页')  # 页脚
    
    workbook.close()
    
    # 准备响应
    output.seek(0)
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'{teacher.name}_完整课表.xlsx'
    )

@schedule_bp.route('/schedule/batch_export', methods=['POST'])
@login_required
def batch_export():
    """批量导出多个课表"""
    export_type = request.form.get('export_type')
    selected_ids = request.form.getlist('selected_ids[]', type=int)
    
    if not selected_ids:
        flash('请选择要导出的项目', 'warning')
        return redirect(url_for('schedule.view'))
    
    # 创建一个临时目录存放生成的文件
    temp_dir = os.path.join(os.getcwd(), 'temp_export')
    os.makedirs(temp_dir, exist_ok=True)
    
    # 创建ZIP文件
    zip_filename = f'课表批量导出_{datetime.now().strftime("%Y%m%d%H%M%S")}.zip'
    zip_path = os.path.join(temp_dir, zip_filename)
    
    # 获取排课设置
    setting = ScheduleSetting.query.first() or ScheduleSetting()
    
    # 获取打印设置
    print_settings = PrintSetting.query.first()
    if not print_settings:
        print_settings = PrintSetting()
    
    # 解析打印设置中的课节时间和公共时段
    try:
        period_times = json.loads(print_settings.period_times) if print_settings.period_times else {}
    except:
        period_times = {}
    
    try:
        common_periods = json.loads(print_settings.common_periods) if print_settings.common_periods else {}
    except:
        common_periods = {}
    
    with zipfile.ZipFile(zip_path, 'w') as zipf:
        if export_type == 'class':
            # 批量导出班级课表
            for class_id in selected_ids:
                class_obj = Class.query.get(class_id)
                if class_obj:
                    # 获取包含早晚自习的班级课表数据
                    schedule_data = get_class_schedule_with_selfstudy(class_id, setting)
                    
                    # 创建Excel文件
                    excel_filename = f'{class_obj.name}_课程表.xlsx'
                    excel_path = os.path.join(temp_dir, excel_filename)
                    
                    # 生成Excel文件
                    workbook = xlsxwriter.Workbook(excel_path)
                    worksheet = workbook.add_worksheet(f"{class_obj.name}课表")
                    
                    # 定义格式（与单个导出保持一致）
                    main_title_format = workbook.add_format({
                        'bold': True, 'align': 'center', 'valign': 'vcenter',
                        'font_size': 18, 'font_name': '宋体'
                    })
                    sub_title_format = workbook.add_format({
                        'bold': True, 'align': 'center', 'valign': 'vcenter',
                        'font_size': 16, 'font_name': '宋体'
                    })
                    info_left_format = workbook.add_format({
                        'align': 'left', 'valign': 'vcenter',
                        'font_size': 12, 'font_name': '宋体'
                    })
                    info_right_format = workbook.add_format({
                        'align': 'right', 'valign': 'vcenter',
                        'font_size': 12, 'font_name': '宋体'
                    })
                    header_format = workbook.add_format({
                        'bold': True, 'align': 'center', 'valign': 'vcenter',
                        'font_size': 12, 'font_name': '宋体', 'border': 1, 'bg_color': '#F2F2F2'
                    })
                    time_format = workbook.add_format({
                        'bold': True, 'align': 'center', 'valign': 'vcenter',
                        'font_size': 11, 'font_name': '宋体', 'border': 1, 'text_wrap': True
                    })
                    cell_format = workbook.add_format({
                        'align': 'center', 'valign': 'vcenter', 'font_size': 11,
                        'font_name': '宋体', 'border': 1, 'text_wrap': True
                    })
                    selfstudy_format = workbook.add_format({
                        'align': 'center', 'valign': 'vcenter', 'font_size': 11,
                        'font_name': '宋体', 'border': 1, 'text_wrap': True, 'bg_color': '#E8F5E8'
                    })
                    activity_format = workbook.add_format({
                        'align': 'center', 'valign': 'vcenter', 'font_size': 11,
                        'font_name': '宋体', 'border': 1, 'text_wrap': True, 'bg_color': '#FFF2CC'
                    })
                    
                    # 设置列宽
                    worksheet.set_column(0, 0, print_settings.column_width or 27)  # 时间列设置为配置的宽度
                    worksheet.set_column(1, 7, print_settings.column_width or 27)  # 星期列设置为配置的宽度
                    
                    current_row = 0
                    
                    # 主标题：学校和学期信息
                    # 获取学校名称（优先使用设置中的，如果没有则使用默认值）
                    school_name = print_settings.school_name if print_settings.school_name and print_settings.school_name.strip() else "六盘水市第七中学"
                    # 默认学期
                    default_semester = "2025年春季学期"
                    
                    # 构建完整的标题
                    if print_settings.semester and print_settings.semester.strip():
                        # 如果设置了学期，使用设置的学期
                        school_semester = f"{school_name}{print_settings.semester}"
                    else:
                        # 如果没有设置学期，使用默认学期
                        school_semester = f"{school_name}{default_semester}"
                    
                    worksheet.merge_range(current_row, 0, current_row, 7, school_semester, main_title_format)
                    current_row += 1
                    
                    # 副标题：班级课程表
                    class_title = f"{class_obj.name} 班级课程表"
                    worksheet.merge_range(current_row, 0, current_row, 7, class_title, sub_title_format)
                    current_row += 1
                    
                    # 空行
                    current_row += 1
                    
                    # 执行日期和班主任信息
                    today = datetime.now().strftime("%Y年%m月%d日")
                    execution_date = f"课表执行日期：{today}"
                    head_teacher_info = f"班主任：{class_obj.head_teacher.name if class_obj.head_teacher else '未设置'}"
                    
                    worksheet.write(current_row, 0, execution_date, info_left_format)
                    worksheet.merge_range(current_row, 5, current_row, 7, head_teacher_info, info_right_format)
                    current_row += 1
                    
                    # 空行
                    current_row += 1
                    
                    # 表头
                    headers = ['星期/节数', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
                    for col, header in enumerate(headers):
                        worksheet.write(current_row, col, header, header_format)
                    current_row += 1
                    
                    # 定义标准时间表（与单个导出保持一致）
                    time_schedule = [
                        (-1, '早读1\n7:20-7:40', True),
                        (1, '上午第一节\n7:50-8:30', False),
                        (2, '上午第二节\n8:40-9:20', False),
                        ('break1', '阳光体育（课间操）\n9:20-10:00', 'activity'),
                        (3, '上午第三节\n10:00-10:40', False),
                        (4, '上午第四节\n10:50-11:30', False),
                        (5, '上午第五节\n11:40-12:20', False),
                        ('lunch', '午休\n12:20-14:30', 'activity'),
                        (6, '下午第一节\n14:30-15:10', False),
                        ('break2', '眼保健操\n15:10-15:15', 'activity'),
                        (7, '下午第二节\n15:25-16:05', False),
                        (8, '下午第三节\n16:15-16:55', False),
                        (9, '下午第四节\n17:05-17:45', False),
                        (setting.periods_per_day + 1, '晚修1\n19:00-22:30', True),
                    ]
                    
                    # 如果有自定义时间，使用自定义时间更新
                    if period_times:
                        for i, (period_num, period_label, format_type) in enumerate(time_schedule):
                            if isinstance(period_num, int) and period_num > 0 and period_num <= setting.periods_per_day:
                                if str(period_num) in period_times:
                                    base_label = period_label.split('\n')[0]
                                    time_schedule[i] = (period_num, f"{base_label}\n{period_times[str(period_num)]}", format_type)
                    
                    # 写入课程表数据
                    for period_num, period_label, format_type in time_schedule:
                        # 写入时间列
                        worksheet.write(current_row, 0, period_label, time_format)
                        
                        # 写入课程内容
                        for day in range(1, 8):
                            cell_text = ''
                            current_format = cell_format
                            
                            if format_type == 'activity':
                                # 公共活动时段
                                if period_num == 'break1':
                                    cell_text = '阳光体育\n（课间操）'
                                elif period_num == 'lunch':
                                    cell_text = '午休'
                                elif period_num == 'break2':
                                    cell_text = '眼保健操'
                                current_format = activity_format
                            elif isinstance(period_num, int):
                                # 获取课程数据
                                cell_data = schedule_data.get(day, {}).get(period_num, '')
                                
                                if cell_data:
                                    cell_text = f"{cell_data['subject']}\n{cell_data['teacher']}"
                                    if cell_data.get('is_combined', False):
                                        cell_text += "\n(合班)"
                                    if cell_data.get('is_common_course', False):
                                        cell_text += "\n(公共课程)"
                                        
                                    # 选择格式
                                    if format_type == True:
                                        current_format = selfstudy_format
                                    elif day == 6 and isinstance(cell_data, dict) and 'subject' in cell_data and cell_data['subject'].endswith('1'):
                                        current_format = selfstudy_format
                                else:
                                    if format_type == True:
                                        current_format = selfstudy_format
                            
                            worksheet.write(current_row, day, cell_text, current_format)
                        
                        current_row += 1
                    
                    # 设置行高
                    title_row_height = print_settings.title_row_height or 25
                    row_height = print_settings.row_height or 45
                    
                    for row in range(current_row):
                        if row <= 4:  # 标题行
                            worksheet.set_row(row, title_row_height)
                        else:  # 表格行
                            worksheet.set_row(row, row_height)
                    
                    # 设置页面布局为横向A4纸张
                    worksheet.set_landscape()  # 设置为横向
                    worksheet.set_paper(9)     # A4纸张 (xlsxwriter中A4纸张代码为9)
                    worksheet.fit_to_pages(1, 1)  # 缩放到一页打印
                    worksheet.set_margins(0.5, 0.5, 0.75, 0.75)  # 设置页边距：左、右、上、下
                    
                    # 设置打印选项
                    worksheet.set_header('&C&"微软雅黑,Bold"&18课程表')  # 页眉
                    worksheet.set_footer('&C第&P页 共&N页')  # 页脚
                    
                    workbook.close()
                    
                    # 添加到ZIP文件
                    zipf.write(excel_path, excel_filename)
                    
                    # 删除临时Excel文件
                    os.remove(excel_path)
        
        elif export_type == 'teacher':
            # 批量导出教师课表
            for teacher_id in selected_ids:
                teacher = Teacher.query.get(teacher_id)
                if teacher:
                    # 获取包含早晚自习的教师课表数据
                    schedule_data = get_teacher_schedule_with_selfstudy(teacher_id, setting)
                    
                    # 创建Excel文件
                    excel_filename = f'{teacher.name}_完整课表.xlsx'
                    excel_path = os.path.join(temp_dir, excel_filename)
                    
                    # 生成Excel文件
                    workbook = xlsxwriter.Workbook(excel_path)
                    worksheet = workbook.add_worksheet(f"{teacher.name}课表")
                    
                    # 添加格式
                    title_format = workbook.add_format({
                        'bold': True, 'align': 'center', 'valign': 'vcenter',
                        'font_size': 16, 'font_name': '宋体', 'bg_color': '#D9E1F2', 'border': 1
                    })
                    header_format = workbook.add_format({
                        'bold': True, 'align': 'center', 'valign': 'vcenter',
                        'font_size': 16, 'font_name': '宋体', 'bg_color': '#E9ECF1', 'border': 1
                    })
                    cell_format = workbook.add_format({
                        'align': 'center', 'valign': 'vcenter',
                        'text_wrap': True, 'border': 1,
                        'font_size': 16, 'font_name': '宋体'
                    })
                    selfstudy_format = workbook.add_format({
                        'align': 'center', 'valign': 'vcenter',
                        'text_wrap': True,
                        'bg_color': '#E8F5E8', 'font_size': 16, 'font_name': '宋体',
                        'border': 1  # 添加边框
                    })
                    subtitle_format = workbook.add_format({
                        'bold': True,  # 添加加粗
                        'align': 'center', 'valign': 'vcenter',
                        'font_size': 16, 'font_name': '宋体', 'italic': True, 'font_color': '#666666',
                        'border': 1  # 添加边框
                    })
                    info_format = workbook.add_format({
                        'align': 'left', 'valign': 'vcenter',
                        'font_size': 16, 'font_name': '宋体', 'font_color': '#666666',
                        'border': 1  # 添加边框
                    })
                    
                    # 合并标题单元格
                    worksheet.merge_range(0, 0, 0, setting.days_per_week, f"{teacher.name} 完整教师课表", title_format)
                    
                    # 添加学期信息（如果有）
                    if print_settings.semester:
                        worksheet.merge_range(1, 0, 1, setting.days_per_week, print_settings.semester, subtitle_format)
                        start_row = 2
                    else:
                        start_row = 1
                    
                    # 添加教师科目信息
                    subject_names = [subject.name for subject in teacher.subjects]
                    if subject_names and print_settings.show_additional_info:
                        worksheet.merge_range(start_row, 0, start_row, setting.days_per_week, 
                                             f"教授科目: {', '.join(subject_names)}", subtitle_format)
                        start_row += 1
                    
                    # 设置列宽和写入表头
                    worksheet.set_column(0, 0, print_settings.column_width or 27)  # 时间列设置为配置的宽度
                    worksheet.set_column(1, setting.days_per_week, print_settings.column_width or 27)  # 星期列设置为配置的宽度
                    
                    header = ['时间']
                    for d in range(1, setting.days_per_week + 1):
                        day_names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
                        header.append(day_names[d-1])
                    
                    for col, title in enumerate(header):
                        worksheet.write(start_row, col, title, header_format)
                    
                    # 设置表头行高为16磅
                    worksheet.set_row(start_row, 16)
                    
                    # 创建完整的时段列表（包含早晚自习）
                    all_periods = []
                    
                    # 添加早读
                    all_periods.append((-1, '早读'))
                    
                    # 添加正常课时
                    for p in range(1, setting.periods_per_day + 1):
                        period_label = f"{'上午' if p <= setting.morning_periods else '下午'} 第{p if p <= setting.morning_periods else p - setting.morning_periods}节"
                        if str(p) in period_times:
                            period_label += f"\n{period_times[str(p)]}"
                        all_periods.append((p, period_label))
                    
                    # 添加晚修
                    all_periods.append((setting.periods_per_day + 1, '晚修'))
                    
                    # 写入课表数据
                    row_index = start_row + 1
                    for period_num, period_label in all_periods:
                        # 时间列使用加粗格式
                        time_cell_format = workbook.add_format({
                            'bold': True,  # 加粗
                            'align': 'center',
                            'valign': 'vcenter',
                            'text_wrap': True,
                            'border': 1,
                            'font_size': 16,
                            'font_name': '宋体'
                        })
                        worksheet.write(row_index, 0, period_label, time_cell_format)
                        
                        for d in range(1, setting.days_per_week + 1):
                            cell_data = schedule_data.get(d, {}).get(period_num, '')
                            cell_text = ''
                            current_format = cell_format
                            
                            if cell_data:
                                if isinstance(cell_data, dict):
                                    cell_text = f"{cell_data['subject']}\n{cell_data['teacher']}"
                                    
                                    # 如果是早晚自习，使用特殊格式
                                    if cell_data.get('is_selfstudy', False):
                                        current_format = selfstudy_format
                                else:
                                    cell_text = cell_data
                            
                            worksheet.write(row_index, d, cell_text, current_format)
                        
                        row_index += 1
                    
                    # 设置行高 - 表头16磅，其他行60磅
                    worksheet.set_row(start_row, 16)  # 表头行设置为16磅
                    for row in range(start_row + 1, row_index):  # 其他行设置为60磅
                        worksheet.set_row(row, 60)
                    
                    # 设置页面布局为横向A4纸张
                    worksheet.set_landscape()  # 设置为横向
                    worksheet.set_paper(9)     # A4纸张 (xlsxwriter中A4纸张代码为9)
                    worksheet.fit_to_pages(1, 1)  # 缩放到一页打印
                    worksheet.set_margins(0.5, 0.5, 0.75, 0.75)  # 设置页边距：左、右、上、下
                    
                    # 设置打印选项
                    worksheet.set_header('&C&"微软雅黑,Bold"&18教师课表')  # 页眉
                    worksheet.set_footer('&C第&P页 共&N页')  # 页脚
                    
                    workbook.close()
                    
                    # 添加到ZIP文件
                    zipf.write(excel_path, excel_filename)
                    
                    # 删除临时Excel文件
                    os.remove(excel_path)
    
    # 读取ZIP文件并作为响应返回
    with open(zip_path, 'rb') as f:
        data = f.read()
    
    # 删除临时ZIP文件
    os.remove(zip_path)
    
    return send_file(
        io.BytesIO(data),
        mimetype='application/zip',
        as_attachment=True,
        download_name=zip_filename
    )

def get_class_schedule_with_selfstudy(class_id, setting):
    """获取指定班级的课表数据，包含早晚自习"""
    from models import SelfStudySchedule  # 避免循环导入
    
    # 获取正常课表数据
    schedule_data = get_class_schedule(class_id, setting)
    
    # 获取早晚自习数据
    selfstudy_schedules = SelfStudySchedule.query.filter_by(class_id=class_id).all()
    
    # 定义早晚自习时段映射
    selfstudy_periods = {
        '早读1': {'display': '早读', 'order': -1},  # 早读排在第一节课之前
        '晚修1': {'display': '晚修', 'order': setting.periods_per_day + 1},  # 晚修排在最后一节课之后
    }
    
    # 为早晚自习创建额外的时段
    for selfstudy in selfstudy_schedules:
        day = selfstudy.day
        period_info = selfstudy_periods.get(selfstudy.period)
        
        if period_info:
            virtual_period = period_info['order']
            
            if day not in schedule_data:
                schedule_data[day] = {}
            
            if selfstudy.is_common_course:
                # 公共课程
                schedule_data[day][virtual_period] = {
                    'subject': selfstudy.common_course_title,
                    'teacher': '公共课程',
                    'teacher_id': 0,
                    'is_combined': False,
                    'is_common_course': True,
                    'is_selfstudy': True,
                    'period_display': period_info['display']
                }
            else:
                # 普通早晚自习
                schedule_data[day][virtual_period] = {
                    'subject': selfstudy.subject.name if selfstudy.subject else '',
                    'teacher': selfstudy.teacher.name if selfstudy.teacher else '',
                    'teacher_id': selfstudy.teacher.id if selfstudy.teacher else 0,
                    'is_combined': False,
                    'is_common_course': False,
                    'is_selfstudy': True,
                    'period_display': period_info['display']
                }
    
    return schedule_data

def get_teacher_schedule_with_selfstudy(teacher_id, setting):
    """获取指定教师的课表数据，包含早晚自习"""
    from models import SelfStudySchedule, SelfStudyPlan  # 避免循环导入
    
    # 获取正常课表数据
    schedule_data = get_teacher_schedule(teacher_id, setting)
    
    # 获取教师的早晚自习数据
    selfstudy_schedules = SelfStudySchedule.query.join(SelfStudyPlan).filter(
        SelfStudyPlan.teacher_id == teacher_id,
        SelfStudySchedule.plan_id == SelfStudyPlan.id,
        SelfStudySchedule.is_common_course == False
    ).all()
    
    # 定义早晚自习时段映射
    selfstudy_periods = {
        '早读1': {'display': '早读', 'order': -1},
        '晚修1': {'display': '晚修', 'order': setting.periods_per_day + 1},
    }
    
    # 为早晚自习创建额外的时段
    for selfstudy in selfstudy_schedules:
        day = selfstudy.day
        period_info = selfstudy_periods.get(selfstudy.period)
        
        if period_info:
            virtual_period = period_info['order']
            
            if day not in schedule_data:
                schedule_data[day] = {}
            
            schedule_data[day][virtual_period] = {
                'subject': selfstudy.subject.name if selfstudy.subject else '',
                'teacher': selfstudy.class_obj.name,  # 对于教师视图，显示班级名称
                'class_id': selfstudy.class_id,
                'subject_id': selfstudy.subject.id if selfstudy.subject else 0,
                'is_combined': False,
                'is_selfstudy': True,
                'period_display': period_info['display']
            }
    
    return schedule_data