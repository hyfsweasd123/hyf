from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from werkzeug.security import generate_password_hash
from database import db
from models import User

users_bp = Blueprint('users', __name__)

@users_bp.route('/users')
@login_required
def index():
    if current_user.role != 'admin':
        flash('您没有权限访问此页面!', 'danger')
        return redirect(url_for('dashboard'))
    
    users = User.query.all()
    return render_template('users/index.html', users=users)

@users_bp.route('/users/new', methods=['GET', 'POST'])
@login_required
def new():
    if current_user.role != 'admin':
        flash('您没有权限访问此页面!', 'danger')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        name = request.form.get('name')
        role = request.form.get('role')
        
        # 检查用户名是否已存在
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('用户名已存在!', 'danger')
            return render_template('users/new.html')
        
        user = User(
            username=username,
            password=generate_password_hash(password),
            name=name,
            role=role
        )
        
        db.session.add(user)
        db.session.commit()
        
        flash('用户创建成功!', 'success')
        return redirect(url_for('users.index'))
    
    return render_template('users/new.html')

@users_bp.route('/users/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    if current_user.role != 'admin':
        flash('您没有权限访问此页面!', 'danger')
        return redirect(url_for('dashboard'))
    
    user = User.query.get_or_404(id)
    
    if request.method == 'POST':
        name = request.form.get('name')
        role = request.form.get('role')
        password = request.form.get('password')
        
        user.name = name
        user.role = role
        
        if password:  # 仅当提供了新密码时才更新密码
            user.password = generate_password_hash(password)
        
        db.session.commit()
        
        flash('用户更新成功!', 'success')
        return redirect(url_for('users.index'))
    
    return render_template('users/edit.html', user=user)

@users_bp.route('/users/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    if current_user.role != 'admin':
        flash('您没有权限访问此页面!', 'danger')
        return redirect(url_for('dashboard'))
    
    user = User.query.get_or_404(id)
    
    # 检查是否删除当前用户或唯一管理员
    if user.id == current_user.id:
        flash('不能删除当前登录的用户!', 'danger')
        return redirect(url_for('users.index'))
    
    admin_count = User.query.filter_by(role='admin').count()
    if user.role == 'admin' and admin_count <= 1:
        flash('不能删除唯一的管理员用户!', 'danger')
        return redirect(url_for('users.index'))
    
    db.session.delete(user)
    db.session.commit()
    
    flash('用户删除成功!', 'success')
    return redirect(url_for('users.index')) 