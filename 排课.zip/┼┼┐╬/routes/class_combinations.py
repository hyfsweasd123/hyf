from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from database import db
from models import ClassCombination, Class, Subject

combinations_bp = Blueprint('combinations', __name__)

@combinations_bp.route('/combinations')
@login_required
def index():
    combinations = ClassCombination.query.all()
    return render_template('combinations/index.html', combinations=combinations)

@combinations_bp.route('/combinations/new', methods=['GET', 'POST'])
@login_required
def new():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('combinations.index'))
    
    classes = Class.query.order_by(Class.grade).all()
    subjects = Subject.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        subject_id = request.form.get('subject_id', type=int)
        class_ids = request.form.getlist('classes', type=int)
        
        # 检查是否选择了学科和至少两个班级
        if not subject_id:
            flash('请选择合班学科!', 'danger')
            return render_template('combinations/new.html', subjects=subjects, classes=classes)
        
        if len(class_ids) < 2:
            flash('请至少选择两个班级进行合班!', 'danger')
            return render_template('combinations/new.html', subjects=subjects, classes=classes)
        
        # 检查合班名称是否已存在
        existing_combo = ClassCombination.query.filter_by(name=name).first()
        if existing_combo:
            flash('合班名称已存在!', 'danger')
            return render_template('combinations/new.html', subjects=subjects, classes=classes)
        
        # 创建合班设置
        combination = ClassCombination(
            name=name,
            subject_id=subject_id
        )
        
        # 添加班级关联
        for class_id in class_ids:
            class_obj = Class.query.get(class_id)
            if class_obj:
                combination.classes.append(class_obj)
        
        db.session.add(combination)
        db.session.commit()
        
        flash('合班设置创建成功!', 'success')
        return redirect(url_for('combinations.index'))
    
    return render_template('combinations/new.html', subjects=subjects, classes=classes)

@combinations_bp.route('/combinations/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('combinations.index'))
    
    combination = ClassCombination.query.get_or_404(id)
    classes = Class.query.order_by(Class.grade).all()
    subjects = Subject.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        subject_id = request.form.get('subject_id', type=int)
        class_ids = request.form.getlist('classes', type=int)
        
        # 检查是否选择了学科和至少两个班级
        if not subject_id:
            flash('请选择合班学科!', 'danger')
            return render_template('combinations/edit.html', combination=combination, subjects=subjects, classes=classes)
        
        if len(class_ids) < 2:
            flash('请至少选择两个班级进行合班!', 'danger')
            return render_template('combinations/edit.html', combination=combination, subjects=subjects, classes=classes)
        
        # 检查名称是否与其他合班设置冲突
        existing_combo = ClassCombination.query.filter(
            (ClassCombination.name == name) & (ClassCombination.id != combination.id)
        ).first()
        
        if existing_combo:
            flash('合班名称已被其他合班设置使用!', 'danger')
            return render_template('combinations/edit.html', combination=combination, subjects=subjects, classes=classes)
        
        combination.name = name
        combination.subject_id = subject_id
        
        # 更新班级关联
        combination.classes.clear()
        for class_id in class_ids:
            class_obj = Class.query.get(class_id)
            if class_obj:
                combination.classes.append(class_obj)
        
        db.session.commit()
        
        flash('合班设置更新成功!', 'success')
        return redirect(url_for('combinations.index'))
    
    return render_template('combinations/edit.html', combination=combination, subjects=subjects, classes=classes)

@combinations_bp.route('/combinations/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('combinations.index'))
    
    combination = ClassCombination.query.get_or_404(id)
    
    db.session.delete(combination)
    db.session.commit()
    
    flash('合班设置删除成功!', 'success')
    return redirect(url_for('combinations.index'))

@combinations_bp.route('/combinations/by_subject/<int:subject_id>')
@login_required
def by_subject(subject_id):
    combinations = ClassCombination.query.filter_by(subject_id=subject_id).all()
    result = []
    
    for combo in combinations:
        class_ids = [c.id for c in combo.classes]
        result.append({
            'id': combo.id,
            'name': combo.name,
            'classes': class_ids
        })
    
    return jsonify(result) 