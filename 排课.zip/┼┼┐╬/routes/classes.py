from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import login_required, current_user
from database import db
from models import Class, Teacher, TeachingPlan
import csv
import io
import pandas as pd
import chardet

classes_bp = Blueprint('classes', __name__)

@classes_bp.route('/classes')
@login_required
def index():
    classes = Class.query.order_by(Class.grade).all()
    
    # 计算每个班级的总课时
    class_total_hours = {}
    for cls in classes:
        # 获取该班级的所有授课计划
        plans = TeachingPlan.query.filter_by(class_id=cls.id).all()
        # 使用模型的total_hours属性计算总课时
        total_hours = sum(plan.total_hours for plan in plans)
        class_total_hours[cls.id] = total_hours
    
    return render_template('classes/index.html', classes=classes, class_total_hours=class_total_hours)

@classes_bp.route('/classes/download_template')
@login_required
def download_template():
    format_type = request.args.get('format', 'csv')
    
    # 使用中文表头
    data = [
        ['班级名称', '年级', '班主任姓名'],  # 中文表头
        ['初一(1)班', '7', '张老师'],  # 示例数据1 - 使用数字表示年级
        ['高二(3)班', '高二', '李老师']  # 示例数据2 - 使用文字表示年级
    ]
    
    if format_type == 'excel':
        # 创建Excel文件
        output = io.BytesIO()
        df = pd.DataFrame(data[1:], columns=data[0])
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name='班级导入模板')
            # 获取工作表
            worksheet = writer.sheets['班级导入模板']
            # 调整列宽
            for i, col in enumerate(df.columns):
                max_len = max(df[col].astype(str).map(len).max(), len(col)) + 2
                worksheet.set_column(i, i, max_len)
        
        output.seek(0)
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name='班级导入模板.xlsx'
        )
    else:
        # 创建CSV文件（默认）
        output = io.StringIO()
        writer = csv.writer(output)
        for row in data:
            writer.writerow(row)
        
        output.seek(0)
        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8')),
            mimetype='text/csv',
            as_attachment=True,
            download_name='班级导入模板.csv'
        )

@classes_bp.route('/classes/new', methods=['GET', 'POST'])
@login_required
def new():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('classes.index'))
    
    teachers = Teacher.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        grade = request.form.get('grade', type=int)
        head_teacher_id = request.form.get('head_teacher_id', type=int)
        
        # 检查班级名称是否已存在
        existing_class = Class.query.filter_by(name=name).first()
        if existing_class:
            flash('班级名称已存在!', 'danger')
            return render_template('classes/new.html', teachers=teachers)
        
        class_obj = Class(
            name=name,
            grade=grade,
            head_teacher_id=head_teacher_id
        )
        
        db.session.add(class_obj)
        db.session.commit()
        
        flash('班级添加成功!', 'success')
        return redirect(url_for('classes.index'))
    
    return render_template('classes/new.html', teachers=teachers)

@classes_bp.route('/classes/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('classes.index'))
    
    class_obj = Class.query.get_or_404(id)
    teachers = Teacher.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        grade = request.form.get('grade', type=int)
        head_teacher_id = request.form.get('head_teacher_id', type=int) or None
        
        # 检查班级名称是否已存在
        existing_class = Class.query.filter(Class.name == name, Class.id != id).first()
        if existing_class:
            flash('班级名称已存在!', 'danger')
            return render_template('classes/edit.html', class_obj=class_obj, teachers=teachers)
        
        class_obj.name = name
        class_obj.grade = grade
        class_obj.head_teacher_id = head_teacher_id
        
        db.session.commit()
        
        flash('班级更新成功!', 'success')
        return redirect(url_for('classes.index'))
    
    return render_template('classes/edit.html', class_obj=class_obj, teachers=teachers)

@classes_bp.route('/classes/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('classes.index'))
    
    class_obj = Class.query.get_or_404(id)
    
    db.session.delete(class_obj)
    db.session.commit()
    
    flash('班级删除成功!', 'success')
    return redirect(url_for('classes.index'))

@classes_bp.route('/classes/import', methods=['GET', 'POST'])
@login_required
def import_classes():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('classes.index'))
    
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('没有上传文件!', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        
        if file.filename == '':
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        if file and file.filename.endswith(('.csv', '.xls', '.xlsx')):
            try:
                # 读取文件并检测编码
                file_content = file.read()
                file.seek(0)  # 重置文件指针
                
                # 检测文件编码
                detected = chardet.detect(file_content)
                encoding = detected['encoding']
                
                # 根据文件类型读取数据
                if file.filename.endswith('.csv'):
                    try:
                        df = pd.read_csv(file, encoding=encoding)
                    except:
                        # 如果出错，尝试使用其他常见编码
                        for enc in ['utf-8', 'gbk', 'gb2312', 'gb18030', 'latin1']:
                            try:
                                file.seek(0)
                                df = pd.read_csv(file, encoding=enc)
                                break
                            except:
                                continue
                else:
                    df = pd.read_excel(file)
                
                # 字段名映射（中文->英文）
                field_mapping = {
                    '班级名称': 'name',
                    '年级': 'grade', 
                    '班主任姓名': 'head_teacher_name',
                    # 保留英文字段名映射，以兼容旧版本
                    'name': 'name',
                    'grade': 'grade',
                    'head_teacher_name': 'head_teacher_name',
                    'head_teacher_staff_id': 'head_teacher_staff_id' # 保留工号字段兼容旧版
                }
                
                # 重命名DataFrame列名
                df = df.rename(columns=field_mapping)
                
                # 验证必要列
                required_columns = ['name', 'grade']
                for column in required_columns:
                    if column not in df.columns:
                        flash(f'文件中缺少必要的列: {column}', 'danger')
                        return redirect(request.url)
                
                # 导入数据
                success_count = 0
                error_count = 0
                
                # 年级名称到数字的映射
                grade_mapping = {
                    '初一': 7, '七年级': 7, '7': 7, 7: 7,
                    '初二': 8, '八年级': 8, '8': 8, 8: 8,
                    '初三': 9, '九年级': 9, '9': 9, 9: 9,
                    '高一': 10, '十年级': 10, '10': 10, 10: 10,
                    '高二': 11, '十一年级': 11, '11': 11, 11: 11,
                    '高三': 12, '十二年级': 12, '12': 12, 12: 12
                }
                
                for _, row in df.iterrows():
                    # 检查必要字段是否为空
                    if pd.isna(row['name']) or pd.isna(row['grade']):
                        error_count += 1
                        continue
                    
                    # 检查班级名称是否已存在
                    existing_class = Class.query.filter_by(name=row['name']).first()
                    if existing_class:
                        error_count += 1
                        continue
                    
                    # 转换年级名称为数字
                    grade_value = row['grade']
                    if grade_value in grade_mapping:
                        grade_number = grade_mapping[grade_value]
                    else:
                        try:
                            # 尝试直接转换为整数
                            grade_number = int(grade_value)
                            # 检查是否在有效范围内
                            if grade_number not in range(7, 13):
                                error_count += 1
                                continue
                        except (ValueError, TypeError):
                            # 如果转换失败，跳过此记录
                            error_count += 1
                            continue
                    
                    # 如果提供了班主任，验证班主任是否存在
                    head_teacher_id = None
                    
                    # 优先使用姓名查找
                    if 'head_teacher_name' in row and not pd.isna(row['head_teacher_name']):
                        teacher = Teacher.query.filter_by(name=row['head_teacher_name']).first()
                        if teacher:
                            head_teacher_id = teacher.id
                    
                    # 如果没找到且提供了工号，则使用工号查找（兼容旧版）
                    elif 'head_teacher_staff_id' in row and not pd.isna(row['head_teacher_staff_id']):
                        teacher = Teacher.query.filter_by(staff_id=str(row['head_teacher_staff_id'])).first()
                        if teacher:
                            head_teacher_id = teacher.id
                    
                    # 创建新班级
                    class_obj = Class(
                        name=row['name'],
                        grade=grade_number,
                        head_teacher_id=head_teacher_id
                    )
                    
                    db.session.add(class_obj)
                    success_count += 1
                
                db.session.commit()
                
                flash(f'成功导入 {success_count} 个班级，{error_count} 条记录导入失败!', 'info')
                return redirect(url_for('classes.index'))
            
            except Exception as e:
                flash(f'导入失败: {str(e)}', 'danger')
                return redirect(request.url)
        
        else:
            flash('文件格式不支持，请上传 CSV 或 Excel 文件!', 'danger')
            return redirect(request.url)
    
    return render_template('classes/import.html')

@classes_bp.route('/classes/export')
@login_required
def export_classes():
    classes = Class.query.order_by(Class.grade).all()
    
    # 年级映射
    grade_map = {
        7: '初一',
        8: '初二',
        9: '初三',
        10: '高一',
        11: '高二',
        12: '高三'
    }
    
    # 创建 CSV 数据
    output = io.StringIO()
    writer = csv.writer(output)
    
    # 写入中文列头
    writer.writerow(['班级名称', '年级', '班主任姓名'])
    
    # 写入数据
    for class_obj in classes:
        head_teacher_name = ''
        if class_obj.head_teacher:
            head_teacher_name = class_obj.head_teacher.name
        
        # 将数字年级转换为中文
        grade_text = grade_map.get(class_obj.grade, str(class_obj.grade))
        
        writer.writerow([
            class_obj.name,
            grade_text,
            head_teacher_name
        ])
    
    # 准备响应
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name='班级数据.csv'
    )

@classes_bp.route('/classes/add_test_data')
@login_required
def add_test_data():
    """添加测试班级数据的路由"""
    # 检查是否已有班级数据
    existing_classes = Class.query.all()
    if len(existing_classes) > 0:
        flash(f'已存在 {len(existing_classes)} 个班级，不再添加测试数据', 'info')
        # 列出现有班级
        class_info = "<ul>"
        for cls in existing_classes:
            class_info += f"<li>{cls.name} (年级: {cls.grade})</li>"
        class_info += "</ul>"
        flash(class_info, 'info')
        return redirect(url_for('classes.index'))
    
    # 创建测试班级数据
    test_classes = [
        # 初中班级
        {"name": "初一(1)班", "grade": 7},
        {"name": "初一(2)班", "grade": 7},
        {"name": "初二(1)班", "grade": 8},
        {"name": "初二(2)班", "grade": 8},
        {"name": "初三(1)班", "grade": 9},
        {"name": "初三(2)班", "grade": 9},
        
        # 高中班级
        {"name": "高一(1)班", "grade": 10},
        {"name": "高一(2)班", "grade": 10},
        {"name": "高二(1)班", "grade": 11},
        {"name": "高二(2)班", "grade": 11},
        {"name": "高三(1)班", "grade": 12},
        {"name": "高三(2)班", "grade": 12},
    ]
    
    # 添加班级数据
    for class_data in test_classes:
        class_obj = Class(
            name=class_data["name"],
            grade=class_data["grade"]
        )
        db.session.add(class_obj)
    
    # 提交到数据库
    db.session.commit()
    flash(f'成功添加 {len(test_classes)} 个测试班级', 'success')
    return redirect(url_for('classes.index')) 