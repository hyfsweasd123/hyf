from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, send_file
from flask_login import login_required, current_user
from database import db
from models import Teacher, Subject, Class, NonRoutineSubstitution, Schedule, TeachingPlan
from datetime import datetime, timedelta
import calendar
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from io import BytesIO

# 创建蓝图
non_routine_bp = Blueprint('non_routine', __name__, url_prefix='/non-routine')

@non_routine_bp.route('/')
@non_routine_bp.route('/index')
@login_required
def index():
    """常规代课安排首页"""
    # 获取最近的代课记录(未来7天)
    today = datetime.now().date()
    next_week = today + timedelta(days=7)
    recent_substitutions = NonRoutineSubstitution.query.filter(
        NonRoutineSubstitution.date >= today,
        NonRoutineSubstitution.date <= next_week
    ).order_by(NonRoutineSubstitution.date).all()
    
    return render_template('non_routine/index.html', recent_substitutions=recent_substitutions)

@non_routine_bp.route('/list')
@login_required
def list_all():
    """查看所有常规代课记录"""
    # 获取状态筛选参数
    status = request.args.get('status', 'all')
    
    # 构建查询
    query = NonRoutineSubstitution.query
    
    # 根据状态筛选
    if status != 'all':
        query = query.filter_by(status=status)
    
    # 时间范围筛选
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    if start_date:
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(NonRoutineSubstitution.date >= start_date)
        except:
            flash('开始日期格式无效', 'warning')
    
    if end_date:
        try:
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(NonRoutineSubstitution.date <= end_date)
        except:
            flash('结束日期格式无效', 'warning')
    
    # 教师筛选
    teacher_id = request.args.get('teacher_id', type=int)
    if teacher_id:
        query = query.filter(
            (NonRoutineSubstitution.original_teacher_id == teacher_id) | 
            (NonRoutineSubstitution.substitute_teacher_id == teacher_id)
        )
    
    # 排序：先按日期降序，再按课时升序
    substitutions = query.order_by(NonRoutineSubstitution.date.desc(), NonRoutineSubstitution.period).all()
    
    # 获取所有教师，用于筛选
    teachers = Teacher.query.order_by(Teacher.name).all()
    
    return render_template('non_routine/list.html', 
                        substitutions=substitutions,
                        current_status=status,
                        teachers=teachers,
                        teacher_id=teacher_id,
                        start_date=start_date if 'start_date' in locals() else None,
                        end_date=end_date if 'end_date' in locals() else None)

@non_routine_bp.route('/new', methods=['GET', 'POST'])
@login_required
def new():
    """创建新的常规代课"""
    if request.method == 'POST':
        # 获取表单数据
        original_teacher_id = request.form.get('original_teacher_id', type=int)
        substitute_teacher_id = request.form.get('substitute_teacher_id', type=int)
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        start_date_str = request.form.get('start_date')
        end_date_str = request.form.get('end_date')
        date_str = request.form.get('date')  # 保留原始字段以兼容
        period = request.form.get('period', type=int)
        reason = request.form.get('reason')
        notes = request.form.get('notes')
        
        # 验证数据
        if not all([original_teacher_id, substitute_teacher_id, class_id, subject_id, start_date_str, end_date_str, period]):
            flash('请填写所有必填字段', 'danger')
            return redirect(url_for('non_routine.new'))
        
        try:
            # 处理日期范围
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
            
            # 使用开始日期作为主日期字段（兼容现有数据结构）
            date = start_date
            day_of_week = date.weekday() + 1  # 转换为 1-7
            
            # 将日期范围信息添加到备注中
            if start_date != end_date:
                range_note = f"请假时间范围: {start_date.strftime('%Y-%m-%d')} 至 {end_date.strftime('%Y-%m-%d')}"
                notes = range_note + "\n" + (notes or "")
        except:
            flash('日期格式无效', 'danger')
            return redirect(url_for('non_routine.new'))
        
        # 创建代课记录
        new_substitution = NonRoutineSubstitution(
            original_teacher_id=original_teacher_id,
            substitute_teacher_id=substitute_teacher_id,
            class_id=class_id,
            subject_id=subject_id,
            date=date,
            day_of_week=day_of_week,
            period=period,
            reason=reason,
            notes=notes,
            status='pending'
        )
        
        try:
            db.session.add(new_substitution)
            db.session.commit()
            flash('常规代课安排创建成功', 'success')
            return redirect(url_for('non_routine.list_all'))
        except Exception as e:
            db.session.rollback()
            flash(f'创建失败: {str(e)}', 'danger')
            return redirect(url_for('non_routine.new'))
    
    # GET请求，显示表单
    teachers = Teacher.query.order_by(Teacher.name).all()
    classes = Class.query.order_by(Class.grade, Class.name).all()
    subjects = Subject.query.order_by(Subject.name).all()
    
    # 按学科分类教师，过滤掉学科名称中包含"1"的学科
    teachers_by_subject = {}
    added_teacher_ids = set()  # 用于跟踪已添加的教师，防止重复
    
    # 首先按学科分类教师
    for subject in subjects:
        # 检查学科名称是否包含"1"，如果包含则跳过
        if "1" in subject.name:
            continue
            
        subject_teachers = []
        for teacher in subject.teachers:
            # 只添加未添加过的教师
            if teacher.id not in added_teacher_ids:
                subject_teachers.append(teacher)
                added_teacher_ids.add(teacher.id)
        
        if subject_teachers:
            teachers_by_subject[subject.id] = {
                'subject_name': subject.name,
                'teachers': sorted(subject_teachers, key=lambda t: t.name)
            }
    
    # 收集未分配到过滤后学科的教师
    other_teachers = [t for t in teachers if t.id not in added_teacher_ids]
    other_teachers.sort(key=lambda t: t.name)
    
    # 获取教师与班级的映射关系
    teacher_class_mapping = {}
    teaching_plans = TeachingPlan.query.all()
    
    for plan in teaching_plans:
        teacher_id = plan.teacher_id
        if teacher_id not in teacher_class_mapping:
            teacher_class_mapping[teacher_id] = []
        
        class_info = {
            'id': plan.class_obj.id,
            'name': plan.class_obj.name,
            'subject_id': plan.subject_id,
            'subject_name': plan.subject.name
        }
        
        # 避免重复添加相同的班级
        if not any(c['id'] == class_info['id'] for c in teacher_class_mapping[teacher_id]):
            teacher_class_mapping[teacher_id].append(class_info)
    
    # 获取教师课表数据
    teacher_schedule_mapping = {}
    schedules = Schedule.query.all()
    
    for schedule in schedules:
        teacher_id = schedule.teacher_id
        if teacher_id not in teacher_schedule_mapping:
            teacher_schedule_mapping[teacher_id] = []
        
        schedule_info = {
            'class_id': schedule.class_id,
            'class_name': schedule.class_obj.name,
            'subject_id': schedule.subject_id,
            'subject_name': schedule.subject.name,
            'day_of_week': schedule.day_of_week,
            'period': schedule.period,
            'week_type': schedule.week_type
        }
        
        teacher_schedule_mapping[teacher_id].append(schedule_info)
    
    return render_template('non_routine/new.html', 
                        teachers=teachers,
                        teachers_by_subject=teachers_by_subject,
                        other_teachers=other_teachers,
                        teacher_class_mapping=teacher_class_mapping,
                        teacher_schedule_mapping=teacher_schedule_mapping,
                        classes=classes,
                        subjects=subjects)

@non_routine_bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    """编辑常规代课"""
    substitution = NonRoutineSubstitution.query.get_or_404(id)
    
    if request.method == 'POST':
        # 获取表单数据
        original_teacher_id = request.form.get('original_teacher_id', type=int)
        substitute_teacher_id = request.form.get('substitute_teacher_id', type=int)
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        start_date_str = request.form.get('start_date')
        end_date_str = request.form.get('end_date')
        date_str = request.form.get('date')  # 保留原始字段以兼容
        period = request.form.get('period', type=int)
        reason = request.form.get('reason')
        notes = request.form.get('notes')
        status = request.form.get('status')
        
        # 验证数据
        if not all([original_teacher_id, substitute_teacher_id, class_id, subject_id, start_date_str, end_date_str, period]):
            flash('请填写所有必填字段', 'danger')
            return redirect(url_for('non_routine.edit', id=id))
        
        try:
            # 处理日期范围
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
            
            # 使用开始日期作为主日期字段（兼容现有数据结构）
            date = start_date
            day_of_week = date.weekday() + 1
            
            # 将日期范围信息添加到备注中
            if start_date != end_date:
                # 先移除可能存在的旧日期范围信息
                if notes and "请假时间范围:" in notes:
                    notes = "\n".join([line for line in notes.split("\n") if not line.strip().startswith("请假时间范围:")])
                
                range_note = f"请假时间范围: {start_date.strftime('%Y-%m-%d')} 至 {end_date.strftime('%Y-%m-%d')}"
                notes = range_note + "\n" + (notes or "")
        except:
            flash('日期格式无效', 'danger')
            return redirect(url_for('non_routine.edit', id=id))
        
        # 更新代课信息
        substitution.original_teacher_id = original_teacher_id
        substitution.substitute_teacher_id = substitute_teacher_id
        substitution.class_id = class_id
        substitution.subject_id = subject_id
        substitution.date = date
        substitution.day_of_week = day_of_week
        substitution.period = period
        substitution.reason = reason
        substitution.notes = notes
        
        if status in ['pending', 'completed', 'cancelled']:
            substitution.status = status
        
        try:
            db.session.commit()
            flash('常规代课信息更新成功', 'success')
            return redirect(url_for('non_routine.list_all'))
        except Exception as e:
            db.session.rollback()
            flash(f'更新失败: {str(e)}', 'danger')
            return redirect(url_for('non_routine.edit', id=id))
    
    # GET请求，显示表单
    teachers = Teacher.query.order_by(Teacher.name).all()
    classes = Class.query.order_by(Class.grade, Class.name).all()
    subjects = Subject.query.order_by(Subject.name).all()
    
    # 按学科分类教师，过滤掉学科名称中包含"1"的学科
    teachers_by_subject = {}
    added_teacher_ids = set()  # 用于跟踪已添加的教师，防止重复
    
    # 首先按学科分类教师
    for subject in subjects:
        # 检查学科名称是否包含"1"，如果包含则跳过
        if "1" in subject.name:
            continue
            
        subject_teachers = []
        for teacher in subject.teachers:
            # 只添加未添加过的教师
            if teacher.id not in added_teacher_ids:
                subject_teachers.append(teacher)
                added_teacher_ids.add(teacher.id)
        
        if subject_teachers:
            teachers_by_subject[subject.id] = {
                'subject_name': subject.name,
                'teachers': sorted(subject_teachers, key=lambda t: t.name)
            }
    
    # 收集未分配到过滤后学科的教师
    other_teachers = [t for t in teachers if t.id not in added_teacher_ids]
    other_teachers.sort(key=lambda t: t.name)
    
    # 获取教师与班级的映射关系
    teacher_class_mapping = {}
    teaching_plans = TeachingPlan.query.all()
    
    for plan in teaching_plans:
        teacher_id = plan.teacher_id
        if teacher_id not in teacher_class_mapping:
            teacher_class_mapping[teacher_id] = []
        
        class_info = {
            'id': plan.class_obj.id,
            'name': plan.class_obj.name,
            'subject_id': plan.subject_id,
            'subject_name': plan.subject.name
        }
        
        # 避免重复添加相同的班级
        if not any(c['id'] == class_info['id'] for c in teacher_class_mapping[teacher_id]):
            teacher_class_mapping[teacher_id].append(class_info)
    
    # 获取教师课表数据
    teacher_schedule_mapping = {}
    schedules = Schedule.query.all()
    
    for schedule in schedules:
        teacher_id = schedule.teacher_id
        if teacher_id not in teacher_schedule_mapping:
            teacher_schedule_mapping[teacher_id] = []
        
        schedule_info = {
            'class_id': schedule.class_id,
            'class_name': schedule.class_obj.name,
            'subject_id': schedule.subject_id,
            'subject_name': schedule.subject.name,
            'day_of_week': schedule.day_of_week,
            'period': schedule.period,
            'week_type': schedule.week_type
        }
        
        teacher_schedule_mapping[teacher_id].append(schedule_info)
    
    return render_template('non_routine/edit.html', 
                        substitution=substitution,
                        teachers=teachers,
                        teachers_by_subject=teachers_by_subject,
                        other_teachers=other_teachers,
                        teacher_class_mapping=teacher_class_mapping,
                        teacher_schedule_mapping=teacher_schedule_mapping,
                        classes=classes,
                        subjects=subjects)

@non_routine_bp.route('/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    """删除常规代课"""
    substitution = NonRoutineSubstitution.query.get_or_404(id)
    
    try:
        db.session.delete(substitution)
        db.session.commit()
        flash('常规代课安排已删除', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'删除失败: {str(e)}', 'danger')
    
    return redirect(url_for('non_routine.list_all'))

@non_routine_bp.route('/<int:id>/change_status', methods=['POST'])
@login_required
def change_status(id):
    """更改代课状态"""
    substitution = NonRoutineSubstitution.query.get_or_404(id)
    new_status = request.form.get('status')
    
    if new_status not in ['pending', 'completed', 'cancelled']:
        flash('无效的状态', 'danger')
        return redirect(url_for('non_routine.list_all'))
    
    substitution.status = new_status
    
    try:
        db.session.commit()
        flash('状态更新成功', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'更新状态失败: {str(e)}', 'danger')
    
    return redirect(url_for('non_routine.list_all'))

@non_routine_bp.route('/<int:id>/change-teacher', methods=['POST'])
@login_required
def change_teacher(id):
    """快速修改代课老师"""
    substitution = NonRoutineSubstitution.query.get_or_404(id)
    new_teacher_id = request.form.get('substitute_teacher_id', type=int)
    
    if not new_teacher_id:
        flash('请选择新的代课老师', 'danger')
        return redirect(url_for('non_routine.list_all'))
    
    # 验证新老师是否存在
    new_teacher = Teacher.query.get(new_teacher_id)
    if not new_teacher:
        flash('选择的代课老师不存在', 'danger')
        return redirect(url_for('non_routine.list_all'))
    
    # 记录原来的代课老师
    old_teacher_name = substitution.substitute_teacher.name if substitution.substitute_teacher else '未知'
    
    # 更新代课老师
    substitution.substitute_teacher_id = new_teacher_id
    
    try:
        db.session.commit()
        flash(f'代课老师已从 {old_teacher_name} 修改为 {new_teacher.name}', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'修改代课老师失败: {str(e)}', 'danger')
    
    return redirect(url_for('non_routine.list_all'))

@non_routine_bp.route('/api/get_schedule_info', methods=['GET'])
@login_required
def get_schedule_info():
    """获取指定日期、班级、课时的课表信息"""
    class_id = request.args.get('class_id', type=int)
    date_str = request.args.get('date')
    period = request.args.get('period', type=int)
    
    if not all([class_id, date_str, period]):
        return jsonify({'error': '缺少必要参数'}), 400
    
    try:
        date = datetime.strptime(date_str, '%Y-%m-%d').date()
        day_of_week = date.weekday() + 1  # 1-7 表示周一到周日
    except:
        return jsonify({'error': '日期格式无效'}), 400
    
    # 查询对应的课表信息
    schedule = Schedule.query.filter_by(
        class_id=class_id,
        day_of_week=day_of_week,
        period=period
    ).first()
    
    if not schedule:
        return jsonify({
            'found': False,
            'message': '未找到相应的课表信息'
        })
    
    # 返回课表信息
    return jsonify({
        'found': True,
        'teacher_id': schedule.teacher_id,
        'teacher_name': schedule.teacher.name if schedule.teacher else None,
        'subject_id': schedule.subject_id,
        'subject_name': schedule.subject.name if schedule.subject else None
    })

@non_routine_bp.route('/api/get_available_teachers', methods=['GET'])
@login_required
def get_available_teachers():
    """获取指定时间段内可以代课的老师列表"""
    date_str = request.args.get('date')
    period = request.args.get('period', type=int)
    original_teacher_id = request.args.get('original_teacher_id', type=int)
    scope = request.args.get('scope')  # same, related(班级范围), all
    
    if not all([date_str, period, original_teacher_id, scope]):
        return jsonify({'error': '缺少必要参数'}), 400
    
    try:
        date = datetime.strptime(date_str, '%Y-%m-%d').date()
        day_of_week = date.weekday() + 1  # 1-7 表示周一到周日
    except:
        return jsonify({'error': '日期格式无效'}), 400
    
    # 获取原老师信息和学科
    original_teacher = Teacher.query.get(original_teacher_id)
    if not original_teacher:
        return jsonify({'error': '找不到原老师信息'}), 400
    
    # 获取原老师的学科
    original_subject = None
    if original_teacher.subjects:
        original_subject = original_teacher.subjects[0].name  # 使用第一个学科
    
    # 获取原老师所教的班级
    original_teacher_classes = set()
    original_teaching_plans = TeachingPlan.query.filter_by(teacher_id=original_teacher_id).all()
    for plan in original_teaching_plans:
        original_teacher_classes.add(plan.class_id)
    
    # 查询在该时间段已经有课的老师
    busy_teachers = set()
    busy_schedules = Schedule.query.filter_by(
        day_of_week=day_of_week,
        period=period
    ).all()
    
    for schedule in busy_schedules:
        busy_teachers.add(schedule.teacher_id)
    
    # 根据范围获取候选老师
    candidate_teachers = []
    all_teachers = Teacher.query.all()
    
    for teacher in all_teachers:
        # 排除原老师本人和已有课程的老师
        if teacher.id == original_teacher_id or teacher.id in busy_teachers:
            continue
        
        # 检查是否没有学科信息，如果没有则跳过
        if not teacher.subjects:
            continue
        
        teacher_subject = teacher.subjects[0].name  # 使用第一个学科
        
        # 根据范围筛选
        if scope == 'same':
            # 同学科
            if teacher_subject == original_subject:
                candidate_teachers.append(teacher)
        elif scope == 'related':
            # 班级范围 - 在原老师所教班级中任教的其他老师
            teacher_teaching_plans = TeachingPlan.query.filter_by(teacher_id=teacher.id).all()
            teacher_classes = set(plan.class_id for plan in teacher_teaching_plans)
            
            # 检查是否有共同的班级
            if original_teacher_classes & teacher_classes:  # 有交集
                candidate_teachers.append(teacher)
        elif scope == 'all':
            # 全校范围（其他学科且不在同一班级）
            teacher_teaching_plans = TeachingPlan.query.filter_by(teacher_id=teacher.id).all()
            teacher_classes = set(plan.class_id for plan in teacher_teaching_plans)
            
            # 不是同学科且不在同一班级
            if teacher_subject != original_subject and not (original_teacher_classes & teacher_classes):
                candidate_teachers.append(teacher)
    
    # 格式化返回数据
    available_teachers = []
    for teacher in candidate_teachers:
        available_teachers.append({
            'id': teacher.id,
            'name': teacher.name,
            'subject': teacher.subjects[0].name if teacher.subjects else '未知'
        })
    
    return jsonify({
        'success': True,
        'teachers': available_teachers,
        'total': len(available_teachers)
    })

def is_related_subject_backend(original_subject, target_subject):
    """后端版本的相关学科判断函数"""
    related_subjects = {
        '语文': ['历史', '政治', '地理'],
        '数学': ['物理', '化学', '生物'],
        '英语': ['语文'],
        '物理': ['数学', '化学'],
        '化学': ['数学', '物理', '生物'],
        '生物': ['数学', '化学'],
        '历史': ['语文', '政治', '地理'],
        '政治': ['语文', '历史'],
        '地理': ['语文', '历史']
    }
    
    return related_subjects.get(original_subject, []) and target_subject in related_subjects.get(original_subject, [])

@non_routine_bp.route('/export')
@login_required
def export_records():
    """导出代课记录为Excel文件"""
    # 获取筛选参数（与list_all函数相同的逻辑）
    status = request.args.get('status', 'all')
    
    # 构建查询
    query = NonRoutineSubstitution.query
    
    # 根据状态筛选
    if status != 'all':
        query = query.filter_by(status=status)
    
    # 时间范围筛选
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    if start_date:
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(NonRoutineSubstitution.date >= start_date)
        except:
            pass
    
    if end_date:
        try:
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(NonRoutineSubstitution.date <= end_date)
        except:
            pass
    
    # 教师筛选
    teacher_id = request.args.get('teacher_id', type=int)
    if teacher_id:
        query = query.filter(
            (NonRoutineSubstitution.original_teacher_id == teacher_id) | 
            (NonRoutineSubstitution.substitute_teacher_id == teacher_id)
        )
    
    # 排序：先按日期降序，再按课时升序
    substitutions = query.order_by(NonRoutineSubstitution.date.desc(), NonRoutineSubstitution.period).all()
    
    # 创建Excel工作簿
    wb = Workbook()
    ws = wb.active
    ws.title = "代课记录"
    
    # 设置列标题
    headers = ['日期', '星期', '课时', '班级', '学科', '请假老师', '代课教师', '请假类型', '状态', '备注']
    
    # 写入标题行
    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num, value=header)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
    
    # 写入数据行
    weekdays = ['一', '二', '三', '四', '五', '六', '日']
    status_map = {
        'pending': '待完成',
        'completed': '已完成',
        'cancelled': '已取消'
    }
    
    for row_num, sub in enumerate(substitutions, 2):
        data = [
            sub.date.strftime('%Y-%m-%d'),
            weekdays[sub.day_of_week - 1],
            f'第{sub.period}节',
            sub.class_obj.name if sub.class_obj else '',
            sub.subject.name if sub.subject else '',
            sub.original_teacher.name if sub.original_teacher else '',
            sub.substitute_teacher.name if sub.substitute_teacher else '',
            sub.reason or '',
            status_map.get(sub.status, sub.status),
            sub.notes or ''
        ]
        
        for col_num, value in enumerate(data, 1):
            cell = ws.cell(row=row_num, column=col_num, value=value)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            # 根据状态设置行颜色
            if sub.status == 'completed':
                cell.fill = PatternFill(start_color="D4F6D4", end_color="D4F6D4", fill_type="solid")
            elif sub.status == 'cancelled':
                cell.fill = PatternFill(start_color="FFD4D4", end_color="FFD4D4", fill_type="solid")
            elif sub.status == 'pending':
                cell.fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
    
    # 设置固定列宽为15个字符
    for column in ws.columns:
        column_letter = column[0].column_letter
        ws.column_dimensions[column_letter].width = 15
    
    # 生成文件名
    current_time = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'代课记录_{current_time}.xlsx'
    
    # 保存到内存
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=filename
    ) 