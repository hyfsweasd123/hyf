from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import login_required, current_user
from database import db
from models import Subject
import csv
import io
import pandas as pd

subjects_bp = Blueprint('subjects', __name__)

@subjects_bp.route('/subjects')
@login_required
def index():
    subjects = Subject.query.all()
    return render_template('subjects/index.html', subjects=subjects)

# 添加API接口，返回所有学科的JSON数据
@subjects_bp.route('/api/subjects')
@login_required
def api_subjects():
    subjects = Subject.query.all()
    return jsonify([{'id': subject.id, 'name': subject.name, 'is_major': subject.is_major} for subject in subjects])

@subjects_bp.route('/subjects/new', methods=['GET', 'POST'])
@login_required
def new():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('subjects.index'))
    
    if request.method == 'POST':
        name = request.form.get('name')
        
        # 检查学科是否已存在
        existing_subject = Subject.query.filter_by(name=name).first()
        if existing_subject:
            flash('学科名称已存在!', 'danger')
            return render_template('subjects/new.html')
        
        subject = Subject(name=name)
        
        db.session.add(subject)
        db.session.commit()
        
        flash('学科添加成功!', 'success')
        return redirect(url_for('subjects.index'))
    
    return render_template('subjects/new.html')

@subjects_bp.route('/subjects/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('subjects.index'))
    
    subject = Subject.query.get_or_404(id)
    
    if request.method == 'POST':
        name = request.form.get('name')
        
        # 检查名称是否与其他学科冲突
        existing_subject = Subject.query.filter(
            (Subject.name == name) & (Subject.id != subject.id)
        ).first()
        
        if existing_subject:
            flash('学科名称已被其他学科使用!', 'danger')
            return render_template('subjects/edit.html', subject=subject)
        
        subject.name = name
        
        db.session.commit()
        
        flash('学科更新成功!', 'success')
        return redirect(url_for('subjects.index'))
    
    return render_template('subjects/edit.html', subject=subject)

@subjects_bp.route('/subjects/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('subjects.index'))
    
    subject = Subject.query.get_or_404(id)
    
    # 检查学科是否被教师引用
    if subject.teachers:
        flash('无法删除，该学科已被教师关联!', 'danger')
        return redirect(url_for('subjects.index'))
    
    db.session.delete(subject)
    db.session.commit()
    
    flash('学科删除成功!', 'success')
    return redirect(url_for('subjects.index'))

@subjects_bp.route('/subjects/import', methods=['GET', 'POST'])
@login_required
def import_subjects():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('subjects.index'))
    
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('没有上传文件!', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        
        if file.filename == '':
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        if file and file.filename.endswith(('.csv', '.xls', '.xlsx')):
            try:
                # 读取文件
                if file.filename.endswith('.csv'):
                    df = pd.read_csv(file)
                else:
                    df = pd.read_excel(file)
                
                # 验证必要列
                required_columns = ['name']
                for column in required_columns:
                    if column not in df.columns:
                        flash(f'文件中缺少必要的列: {column}', 'danger')
                        return redirect(request.url)
                
                # 导入数据
                success_count = 0
                error_count = 0
                
                for _, row in df.iterrows():
                    # 检查必要字段是否为空
                    if pd.isna(row['name']):
                        error_count += 1
                        continue
                    
                    # 检查学科是否已存在
                    existing_subject = Subject.query.filter_by(name=row['name']).first()
                    if existing_subject:
                        error_count += 1
                        continue
                    
                    # 创建新学科
                    subject = Subject(name=row['name'])
                    
                    db.session.add(subject)
                    success_count += 1
                
                db.session.commit()
                
                flash(f'成功导入 {success_count} 个学科，{error_count} 条记录导入失败!', 'info')
                return redirect(url_for('subjects.index'))
            
            except Exception as e:
                flash(f'导入失败: {str(e)}', 'danger')
                return redirect(request.url)
        
        else:
            flash('文件格式不支持，请上传 CSV 或 Excel 文件!', 'danger')
            return redirect(request.url)
    
    return render_template('subjects/import.html')

@subjects_bp.route('/subjects/export')
@login_required
def export_subjects():
    subjects = Subject.query.all()
    
    # 创建 CSV 数据
    output = io.StringIO()
    writer = csv.writer(output)
    
    # 写入列头
    writer.writerow(['name'])
    
    # 写入数据
    for subject in subjects:
        writer.writerow([subject.name])
    
    # 准备响应
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name='subjects.csv'
    ) 