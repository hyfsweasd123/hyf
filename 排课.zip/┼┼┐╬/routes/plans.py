from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file, current_app
from flask_login import login_required, current_user
from database import db
from models import TeachingPlan, Class, Subject, Teacher, ClassCombination
import pandas as pd
import os
from werkzeug.utils import secure_filename
import tempfile
import shutil
from datetime import datetime
import atexit
import numpy as np

plans_bp = Blueprint('plans', __name__)

# 创建一个全局的临时文件目录列表，用于退出时清理
temp_dirs = []

# 注册应用退出时的清理函数
def cleanup_temp_dirs():
    for dir_path in temp_dirs:
        try:
            if os.path.exists(dir_path):
                shutil.rmtree(dir_path, ignore_errors=True)
        except Exception as e:
            print(f"清理临时目录失败: {str(e)}")

atexit.register(cleanup_temp_dirs)

@plans_bp.route('/plans')
@login_required
def index():
    # 获取所有班级
    classes = Class.query.order_by(Class.grade).all()
    
    # 如果没有班级，直接返回空数据
    if not classes:
        return render_template('plans/index.html', plans=[], classes=[], subjects=[], selected_class=None)
    
    # 获取选定的班级ID，默认为第一个班级
    selected_class_id = request.args.get('class_id', type=int)
    if not selected_class_id and classes:
        selected_class_id = classes[0].id
        
    # 获取选定班级的对象
    selected_class = Class.query.get(selected_class_id) if selected_class_id else None
    
    # 获取所有学科
    subjects = Subject.query.order_by(Subject.id).all()
    
    # 获取选定班级的排课计划，如果没有选定班级则获取所有计划
    if selected_class:
        plans = TeachingPlan.query.filter_by(class_id=selected_class.id).all()
    else:
        plans = TeachingPlan.query.all()
    
    # 计算总课时数（使用模型的total_hours属性）
    total_hours = sum(plan.total_hours for plan in plans) if plans else 0
    
    return render_template('plans/index.html', plans=plans, classes=classes, subjects=subjects, 
                          selected_class=selected_class, total_hours=total_hours)

@plans_bp.route('/plans/new', methods=['GET', 'POST'])
@login_required
def new():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('plans.index'))
    
    classes = Class.query.order_by(Class.grade).all()
    subjects = Subject.query.all()
    teachers = Teacher.query.all()
    combinations = ClassCombination.query.all()
    
    if request.method == 'POST':
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        teacher_id = request.form.get('teacher_id', type=int)
        hours_per_week = request.form.get('hours_per_week', type=int)
        is_combined = 'is_combined' in request.form
        combination_id = request.form.get('combination_id', type=int) if is_combined else None
        
        # 获取单双周信息
        week_type = request.form.get('week_type', 'all')
        extra_hours = request.form.get('extra_hours', type=int, default=0)
        extra_week_type = request.form.get('extra_week_type') if extra_hours > 0 else None
        
        # 基本验证
        if not class_id or not subject_id or not teacher_id or not hours_per_week:
            flash('请填写所有必要字段!', 'danger')
            return render_template('plans/new.html', classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
        
        # 检查教师是否教授该学科
        teacher = Teacher.query.get(teacher_id)
        subject = Subject.query.get(subject_id)
        if subject not in teacher.subjects:
            flash('所选教师不教授该学科!', 'danger')
            return render_template('plans/new.html', classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
        
        # 检查是否已存在相同班级和学科的授课计划
        existing_plan = TeachingPlan.query.filter_by(class_id=class_id, subject_id=subject_id).first()
        if existing_plan:
            flash('该班级的这个学科已有授课计划!', 'danger')
            return render_template('plans/new.html', classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
        
        # 如果是合班，检查合班设置是否与学科匹配
        if is_combined and combination_id:
            combination = ClassCombination.query.get(combination_id)
            if combination.subject_id != subject_id:
                flash('合班设置的学科与所选学科不匹配!', 'danger')
                return render_template('plans/new.html', classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
            
            # 检查班级是否在合班设置中
            class_obj = Class.query.get(class_id)
            if class_obj not in combination.classes:
                flash('所选班级不在合班设置中!', 'danger')
                return render_template('plans/new.html', classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
        
        plan = TeachingPlan(
            class_id=class_id,
            subject_id=subject_id,
            teacher_id=teacher_id,
            hours_per_week=hours_per_week,
            is_combined=is_combined,
            combination_id=combination_id if is_combined else None,
            # 添加单双周信息
            week_type=week_type,
            extra_hours=extra_hours if extra_hours > 0 else None,
            extra_week_type=extra_week_type
        )
        
        db.session.add(plan)
        db.session.commit()
        
        flash('授课计划创建成功!', 'success')
        return redirect(url_for('plans.index'))
    
    return render_template('plans/new.html', classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)

@plans_bp.route('/plans/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('plans.index'))
    
    plan = TeachingPlan.query.get_or_404(id)
    classes = Class.query.order_by(Class.grade).all()
    subjects = Subject.query.all()
    teachers = Teacher.query.all()
    combinations = ClassCombination.query.all()
    
    if request.method == 'POST':
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        teacher_id = request.form.get('teacher_id', type=int)
        hours_per_week = request.form.get('hours_per_week', type=int)
        is_combined = 'is_combined' in request.form
        combination_id = request.form.get('combination_id', type=int) if is_combined else None
        
        # 获取单双周信息
        week_type = request.form.get('week_type', 'all')
        extra_hours = request.form.get('extra_hours', type=int, default=0)
        extra_week_type = request.form.get('extra_week_type') if extra_hours > 0 else None
        
        # 基本验证
        if not class_id or not subject_id or not teacher_id or not hours_per_week:
            flash('请填写所有必要字段!', 'danger')
            return render_template('plans/edit.html', plan=plan, classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
        
        # 检查教师是否教授该学科
        teacher = Teacher.query.get(teacher_id)
        subject = Subject.query.get(subject_id)
        if subject not in teacher.subjects:
            flash('所选教师不教授该学科!', 'danger')
            return render_template('plans/edit.html', plan=plan, classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
        
        # 检查是否已存在相同班级和学科的其他授课计划
        existing_plan = TeachingPlan.query.filter(
            (TeachingPlan.class_id == class_id) & 
            (TeachingPlan.subject_id == subject_id) & 
            (TeachingPlan.id != plan.id)
        ).first()
        
        if existing_plan:
            flash('该班级的这个学科已有其他授课计划!', 'danger')
            return render_template('plans/edit.html', plan=plan, classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
        
        # 如果是合班，检查合班设置是否与学科匹配
        if is_combined and combination_id:
            combination = ClassCombination.query.get(combination_id)
            if combination.subject_id != subject_id:
                flash('合班设置的学科与所选学科不匹配!', 'danger')
                return render_template('plans/edit.html', plan=plan, classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
            
            # 检查班级是否在合班设置中
            class_obj = Class.query.get(class_id)
            if class_obj not in combination.classes:
                flash('所选班级不在合班设置中!', 'danger')
                return render_template('plans/edit.html', plan=plan, classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)
        
        plan.class_id = class_id
        plan.subject_id = subject_id
        plan.teacher_id = teacher_id
        plan.hours_per_week = hours_per_week
        plan.is_combined = is_combined
        plan.combination_id = combination_id if is_combined else None
        
        # 更新单双周信息
        plan.week_type = week_type
        plan.extra_hours = extra_hours if extra_hours > 0 else None
        plan.extra_week_type = extra_week_type
        
        db.session.commit()
        
        flash('授课计划更新成功!', 'success')
        return redirect(url_for('plans.index'))
    
    return render_template('plans/edit.html', plan=plan, classes=classes, subjects=subjects, teachers=teachers, combinations=combinations)

@plans_bp.route('/plans/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('plans.index'))
    
    plan = TeachingPlan.query.get_or_404(id)
    
    db.session.delete(plan)
    db.session.commit()
    
    flash('授课计划删除成功!', 'success')
    return redirect(url_for('plans.index'))

@plans_bp.route('/plans/by_class/<int:class_id>')
@login_required
def by_class(class_id):
    plans = TeachingPlan.query.filter_by(class_id=class_id).all()
    result = []
    
    for plan in plans:
        result.append({
            'id': plan.id,
            'subject_id': plan.subject_id,
            'subject_name': plan.subject.name,
            'teacher_id': plan.teacher_id,
            'teacher_name': plan.teacher.name,
            'hours_per_week': plan.hours_per_week,
            'is_combined': plan.is_combined,
            'combination_id': plan.combination_id
        })
    
    return jsonify(result)

@plans_bp.route('/plans/by_teacher/<int:teacher_id>')
@login_required
def by_teacher(teacher_id):
    plans = TeachingPlan.query.filter_by(teacher_id=teacher_id).all()
    result = []
    
    for plan in plans:
        result.append({
            'id': plan.id,
            'class_id': plan.class_id,
            'class_name': plan.class_obj.name,
            'subject_id': plan.subject_id,
            'subject_name': plan.subject.name,
            'hours_per_week': plan.hours_per_week,
            'is_combined': plan.is_combined,
            'combination_id': plan.combination_id
        })
    
    return jsonify(result)

@plans_bp.route('/plans/import', methods=['GET', 'POST'])
@login_required
def import_plans():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('plans.index'))
    
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        if file and file.filename.endswith(('.xlsx', '.xls')):
            # 创建临时目录保存上传文件
            temp_dir = tempfile.mkdtemp()
            temp_dirs.append(temp_dir)  # 添加到待清理列表
            
            try:
                filename = secure_filename(file.filename)
                filepath = os.path.join(temp_dir, filename)
                file.save(filepath)
                
                # 读取Excel文件
                df = pd.read_excel(filepath)
                
                # 预处理数据
                success = 0
                errors = 0
                error_messages = []
                
                # 假设Excel格式为：班级,学科,教师,周课时,是否合班,合班名称
                for _, row in df.iterrows():
                    try:
                        class_name = row['班级']
                        subject_name = row['学科']
                        teacher_name = row['教师']
                        hours_per_week = int(row['周课时'])
                        is_combined = row.get('是否合班', '否') == '是'
                        combination_name = row.get('合班名称', None)
                        
                        # 获取相关对象
                        class_obj = Class.query.filter_by(name=class_name).first()
                        
                        # 如果班级不存在，添加到错误信息
                        if not class_obj:
                            error_msg = f"行 {_ + 2}: 班级 '{class_name}' 不存在"
                            error_messages.append(error_msg)
                            errors += 1
                            continue
                        
                        # 检查学科是否存在，如果不存在则自动创建
                        subject = Subject.query.filter_by(name=subject_name).first()
                        if not subject:
                            subject = Subject(
                                name=subject_name
                            )
                            db.session.add(subject)
                            db.session.commit()  # 提交以获取ID
                            flash(f"已自动创建学科: {subject_name}", "info")
                        
                        # 检查教师是否存在，如果不存在则自动创建
                        teacher = Teacher.query.filter_by(name=teacher_name).first()
                        if not teacher:
                            # 生成新教师工号（格式：T + 年份 + 3位序号）
                            import datetime
                            current_year = datetime.datetime.now().year
                            # 查找最大工号
                            latest_teacher = Teacher.query.filter(Teacher.staff_id.like(f'T{current_year}%')).order_by(Teacher.staff_id.desc()).first()
                            
                            if latest_teacher and latest_teacher.staff_id.startswith(f'T{current_year}'):
                                try:
                                    seq_num = int(latest_teacher.staff_id[5:]) + 1
                                except (ValueError, IndexError):
                                    seq_num = 1
                            else:
                                seq_num = 1
                                
                            staff_id = f'T{current_year}{seq_num:03d}'
                            
                            # 创建新教师
                            teacher = Teacher(
                                name=teacher_name,
                                staff_id=staff_id,
                                gender='未知'  # 默认性别
                            )
                            db.session.add(teacher)
                            db.session.commit()  # 提交以获取ID
                            flash(f"已自动创建教师: {teacher_name} (工号: {staff_id})", "info")
                        
                        # 确保教师具有该学科的教授权限
                        if subject not in teacher.subjects:
                            teacher.subjects.append(subject)
                            db.session.commit()
                            flash(f"已为教师 {teacher_name} 分配学科 {subject_name}", "info")
                        
                        # 检查是否已存在相同班级和学科的授课计划
                        existing_plan = TeachingPlan.query.filter_by(class_id=class_obj.id, subject_id=subject.id).first()
                        if existing_plan:
                            error_msg = f"行 {_ + 2}: 班级 {class_name} 的 {subject_name} 已有授课计划"
                            error_messages.append(error_msg)
                            errors += 1
                            continue
                        
                        # 处理合班情况
                        combination_id = None
                        if is_combined and combination_name:
                            combination = ClassCombination.query.filter_by(name=combination_name).first()
                            if not combination:
                                error_msg = f"行 {_ + 2}: 合班 {combination_name} 不存在"
                                error_messages.append(error_msg)
                                errors += 1
                                continue
                            
                            if combination.subject_id != subject.id:
                                error_msg = f"行 {_ + 2}: 合班 {combination_name} 的学科与所选学科 {subject_name} 不匹配"
                                error_messages.append(error_msg)
                                errors += 1
                                continue
                            
                            if class_obj not in combination.classes:
                                error_msg = f"行 {_ + 2}: 班级 {class_name} 不在合班 {combination_name} 中"
                                error_messages.append(error_msg)
                                errors += 1
                                continue
                            
                            combination_id = combination.id
                        
                        # 创建授课计划
                        plan = TeachingPlan(
                            class_id=class_obj.id,
                            subject_id=subject.id,
                            teacher_id=teacher.id,
                            hours_per_week=hours_per_week,
                            is_combined=is_combined,
                            combination_id=combination_id
                        )
                        
                        db.session.add(plan)
                        success += 1
                    except Exception as e:
                        error_msg = f"行 {_ + 2}: 处理出错 - {str(e)}"
                        error_messages.append(error_msg)
                        errors += 1
                
                db.session.commit()
                
                if errors > 0:
                    error_summary = '<br>'.join(error_messages)
                    flash(f'导入完成，成功: {success}，失败: {errors}<br>{error_summary}', 'warning')
                else:
                    flash(f'成功导入 {success} 条授课计划!', 'success')
                
                return redirect(url_for('plans.index'))
            except Exception as e:
                flash(f'导入出错: {str(e)}', 'danger')
            finally:
                # 删除临时目录
                shutil.rmtree(temp_dir, ignore_errors=True)
        else:
            flash('请上传Excel文件(.xlsx或.xls格式)!', 'danger')
        
        return redirect(request.url)
    
    # 提供模板下载
    return render_template('plans/import.html')

@plans_bp.route('/plans/export')
@login_required
def export_plans():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('plans.index'))
    
    plans = TeachingPlan.query.all()
    data = []
    
    for plan in plans:
        data.append({
            '班级': plan.class_obj.name,
            '学科': plan.subject.name,
            '教师': plan.teacher.name,
            '周课时': plan.hours_per_week,
            '是否合班': '是' if plan.is_combined else '否',
            '合班名称': plan.combination.name if plan.combination else '',
        })
    
    df = pd.DataFrame(data)
    
    # 创建临时目录保存导出文件
    temp_dir = tempfile.mkdtemp()
    temp_dirs.append(temp_dir)  # 添加到待清理列表
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'授课计划_{timestamp}.xlsx'
    filepath = os.path.join(temp_dir, filename)
    
    # 写入Excel文件
    df.to_excel(filepath, index=False)
    
    return send_file(
        filepath,
        as_attachment=True,
        download_name=filename,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@plans_bp.route('/plans/template')
@login_required
def download_template():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('plans.index'))
    
    # 创建示例数据
    data = [
        {
            '班级': '高一(1)班',
            '学科': '语文',
            '教师': '王老师',
            '周课时': 6,
            '是否合班': '否',
            '合班名称': '',
        },
        {
            '班级': '高一(2)班',
            '学科': '数学',
            '教师': '李老师',
            '周课时': 6,
            '是否合班': '是',
            '合班名称': '高一数学合班1',
        }
    ]
    
    df = pd.DataFrame(data)
    
    # 创建临时目录保存模板文件
    temp_dir = tempfile.mkdtemp()
    temp_dirs.append(temp_dir)  # 添加到待清理列表
    
    filepath = os.path.join(temp_dir, '授课计划导入模板.xlsx')
    
    # 写入Excel文件
    df.to_excel(filepath, index=False)
    
    return send_file(
        filepath,
        as_attachment=True,
        download_name='授课计划导入模板.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@plans_bp.route('/plans/export_matrix')
@login_required
def export_matrix():
    """导出矩阵式授课计划Excel（两个工作表：课时和教师）"""
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('plans.index'))
    
    # 查询所有班级和学科，按照既定顺序排序
    classes = Class.query.order_by(Class.grade).all()
    subjects = Subject.query.order_by(Subject.id).all()
    
    # 查询所有授课计划
    plans = TeachingPlan.query.all()
    
    # 创建两个数据框：课时矩阵和教师矩阵
    # 创建空矩阵，行是班级，列是学科
    hours_matrix = np.zeros((len(classes), len(subjects)), dtype=int)
    teacher_matrix = np.empty((len(classes), len(subjects)), dtype=object)
    # 填充空字符串
    teacher_matrix.fill('')
    
    # 填充矩阵
    for plan in plans:
        class_idx = next((i for i, c in enumerate(classes) if c.id == plan.class_id), None)
        subject_idx = next((i for i, s in enumerate(subjects) if s.id == plan.subject_id), None)
        
        if class_idx is not None and subject_idx is not None:
            hours_matrix[class_idx][subject_idx] = plan.hours_per_week
            teacher_matrix[class_idx][subject_idx] = plan.teacher.name
            
            # 如果是合班，在教师名后添加标记
            if plan.is_combined:
                teacher_matrix[class_idx][subject_idx] += '*'
    
    # 准备班级名称和学科名称
    class_names = [c.name for c in classes]
    subject_names = [s.name for s in subjects]
    
    # 创建课时DataFrame
    hours_df = pd.DataFrame(hours_matrix, columns=subject_names)
    hours_df.insert(0, '班级', class_names)
    
    # 创建教师DataFrame
    teacher_df = pd.DataFrame(teacher_matrix, columns=subject_names)
    teacher_df.insert(0, '班级', class_names)
    
    # 创建临时目录保存导出文件
    temp_dir = tempfile.mkdtemp()
    temp_dirs.append(temp_dir)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'授课计划矩阵_{timestamp}.xlsx'
    filepath = os.path.join(temp_dir, filename)
    
    # 创建Excel写入器
    writer = pd.ExcelWriter(filepath, engine='openpyxl')
    
    # 写入两个工作表
    hours_df.to_excel(writer, sheet_name='课时安排', index=False)
    teacher_df.to_excel(writer, sheet_name='教师安排', index=False)
    
    # 保存文件
    writer.close()
    
    # 添加说明信息
    try:
        from openpyxl import load_workbook
        wb = load_workbook(filepath)
        
        # 给课时表添加说明
        ws = wb['课时安排']
        row = len(classes) + 3
        ws.cell(row=row, column=1).value = "说明:"
        ws.cell(row=row+1, column=1).value = "1、s表示单周, d表示双周, f表示随机, 随机表示由系统确定单周还是双周。"
        ws.cell(row=row+2, column=1).value = "2、d1表示双周安排一节课, s2表示单周安排二节课"
        ws.cell(row=row+3, column=1).value = "3、4s1表示每周4节课，另外单周再安排1节, 2d1表示每周2节，另双周再安排一节。"
        ws.cell(row=row+4, column=1).value = "4、课时数为空或者为0，则表示该班不开设此课程。"
        ws.cell(row=row+5, column=1).value = "5、注意：下面四个工作表名称不能有错，应完全一样。"
        ws.cell(row=row+6, column=1).value = "6、首行的学科名称和首列的班级名称，所有四个工作表应完全相同和对应。"
        
        # 给教师表添加说明
        ws = wb['教师安排']
        row = len(classes) + 3
        ws.cell(row=row, column=1).value = "说明:"
        ws.cell(row=row+1, column=1).value = "1、教师名为空，表示该班不开设此门课或该门课还未安排教师。"
        ws.cell(row=row+2, column=1).value = "2、首行的学科名称和首列的班级名称，所有四个工作表应完全相同和对应。"
        ws.cell(row=row+3, column=1).value = "3、带*号的表示合班上课"
        
        wb.save(filepath)
    except Exception as e:
        print(f"添加说明信息失败: {str(e)}")
    
    return send_file(
        filepath,
        as_attachment=True,
        download_name=filename,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@plans_bp.route('/plans/matrix_template')
@login_required
def matrix_template():
    """下载矩阵式模板"""
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('plans.index'))
    
    # 创建示例数据
    class_names = ['高一(1)班', '高一(2)班', '高一(3)班', '高一(4)班', '高一(5)班', '高一(6)班']
    subject_names = ['语文', '数学', '英语', '物理', '化学', '生物', '政治', '历史', '地理', '体育', '音乐', '美术', '健康', '通用技术', '信息技术']
    
    # 创建示例课时数据
    hours_data = np.zeros((len(class_names), len(subject_names)), dtype=int)
    # 语文、数学每班6节课
    hours_data[:, 0:2] = 6
    # 英语每班5节课
    hours_data[:, 2] = 5
    # 物理、化学、生物
    hours_data[0:2, 3:6] = 2  # 高一(1)(2)班
    hours_data[2, 3:6] = 4    # 高一(3)班
    hours_data[3:6, 3:6] = 2  # 高一(4)(5)(6)班
    # 政治
    hours_data[:, 6] = 4
    # 历史
    hours_data[:, 7] = 2
    # 地理、体育、音乐
    hours_data[:, 8:11] = 3
    # 美术、健康、通用技术、信息技术
    hours_data[:, 11:] = 1
    
    hours_df = pd.DataFrame(hours_data, columns=subject_names)
    hours_df.insert(0, '班级', class_names)
    
    # 创建示例教师数据
    teachers = [
        ['曹老师', '任老师', '曹老师', '张教练', '', '', '完国老', '冯老师', '新教师2x', '曹教练', '曹二', '丁老师', '姚小x', '杨南x', '雷小x'],
        ['任老师', '任老师', '曹老师', '张教练', '', '', '完国老', '冯老师', '新教师2x', '王教练', '曹二', '丁老师', '姚小x', '杨南x', '雷小x'],
        ['王凯x', '王案x', '虞老师', '李教练', '', '', '完国老', '冯老师', '新教师2x', '王教练', '张力x', '丁老师', '姚小x', '杨南x', '雷小x'],
        ['王案x', '王案x', '虞老师', '李教练', '张小x', '王小x', '完国老', '', '', '王教练', '张力x', '丁老师', '姚小x', '杨南x', '雷小x'],
        ['新教师1x', '熊桂x', '新教师1x', '刘芹x', '张小x', '王小x', '完国老', '', '', '王教练', '张力x', '丁老师', '姚小x', '杨南x', '雷小x'],
        ['刘芹x', '关劲x', '新教师1x', '刘芹x', '张小x', '王小x', '完国老', '', '', '王教练', '张力x', '丁老师', '姚小x', '杨南x', '雷小x']
    ]
    
    teacher_matrix = np.array(teachers)
    teacher_df = pd.DataFrame(teacher_matrix, columns=subject_names)
    teacher_df.insert(0, '班级', class_names)
    
    # 创建临时目录保存模板文件
    temp_dir = tempfile.mkdtemp()
    temp_dirs.append(temp_dir)
    
    filepath = os.path.join(temp_dir, '授课计划矩阵模板.xlsx')
    
    # 创建Excel写入器
    writer = pd.ExcelWriter(filepath, engine='openpyxl')
    
    # 写入两个工作表
    hours_df.to_excel(writer, sheet_name='课时安排', index=False)
    teacher_df.to_excel(writer, sheet_name='教师安排', index=False)
    
    # 保存文件
    writer.close()
    
    # 添加说明信息
    try:
        from openpyxl import load_workbook
        wb = load_workbook(filepath)
        
        # 给课时表添加说明
        ws = wb['课时安排']
        row = len(class_names) + 3
        ws.cell(row=row, column=1).value = "说明:"
        ws.cell(row=row+1, column=1).value = "1、s表示单周, d表示双周, f表示随机, 随机表示由系统确定单周还是双周。"
        ws.cell(row=row+2, column=1).value = "2、d1表示双周安排一节课, s2表示单周安排二节课"
        ws.cell(row=row+3, column=1).value = "3、4s1表示每周4节课，另外单周再安排1节, 2d1表示每周2节，另双周再安排一节。"
        ws.cell(row=row+4, column=1).value = "4、课时数为空或者为0，则表示该班不开设此课程。"
        ws.cell(row=row+5, column=1).value = "5、注意：下面四个工作表名称不能有错，应完全一样。"
        ws.cell(row=row+6, column=1).value = "6、首行的学科名称和首列的班级名称，所有四个工作表应完全相同和对应。"
        
        # 给教师表添加说明
        ws = wb['教师安排']
        row = len(class_names) + 3
        ws.cell(row=row, column=1).value = "说明:"
        ws.cell(row=row+1, column=1).value = "1、教师名为空，表示该班不开设此门课或该门课还未安排教师。"
        ws.cell(row=row+2, column=1).value = "2、首行的学科名称和首列的班级名称，所有四个工作表应完全相同和对应。"
        ws.cell(row=row+3, column=1).value = "3、带*号的表示合班上课"
        
        wb.save(filepath)
    except Exception as e:
        print(f"添加说明信息失败: {str(e)}")
    
    return send_file(
        filepath,
        as_attachment=True,
        download_name='授课计划矩阵模板.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@plans_bp.route('/plans/matrix_import', methods=['GET', 'POST'])
@login_required
def matrix_import():
    """导入矩阵式授课计划"""
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('plans.index'))
    
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        if file and file.filename.endswith(('.xlsx', '.xls')):
            # 创建临时目录保存上传文件
            temp_dir = tempfile.mkdtemp()
            temp_dirs.append(temp_dir)
            
            try:
                filename = secure_filename(file.filename)
                filepath = os.path.join(temp_dir, filename)
                file.save(filepath)
                
                # 读取Excel文件的两个工作表
                try:
                    # 获取所有工作表名
                    xl = pd.ExcelFile(filepath)
                    sheets = xl.sheet_names
                    
                    if '课时安排' not in sheets or '教师安排' not in sheets:
                        flash('Excel文件必须包含"课时安排"和"教师安排"两个工作表!', 'danger')
                        return redirect(request.url)
                    
                    # 读取两个工作表
                    hours_df = pd.read_excel(filepath, sheet_name='课时安排')
                    teachers_df = pd.read_excel(filepath, sheet_name='教师安排')
                    
                    # 检查两个表的格式是否正确
                    if '班级' not in hours_df.columns or '班级' not in teachers_df.columns:
                        flash('工作表必须包含"班级"列!', 'danger')
                        return redirect(request.url)
                    
                    # 检查两个表的班级和学科是否一致
                    if not hours_df.columns.equals(teachers_df.columns):
                        flash('两个工作表的列名（学科）必须完全一致!', 'danger')
                        return redirect(request.url)
                    
                    # 对班级名称进行标准化处理
                    # 排除掉可能是说明文本的行（通常以数字、中文顿号开头的行）
                    def is_valid_class_name(name):
                        if not isinstance(name, str):
                            return True
                        name = name.strip()
                        # 排除以数字加、顿号或点号开头的说明文本
                        if name and (name[0].isdigit() and len(name) > 1 and (name[1] == '、' or name[1] == '.')):
                            return False
                        return True
                    
                    # 解析课时数据，支持特殊格式如'd1', 's2', '4s1', '2d1'等
                    def parse_hours(hours_value):
                        """
                        解析课时数据，支持各种单双周格式
                        返回一个字典：
                        {
                            'hours': 基础课时数,
                            'week_type': 'all'|'s'|'d'|'f', # all=每周, s=单周, d=双周, f=随机
                            'extra_hours': 额外课时数,
                            'extra_week_type': 额外课时的周类型
                        }
                        """
                        if pd.isna(hours_value) or hours_value == '':
                            return {'hours': 0, 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                        
                        if isinstance(hours_value, (int, float)):
                            return {'hours': int(hours_value), 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                            
                        # 尝试解析特殊格式
                        hours_str = str(hours_value).strip().lower()
                        
                        # 简单格式: 纯数字
                        if hours_str.isdigit():
                            return {'hours': int(hours_str), 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                            
                        # 处理带单双周标记的格式
                        # 例如: 'd1'=双周1节, 's2'=单周2节
                        import re
                        
                        # 单周或双周的基本格式：s1, d2等
                        simple_pattern = r'^([sd])(\d+)$'
                        simple_match = re.match(simple_pattern, hours_str)
                        if simple_match:
                            week_type = simple_match.group(1)  # 's'=单周, 'd'=双周
                            hours = int(simple_match.group(2))  # 课时数
                            return {'hours': hours, 'week_type': week_type, 'extra_hours': None, 'extra_week_type': None}
                            
                        # 处理复合格式: 如'4s1'=每周4节+单周1节; '2d1'=每周2节+双周1节
                        complex_pattern = r'^(\d+)([sd])(\d+)$'
                        complex_match = re.match(complex_pattern, hours_str)
                        if complex_match:
                            base_hours = int(complex_match.group(1))  # 基本课时
                            extra_week_type = complex_match.group(2)  # 's'=单周, 'd'=双周
                            extra_hours = int(complex_match.group(3))  # 额外课时
                            return {
                                'hours': base_hours, 
                                'week_type': 'all',
                                'extra_hours': extra_hours,
                                'extra_week_type': extra_week_type
                            }
                        
                        # 随机单双周格式: 例如 'f2' = 随机单双周各2节
                        random_pattern = r'^f(\d+)$'
                        random_match = re.match(random_pattern, hours_str)
                        if random_match:
                            hours = int(random_match.group(1))
                            return {'hours': hours, 'week_type': 'f', 'extra_hours': None, 'extra_week_type': None}
                            
                        # 其他情况或无法解析时
                        try:
                            return {'hours': int(float(hours_str)), 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                        except:
                            # 默认返回1节课
                            flash(f"无法解析课时格式: {hours_str}，默认设置为1节课", "warning")
                            return {'hours': 1, 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                    
                    # 筛选有效的班级行
                    valid_rows = []
                    for i, class_name in enumerate(hours_df['班级']):
                        if is_valid_class_name(class_name):
                            valid_rows.append(i)
                    
                    # 只比较有效行
                    hours_classes = hours_df.iloc[valid_rows]['班级'].apply(lambda x: str(x).strip())
                    teachers_classes = teachers_df.iloc[valid_rows]['班级'].apply(lambda x: str(x).strip())
                    
                    if not hours_classes.equals(teachers_classes):
                        # 打印不匹配的班级名，便于调试
                        diff_classes = []
                        for i, (c1, c2) in enumerate(zip(hours_classes, teachers_classes)):
                            if c1 != c2:
                                # 使用原始索引+2（Excel行号）
                                diff_classes.append(f"行{valid_rows[i]+2}: '{c1}' vs '{c2}'")
                        
                        error_msg = '两个工作表的班级名称不一致!<br>具体差异:<br>' + '<br>'.join(diff_classes[:5])
                        if len(diff_classes) > 5:
                            error_msg += '<br>...(更多差异已省略)'
                        
                        flash(error_msg, 'danger')
                        return redirect(request.url)
                    
                    # 开始导入数据
                    success = 0
                    errors = 0
                    error_messages = []
                    
                    # 获取所有班级、学科和教师的映射关系
                    classes_dict = {c.name: c for c in Class.query.all()}
                    subjects_dict = {s.name: s for s in Subject.query.all()}
                    teachers_dict = {t.name: t for t in Teacher.query.all()}
                    teachers_dict.update({t.name + '*': t for t in Teacher.query.all()})  # 带星号也能识别
                    
                    # 获取所有合班设置
                    combinations_dict = {}
                    for combo in ClassCombination.query.all():
                        for subject in combo.subject.name:
                            for class_obj in combo.classes:
                                key = (class_obj.name, subject)
                                combinations_dict[key] = combo
                    
                    # 首先检查并删除已有的教学计划
                    if request.form.get('clear_existing') == 'yes':
                        TeachingPlan.query.delete()
                        db.session.commit()
                        flash('已清除所有现有授课计划!', 'warning')
                    
                    # 先处理学科列表（表头），自动创建不存在的学科
                    subject_columns = [col for col in hours_df.columns if col != '班级']
                    for subject_name in subject_columns:
                        if subject_name not in subjects_dict:
                            # 创建新学科
                            new_subject = Subject(name=subject_name)
                            db.session.add(new_subject)
                            db.session.commit()
                            subjects_dict[subject_name] = new_subject
                            flash(f"已自动创建学科: {subject_name}", "info")
                    
                    # 遍历每行，创建授课计划
                    for idx, row in hours_df.iterrows():
                        class_name = row['班级']
                        
                        if class_name not in classes_dict:
                            error_msg = f"第 {idx + 2} 行: 班级 '{class_name}' 不存在"
                            error_messages.append(error_msg)
                            errors += 1
                            continue
                        
                        # 获取相应的教师行
                        teacher_row = teachers_df.iloc[idx]
                        
                        # 对每个学科进行处理
                        for subject_name in hours_df.columns:
                            if subject_name == '班级':
                                continue
                                
                            subject = subjects_dict[subject_name]
                            
                            # 获取课时和教师
                            hours_value = row[subject_name]
                            teacher_value = teacher_row[subject_name]
                            
                            # 解析课时值
                            hours_info = parse_hours(hours_value)
                            
                            # 跳过无课时或无教师的情况
                            if hours_info['hours'] == 0 or pd.isna(teacher_value) or teacher_value == '':
                                continue
                            
                            # 处理教师名
                            is_combined = False
                            if isinstance(teacher_value, str) and teacher_value.endswith('*'):
                                is_combined = True
                                teacher_name = teacher_value.rstrip('*')
                            else:
                                teacher_name = teacher_value
                            
                            # 检查教师是否存在，不存在则创建
                            if teacher_name not in teachers_dict and teacher_name not in [t.name for t in Teacher.query.all()]:
                                # 生成新教师工号
                                import datetime
                                current_year = datetime.datetime.now().year
                                latest_teacher = Teacher.query.filter(Teacher.staff_id.like(f'T{current_year}%')).order_by(Teacher.staff_id.desc()).first()
                                
                                if latest_teacher and latest_teacher.staff_id.startswith(f'T{current_year}'):
                                    try:
                                        seq_num = int(latest_teacher.staff_id[5:]) + 1
                                    except (ValueError, IndexError):
                                        seq_num = 1
                                else:
                                    seq_num = 1
                                    
                                staff_id = f'T{current_year}{seq_num:03d}'
                                
                                # 创建新教师
                                new_teacher = Teacher(
                                    name=teacher_name,
                                    staff_id=staff_id,
                                    gender='未知'
                                )
                                db.session.add(new_teacher)
                                db.session.commit()
                                
                                # 更新教师字典
                                teachers_dict[teacher_name] = new_teacher
                                flash(f"已自动创建教师: {teacher_name} (工号: {staff_id})", "info")
                            
                            # 获取教师对象
                            teacher = teachers_dict.get(teacher_name) or Teacher.query.filter_by(name=teacher_name).first()
                            
                            # 确保教师具有该学科的教授权限
                            if subject not in teacher.subjects:
                                teacher.subjects.append(subject)
                                db.session.commit()
                                flash(f"已为教师 {teacher_name} 分配学科 {subject_name}", "info")
                            
                            # 检查是否已存在相同班级和学科的授课计划
                            class_obj = classes_dict[class_name]
                            existing_plan = TeachingPlan.query.filter_by(
                                class_id=class_obj.id, 
                                subject_id=subject.id
                            ).first()
                            
                            if existing_plan:
                                error_msg = f"行 {idx + 2}, {class_name}-{subject_name}: 已有授课计划"
                                error_messages.append(error_msg)
                                errors += 1
                                continue
                            
                            # 处理合班情况
                            combination_id = None
                            if is_combined:
                                # 查找匹配的合班设置
                                match_found = False
                                for combo in ClassCombination.query.filter_by(subject_id=subject.id).all():
                                    # 需要检查班级对象而不是班级名称
                                    class_in_combo = False
                                    for combo_class in combo.classes:
                                        if combo_class.id == class_obj.id:
                                            class_in_combo = True
                                            break
                                    
                                    if class_in_combo:
                                        combination_id = combo.id
                                        match_found = True
                                        break
                                
                                if not match_found:
                                    error_msg = f"行 {idx + 2}, {class_name}-{subject_name}: 找不到合适的合班设置"
                                    error_messages.append(error_msg)
                                    errors += 1
                                    continue
                            
                            # 创建授课计划
                            try:
                                plan = TeachingPlan(
                                    class_id=class_obj.id,
                                    subject_id=subject.id,
                                    teacher_id=teacher.id,
                                    hours_per_week=hours_info['hours'],
                                    is_combined=is_combined,
                                    combination_id=combination_id,
                                    # 添加单双周信息
                                    week_type=hours_info['week_type'],
                                    extra_hours=hours_info['extra_hours'],
                                    extra_week_type=hours_info['extra_week_type']
                                )
                                
                                db.session.add(plan)
                                success += 1
                            except Exception as e:
                                error_msg = f"行 {idx + 2}, {class_name}-{subject_name}: 处理出错 - {str(e)}"
                                error_messages.append(error_msg)
                                errors += 1
                    
                    # 提交所有更改
                    db.session.commit()
                    
                    if errors > 0:
                        error_summary = '<br>'.join(error_messages[:20])
                        if len(error_messages) > 20:
                            error_summary += '<br>...(更多错误已省略)'
                        flash(f'导入完成，成功: {success}，失败: {errors}<br>{error_summary}', 'warning')
                    else:
                        flash(f'成功导入 {success} 条授课计划!', 'success')
                    
                    return redirect(url_for('plans.index'))
                
                except Exception as e:
                    flash(f'处理Excel文件出错: {str(e)}', 'danger')
                    return redirect(request.url)
                
            except Exception as e:
                flash(f'导入出错: {str(e)}', 'danger')
            finally:
                # 删除临时目录
                shutil.rmtree(temp_dir, ignore_errors=True)
        else:
            flash('请上传Excel文件(.xlsx或.xls格式)!', 'danger')
        
        return redirect(request.url)
    
    # GET请求，显示导入页面
    return render_template('plans/matrix_import.html') 