from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import login_required, current_user
from database import db
from models import Teacher, Subject
import csv
import io
import pandas as pd
from werkzeug.utils import secure_filename
import os
from datetime import datetime

teachers_bp = Blueprint('teachers', __name__)

@teachers_bp.route('/teachers')
@login_required
def index():
    teachers = Teacher.query.all()
    return render_template('teachers/index.html', teachers=teachers)

@teachers_bp.route('/teachers/new', methods=['GET', 'POST'])
@login_required
def new():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('teachers.index'))
    
    subjects = Subject.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        
        # 生成唯一工号
        existing_staff_ids = [t.staff_id for t in Teacher.query.all()]
        base_staff_id = f"T{len(existing_staff_ids)+1:04d}"
        staff_id = base_staff_id
        counter = 1
        while staff_id in existing_staff_ids:
            staff_id = f"{base_staff_id}_{counter}"
            counter += 1
        
        # 兼容两种可能的表单提交方式
        subject_ids = request.form.getlist('subjects[]', type=int)
        if not subject_ids:
            subject_ids = request.form.getlist('subjects', type=int)
        
        teacher = Teacher(name=name, gender='未知', staff_id=staff_id)
        
        # 添加教师学科关联
        for subject_id in subject_ids:
            subject = Subject.query.get(subject_id)
            if subject:
                teacher.subjects.append(subject)
        
        db.session.add(teacher)
        db.session.commit()
        
        flash('教师添加成功!', 'success')
        return redirect(url_for('teachers.index'))
    
    return render_template('teachers/new.html', subjects=subjects)

@teachers_bp.route('/teachers/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('teachers.index'))
    
    teacher = Teacher.query.get_or_404(id)
    subjects = Subject.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        
        # 兼容两种可能的表单提交方式
        subject_ids = request.form.getlist('subjects[]', type=int)
        if not subject_ids:
            subject_ids = request.form.getlist('subjects', type=int)
        
        teacher.name = name
        
        # 更新教师学科关联
        teacher.subjects.clear()
        for subject_id in subject_ids:
            subject = Subject.query.get(subject_id)
            if subject:
                teacher.subjects.append(subject)
        
        db.session.commit()
        
        flash('教师信息更新成功!', 'success')
        return redirect(url_for('teachers.index'))
    
    return render_template('teachers/edit.html', teacher=teacher, subjects=subjects)

@teachers_bp.route('/teachers/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('teachers.index'))
    
    teacher = Teacher.query.get_or_404(id)
    
    db.session.delete(teacher)
    db.session.commit()
    
    flash('教师删除成功!', 'success')
    return redirect(url_for('teachers.index'))

@teachers_bp.route('/teachers/import', methods=['GET', 'POST'])
@login_required
def import_teachers():
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('teachers.index'))
    
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('没有上传文件!', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        
        if file.filename == '':
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        if file and file.filename.endswith(('.csv', '.xls', '.xlsx')):
            try:
                # 读取文件
                if file.filename.endswith('.csv'):
                    # 尝试不同的编码方式读取CSV文件
                    encodings = ['utf-8', 'gbk', 'gb18030', 'gb2312', 'latin1']
                    for encoding in encodings:
                        try:
                            # 将文件指针重置到开始位置
                            file.seek(0)
                            df = pd.read_csv(file, encoding=encoding)
                            break
                        except UnicodeDecodeError:
                            continue
                    else:
                        # 如果所有编码都尝试失败
                        flash('无法识别文件编码，请尝试保存为UTF-8编码格式!', 'danger')
                        return redirect(request.url)
                else:
                    # Excel文件通常不需要指定编码
                    df = pd.read_excel(file)
                
                # 打印调试信息
                print("文件读取成功，包含以下列：", df.columns.tolist())
                print("前5行数据预览：", df.head(5))
                
                # 检查是否有工号列
                has_staff_id = '工号' in df.columns
                
                # 验证必要列
                required_columns = ['姓名', '教授学科']
                missing_columns = [col for col in required_columns if col not in df.columns]
                if missing_columns:
                    flash(f'文件中缺少必要的列: {", ".join(missing_columns)}', 'danger')
                    return redirect(request.url)
                
                # 获取所有学科名称的映射
                all_subjects = Subject.query.all()
                subject_name_map = {subject.name: subject for subject in all_subjects}
                
                print(f"系统中共有{len(all_subjects)}个学科")
                
                # 检查是否需要自动创建学科
                auto_create = request.form.get('auto_create_subjects') == 'on'
                
                # 获取现有教师的工号，用于避免重复
                existing_staff_ids = set()
                for teacher in Teacher.query.all():
                    existing_staff_ids.add(teacher.staff_id)
                
                # 导入数据
                success_count = 0
                error_count = 0
                error_details = []
                created_subjects = []
                
                # 第一次扫描，收集所有出现的学科名称
                all_subject_names = set()
                for _, row in df.iterrows():
                    if not pd.isna(row['教授学科']):
                        subject_names = str(row['教授学科']).split(',')
                        for name in subject_names:
                            name = name.strip()
                            if name:
                                all_subject_names.add(name)
                
                # 自动创建缺失的学科
                if auto_create:
                    for name in all_subject_names:
                        # 检查是否已存在相同名称的学科
                        if name not in subject_name_map:
                            # 创建新学科
                            new_subject = Subject(name=name)
                            db.session.add(new_subject)
                            try:
                                db.session.commit()
                                created_subjects.append(new_subject)
                                # 更新映射
                                subject_name_map[name] = new_subject
                                print(f"创建新学科: {name}")
                            except Exception as e:
                                db.session.rollback()
                                print(f"创建学科 {name} 失败: {str(e)}")
                
                # 导入教师数据
                staff_id_counter = 1
                for index, row in df.iterrows():
                    try:
                        # 检查必要字段是否为空
                        if pd.isna(row['姓名']):
                            msg = f"第{index+2}行: 姓名为空"
                            error_details.append(msg)
                            error_count += 1
                            continue
                        
                        # 获取或生成工号
                        if has_staff_id and not pd.isna(row['工号']):
                            staff_id = str(row['工号']).strip()
                        else:
                            # 生成基于姓名拼音首字母的工号 (简化处理)
                            name = row['姓名']
                            base_staff_id = f"T{index+1:04d}"
                            staff_id = base_staff_id
                            
                            # 确保工号唯一
                            while staff_id in existing_staff_ids:
                                staff_id = f"{base_staff_id}_{staff_id_counter}"
                                staff_id_counter += 1
                        
                        existing_staff_ids.add(staff_id)
                        
                        # 创建新教师
                        teacher = Teacher(name=row['姓名'], gender='未知', staff_id=staff_id)
                        
                        # 添加学科关联
                        if not pd.isna(row['教授学科']):
                            subject_names = str(row['教授学科']).split(',')
                            subject_found = False
                            
                            for name in subject_names:
                                name = name.strip()
                                if not name:
                                    continue
                                
                                # 通过名称匹配学科
                                subject = subject_name_map.get(name)
                                
                                if subject:
                                    teacher.subjects.append(subject)
                                    subject_found = True
                                else:
                                    print(f"未找到学科: {name}")
                            
                            if not subject_found:
                                msg = f"第{index+2}行: {row['姓名']} - 未找到任何匹配的学科 ({row['教授学科']})"
                                error_details.append(msg)
                                error_count += 1
                                continue
                        
                        db.session.add(teacher)
                        db.session.commit()
                        success_count += 1
                    except Exception as e:
                        db.session.rollback()
                        error_count += 1
                        msg = f"第{index+2}行: {row['姓名']} - 错误: {str(e)}"
                        error_details.append(msg)
                        print(msg)
                
                # 显示详细的错误信息
                created_msg = ""
                if created_subjects:
                    created_msg = f"自动创建了 {len(created_subjects)} 个新学科: " + \
                                 ", ".join([s.name for s in created_subjects[:5]]) + \
                                 ("..." if len(created_subjects) > 5 else "")
                
                if error_count > 0:
                    error_sample = error_details[:5]  # 只显示前5个错误
                    error_msg = "<br>".join(error_sample)
                    if len(error_details) > 5:
                        error_msg += f"<br>... 以及其他 {len(error_details) - 5} 个错误"
                    
                    if created_msg:
                        flash(created_msg + '<br><br>' + f'成功导入 {success_count} 名教师，{error_count} 条记录导入失败!<br>错误样本:<br>{error_msg}', 'warning')
                    else:
                        flash(f'成功导入 {success_count} 名教师，{error_count} 条记录导入失败!<br>错误样本:<br>{error_msg}', 'warning')
                else:
                    message = f'成功导入 {success_count} 名教师!'
                    if created_msg:
                        message = created_msg + '<br><br>' + message
                    flash(message, 'success')
                
                return redirect(url_for('teachers.index'))
            
            except Exception as e:
                flash(f'导入失败: {str(e)}', 'danger')
                import traceback
                print(traceback.format_exc())
                return redirect(request.url)
        
        else:
            flash('文件格式不支持，请上传 CSV 或 Excel 文件!', 'danger')
            return redirect(request.url)
    
    return render_template('teachers/import.html')

@teachers_bp.route('/teachers/export')
@login_required
def export_teachers():
    teachers = Teacher.query.all()
    
    # 创建 CSV 数据
    output = io.StringIO()
    writer = csv.writer(output)
    
    # 写入列头
    writer.writerow(['姓名', '教授学科', '工号'])
    
    # 如果没有教师数据，添加示例数据
    if not teachers:
        writer.writerow(['张三', '数学,物理', 'T0001'])
        writer.writerow(['李四', '语文', 'T0002'])
        writer.writerow(['赵六', '英语,化学', 'T0003'])
    else:
        # 写入数据
        for teacher in teachers:
            subject_names = ','.join([subject.name for subject in teacher.subjects])
            writer.writerow([
                teacher.name,
                subject_names,
                teacher.staff_id
            ])
    
    # 准备响应
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name='teachers.csv'
    ) 