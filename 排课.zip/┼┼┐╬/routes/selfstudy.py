from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, send_file, current_app
from flask_login import login_required, current_user
from database import db
from models import Teacher, Subject, Class, SelfStudyPlan, SelfStudySchedule, SelfStudyBlock
import datetime
import pandas as pd
import os
from werkzeug.utils import secure_filename
import tempfile
import shutil
import atexit
import numpy as np
import traceback

# 创建一个全局的临时文件目录列表，用于退出时清理
temp_dirs = []

# 注册应用退出时的清理函数
def cleanup_temp_dirs():
    for dir_path in temp_dirs:
        try:
            if os.path.exists(dir_path):
                shutil.rmtree(dir_path, ignore_errors=True)
        except Exception as e:
            print(f"清理临时目录失败: {str(e)}")

atexit.register(cleanup_temp_dirs)

# 创建蓝图
selfstudy_bp = Blueprint('selfstudy', __name__, url_prefix='/selfstudy')

@selfstudy_bp.route('/')
@selfstudy_bp.route('/index')
@login_required
def index():
    """早晚自习管理首页"""
    return render_template('selfstudy/index.html')

@selfstudy_bp.route('/plans')
@login_required
def plans():
    """早晚自习授课计划管理"""
    # 获取所有班级信息
    classes = Class.query.order_by(Class.grade, Class.name).all()
    
    # 获取所有学科
    subjects = Subject.query.order_by(Subject.name).all()
    
    # 获取选定的班级（如果有）
    selected_class_id = request.args.get('class_id', type=int)
    selected_class = None
    plans = []
    total_hours = 0
    
    if selected_class_id:
        selected_class = Class.query.get_or_404(selected_class_id)
        plans = SelfStudyPlan.query.filter_by(class_id=selected_class_id).all()
        
        # 计算总课时
        for plan in plans:
            total_hours += plan.hours_per_week
            if plan.extra_hours:
                total_hours += plan.extra_hours
    
    # 序列化plans为JSON供JavaScript使用
    plans_json = []
    for plan in plans:
        plan_dict = {
            'id': plan.id,
            'class_id': plan.class_id,
            'subject_id': plan.subject_id,
            'subject_name': plan.subject.name,
            'teacher_id': plan.teacher_id,
            'teacher_name': plan.teacher.name,
            'hours_per_week': plan.hours_per_week,
            'is_combined': plan.is_combined,
            'week_type': plan.week_type,
            'extra_hours': plan.extra_hours,
            'extra_week_type': plan.extra_week_type
        }
        plans_json.append(plan_dict)
    
    return render_template('selfstudy/plans.html', 
                           classes=classes,
                           subjects=subjects,
                           selected_class=selected_class,
                           plans=plans,
                           plans_json=plans_json,
                           total_hours=total_hours)

@selfstudy_bp.route('/plans/new', methods=['GET', 'POST'])
@login_required
def new_plan():
    """添加早晚自习授课计划"""
    if request.method == 'POST':
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        teacher_id = request.form.get('teacher_id', type=int)
        hours_per_week = request.form.get('hours_per_week', type=int)
        is_combined = 'is_combined' in request.form
        combination_id = request.form.get('combination_id', type=int) if is_combined else None
        week_type = request.form.get('week_type', 'all')
        extra_hours = request.form.get('extra_hours', type=int)
        extra_week_type = request.form.get('extra_week_type')
        
        # 验证必填字段
        if not all([class_id, subject_id, teacher_id, hours_per_week]):
            flash('请填写所有必填字段!', 'danger')
            return redirect(url_for('selfstudy.new_plan'))
        
        # 检查是否已存在相同班级和学科的授课计划
        existing_plan = SelfStudyPlan.query.filter_by(class_id=class_id, subject_id=subject_id).first()
        if existing_plan:
            flash('该班级的这个学科已有授课计划!', 'danger')
            return redirect(url_for('selfstudy.plans'))
        
        # 创建授课计划
        new_plan = SelfStudyPlan(
            class_id=class_id,
            subject_id=subject_id,
            teacher_id=teacher_id,
            hours_per_week=hours_per_week,
            is_combined=is_combined,
            combination_id=combination_id,
            week_type=week_type,
            extra_hours=extra_hours,
            extra_week_type=extra_week_type
        )
        
        db.session.add(new_plan)
        db.session.commit()
        flash('早晚自习授课计划创建成功!', 'success')
        return redirect(url_for('selfstudy.plans', class_id=class_id))
    
    # GET请求
    classes = Class.query.order_by(Class.grade, Class.name).all()
    subjects = Subject.query.order_by(Subject.name).all()
    teachers = Teacher.query.order_by(Teacher.name).all()
    combinations = []
    
    # 如果URL中指定了班级ID，则预选
    class_id = request.args.get('class_id', type=int)
    selected_class = None
    if class_id:
        selected_class = Class.query.get(class_id)
    
    return render_template('selfstudy/new_plan.html', 
                           classes=classes,
                           subjects=subjects,
                           teachers=teachers,
                           combinations=combinations,
                           selected_class=selected_class)

@selfstudy_bp.route('/plans/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_plan(id):
    """编辑早晚自习授课计划"""
    plan = SelfStudyPlan.query.get_or_404(id)
    
    if request.method == 'POST':
        class_id = request.form.get('class_id', type=int)
        subject_id = request.form.get('subject_id', type=int)
        teacher_id = request.form.get('teacher_id', type=int)
        hours_per_week = request.form.get('hours_per_week', type=int)
        is_combined = 'is_combined' in request.form
        combination_id = request.form.get('combination_id', type=int) if is_combined else None
        week_type = request.form.get('week_type', 'all')
        extra_hours = request.form.get('extra_hours', type=int)
        extra_week_type = request.form.get('extra_week_type')
        
        # 验证必填字段
        if not all([class_id, subject_id, teacher_id, hours_per_week]):
            flash('请填写所有必填字段!', 'danger')
            return redirect(url_for('selfstudy.edit_plan', id=id))
        
        # 检查是否已存在相同班级和学科的其他授课计划
        existing_plan = SelfStudyPlan.query.filter(
            SelfStudyPlan.class_id == class_id,
            SelfStudyPlan.subject_id == subject_id,
            SelfStudyPlan.id != id
        ).first()
        
        if existing_plan:
            flash('该班级的这个学科已有其他授课计划!', 'danger')
            return redirect(url_for('selfstudy.plans'))
        
        # 更新授课计划
        plan.class_id = class_id
        plan.subject_id = subject_id
        plan.teacher_id = teacher_id
        plan.hours_per_week = hours_per_week
        plan.is_combined = is_combined
        plan.combination_id = combination_id
        plan.week_type = week_type
        plan.extra_hours = extra_hours
        plan.extra_week_type = extra_week_type
        
        db.session.commit()
        flash('早晚自习授课计划更新成功!', 'success')
        return redirect(url_for('selfstudy.plans', class_id=class_id))
    
    # GET请求
    classes = Class.query.order_by(Class.grade, Class.name).all()
    subjects = Subject.query.order_by(Subject.name).all()
    teachers = Teacher.query.order_by(Teacher.name).all()
    combinations = []
    
    return render_template('selfstudy/edit_plan.html', 
                           plan=plan,
                           classes=classes,
                           subjects=subjects,
                           teachers=teachers,
                           combinations=combinations)

@selfstudy_bp.route('/plans/delete/<int:id>', methods=['POST'])
@login_required
def delete_plan(id):
    """删除早晚自习授课计划"""
    plan = SelfStudyPlan.query.get_or_404(id)
    class_id = plan.class_id
    
    db.session.delete(plan)
    db.session.commit()
    
    flash('早晚自习授课计划删除成功!', 'success')
    return redirect(url_for('selfstudy.plans', class_id=class_id))

@selfstudy_bp.route('/plans/import', methods=['GET', 'POST'])
@login_required
def import_plans():
    """导入早晚自习授课计划"""
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('selfstudy.plans'))
    
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        if file and file.filename.endswith(('.xlsx', '.xls')):
            # 创建临时目录保存上传文件
            temp_dir = tempfile.mkdtemp()
            temp_dirs.append(temp_dir)  # 添加到待清理列表
            
            try:
                filename = secure_filename(file.filename)
                filepath = os.path.join(temp_dir, filename)
                file.save(filepath)
                
                # 读取Excel文件
                df = pd.read_excel(filepath)
                
                # 预处理数据
                success = 0
                errors = 0
                error_messages = []
                
                # 检查并删除已有的早晚自习授课计划
                if request.form.get('clear_existing') == 'yes':
                    SelfStudyPlan.query.delete()
                    db.session.commit()
                    flash('已清除所有现有早晚自习授课计划!', 'warning')
                
                # 假设Excel格式为：班级,学科,教师,周课时,是否合班,合班名称,周类型,额外课时,额外周类型
                for _, row in df.iterrows():
                    try:
                        class_name = row['班级']
                        subject_name = row['学科']
                        teacher_name = row['教师']
                        hours_per_week = int(row['周课时'])
                        is_combined = row.get('是否合班', '否') == '是'
                        combination_name = row.get('合班名称', None)
                        week_type = row.get('周类型', 'all')
                        extra_hours = row.get('额外课时', None)
                        extra_week_type = row.get('额外周类型', None)
                        
                        # 尝试转换额外课时为整数
                        if extra_hours and pd.notna(extra_hours):
                            try:
                                extra_hours = int(extra_hours)
                            except:
                                extra_hours = None
                        else:
                            extra_hours = None
                        
                        # 获取相关对象
                        class_obj = Class.query.filter_by(name=class_name).first()
                        
                        # 如果班级不存在，添加到错误信息
                        if not class_obj:
                            error_msg = f"行 {_ + 2}: 班级 '{class_name}' 不存在"
                            error_messages.append(error_msg)
                            errors += 1
                            continue
                        
                        # 检查学科是否存在，如果不存在则自动创建
                        subject = Subject.query.filter_by(name=subject_name).first()
                        if not subject:
                            subject = Subject(
                                name=subject_name
                            )
                            db.session.add(subject)
                            db.session.commit()  # 提交以获取ID
                            flash(f"已自动创建学科: {subject_name}", "info")
                        
                        # 检查教师是否存在，如果不存在则自动创建
                        teacher = Teacher.query.filter_by(name=teacher_name).first()
                        if not teacher:
                            # 生成新教师工号（格式：T + 年份 + 3位序号）
                            current_year = datetime.datetime.now().year
                            # 查找最大工号
                            latest_teacher = Teacher.query.filter(Teacher.staff_id.like(f'T{current_year}%')).order_by(Teacher.staff_id.desc()).first()
                            
                            if latest_teacher and latest_teacher.staff_id.startswith(f'T{current_year}'):
                                try:
                                    seq_num = int(latest_teacher.staff_id[5:]) + 1
                                except (ValueError, IndexError):
                                    seq_num = 1
                            else:
                                seq_num = 1
                                
                            staff_id = f'T{current_year}{seq_num:03d}'
                            
                            # 创建新教师
                            teacher = Teacher(
                                name=teacher_name,
                                staff_id=staff_id,
                                gender='未知'  # 默认性别
                            )
                            db.session.add(teacher)
                            db.session.commit()  # 提交以获取ID
                            flash(f"已自动创建教师: {teacher_name} (工号: {staff_id})", "info")
                        
                        # 确保教师具有该学科的教授权限
                        if subject not in teacher.subjects:
                            teacher.subjects.append(subject)
                            db.session.commit()
                            flash(f"已为教师 {teacher_name} 分配学科 {subject_name}", "info")
                        
                        # 检查是否已存在相同班级和学科的授课计划
                        # 只有在没有选择清除所有计划的情况下才检查是否存在
                        if request.form.get('clear_existing') != 'yes':
                            existing_plan = SelfStudyPlan.query.filter_by(class_id=class_obj.id, subject_id=subject.id).first()
                            if existing_plan:
                                error_msg = f"行 {_ + 2}: 班级 {class_name} 的 {subject_name} 已有早晚自习授课计划"
                                error_messages.append(error_msg)
                                errors += 1
                                continue
                        
                        # 处理合班情况
                        combination_id = None
                        if is_combined and combination_name:
                            from models import ClassCombination
                            combination = ClassCombination.query.filter_by(name=combination_name).first()
                            if not combination:
                                error_msg = f"行 {_ + 2}: 合班 {combination_name} 不存在"
                                error_messages.append(error_msg)
                                errors += 1
                                continue
                            
                            if combination.subject_id != subject.id:
                                error_msg = f"行 {_ + 2}: 合班 {combination_name} 的学科与所选学科 {subject_name} 不匹配"
                                error_messages.append(error_msg)
                                errors += 1
                                continue
                            
                            if class_obj not in combination.classes:
                                error_msg = f"行 {_ + 2}: 班级 {class_name} 不在合班 {combination_name} 中"
                                error_messages.append(error_msg)
                                errors += 1
                                continue
                            
                            combination_id = combination.id
                        
                        # 创建授课计划
                        plan = SelfStudyPlan(
                            class_id=class_obj.id,
                            subject_id=subject.id,
                            teacher_id=teacher.id,
                            hours_per_week=hours_per_week,
                            is_combined=is_combined,
                            combination_id=combination_id,
                            week_type=week_type,
                            extra_hours=extra_hours,
                            extra_week_type=extra_week_type
                        )
                        
                        db.session.add(plan)
                        success += 1
                    except Exception as e:
                        error_msg = f"行 {_ + 2}: 处理出错 - {str(e)}"
                        error_messages.append(error_msg)
                        errors += 1
                
                db.session.commit()
                
                if errors > 0:
                    error_summary = '<br>'.join(error_messages)
                    flash(f'导入完成，成功: {success}，失败: {errors}<br>{error_summary}', 'warning')
                else:
                    flash(f'成功导入 {success} 条早晚自习授课计划!', 'success')
                
                return redirect(url_for('selfstudy.plans'))
            except Exception as e:
                flash(f'导入出错: {str(e)}', 'danger')
            finally:
                # 删除临时目录
                shutil.rmtree(temp_dir, ignore_errors=True)
        else:
            flash('请上传Excel文件(.xlsx或.xls格式)!', 'danger')
        
        return redirect(request.url)
    
    # 提供模板下载
    return render_template('selfstudy/import.html')

@selfstudy_bp.route('/plans/export')
@login_required
def export_plans():
    """导出早晚自习授课计划"""
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('selfstudy.plans'))
    
    plans = SelfStudyPlan.query.all()
    data = []
    
    for plan in plans:
        data.append({
            '班级': plan.class_obj.name,
            '学科': plan.subject.name,
            '教师': plan.teacher.name,
            '周课时': plan.hours_per_week,
            '是否合班': '是' if plan.is_combined else '否',
            '合班名称': plan.combination.name if plan.combination else '',
            '周类型': plan.week_type if plan.week_type else 'all',
            '额外课时': plan.extra_hours if plan.extra_hours else '',
            '额外周类型': plan.extra_week_type if plan.extra_week_type else ''
        })
    
    df = pd.DataFrame(data)
    
    # 创建临时目录保存导出文件
    temp_dir = tempfile.mkdtemp()
    temp_dirs.append(temp_dir)  # 添加到待清理列表
    
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'早晚自习授课计划_{timestamp}.xlsx'
    filepath = os.path.join(temp_dir, filename)
    
    # 写入Excel文件
    df.to_excel(filepath, index=False)
    
    return send_file(
        filepath,
        as_attachment=True,
        download_name=filename,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@selfstudy_bp.route('/plans/template')
@login_required
def download_template():
    """下载早晚自习授课计划导入模板"""
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('selfstudy.plans'))
    
    # 创建示例数据
    data = [
        {
            '班级': '高一(1)班',
            '学科': '语文',
            '教师': '王老师',
            '周课时': 5,
            '是否合班': '否',
            '合班名称': '',
            '周类型': 'all',
            '额外课时': '',
            '额外周类型': ''
        },
        {
            '班级': '高一(2)班',
            '学科': '数学',
            '教师': '李老师',
            '周课时': 4,
            '是否合班': '是',
            '合班名称': '高一数学合班1',
            '周类型': 's',
            '额外课时': 1,
            '额外周类型': 'd'
        }
    ]
    
    df = pd.DataFrame(data)
    
    # 创建临时目录保存模板文件
    temp_dir = tempfile.mkdtemp()
    temp_dirs.append(temp_dir)  # 添加到待清理列表
    
    filepath = os.path.join(temp_dir, '早晚自习授课计划导入模板.xlsx')
    
    # 写入Excel文件
    df.to_excel(filepath, index=False)
    
    return send_file(
        filepath,
        as_attachment=True,
        download_name='早晚自习授课计划导入模板.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@selfstudy_bp.route('/plans/export_matrix')
@login_required
def export_matrix():
    """导出矩阵式早晚自习授课计划Excel（两个工作表：课时和教师）"""
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('selfstudy.plans'))
    
    # 查询所有班级和学科，按照既定顺序排序
    classes = Class.query.order_by(Class.grade).all()
    subjects = Subject.query.order_by(Subject.id).all()
    
    # 查询所有授课计划
    plans = SelfStudyPlan.query.all()
    
    # 创建两个数据框：课时矩阵和教师矩阵
    # 创建空矩阵，行是班级，列是学科
    hours_matrix = np.zeros((len(classes), len(subjects)), dtype=int)
    teacher_matrix = np.empty((len(classes), len(subjects)), dtype=object)
    # 填充空字符串
    teacher_matrix.fill('')
    
    # 填充矩阵
    for plan in plans:
        class_idx = next((i for i, c in enumerate(classes) if c.id == plan.class_id), None)
        subject_idx = next((i for i, s in enumerate(subjects) if s.id == plan.subject_id), None)
        
        if class_idx is not None and subject_idx is not None:
            hours_matrix[class_idx][subject_idx] = plan.hours_per_week
            teacher_matrix[class_idx][subject_idx] = plan.teacher.name
            
            # 如果是合班，在教师名后添加标记
            if plan.is_combined:
                teacher_matrix[class_idx][subject_idx] += '*'
    
    # 准备班级名称和学科名称
    class_names = [c.name for c in classes]
    subject_names = [s.name for s in subjects]
    
    # 创建课时DataFrame
    hours_df = pd.DataFrame(hours_matrix, columns=subject_names)
    hours_df.insert(0, '班级', class_names)
    
    # 创建教师DataFrame
    teacher_df = pd.DataFrame(teacher_matrix, columns=subject_names)
    teacher_df.insert(0, '班级', class_names)
    
    # 创建临时目录保存导出文件
    temp_dir = tempfile.mkdtemp()
    temp_dirs.append(temp_dir)
    
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'早晚自习授课计划矩阵_{timestamp}.xlsx'
    filepath = os.path.join(temp_dir, filename)
    
    # 创建Excel写入器
    writer = pd.ExcelWriter(filepath, engine='openpyxl')
    
    # 写入两个工作表
    hours_df.to_excel(writer, sheet_name='课时安排', index=False)
    teacher_df.to_excel(writer, sheet_name='教师安排', index=False)
    
    # 保存文件
    writer.close()
    
    # 添加说明信息
    try:
        from openpyxl import load_workbook
        wb = load_workbook(filepath)
        
        # 给课时表添加说明
        ws = wb['课时安排']
        row = len(classes) + 3
        ws.cell(row=row, column=1).value = "说明:"
        ws.cell(row=row+1, column=1).value = "1、s表示单周, d表示双周, f表示随机, 随机表示由系统确定单周还是双周。"
        ws.cell(row=row+2, column=1).value = "2、d1表示双周安排一节课, s2表示单周安排二节课"
        ws.cell(row=row+3, column=1).value = "3、4s1表示每周4节课，另外单周再安排1节, 2d1表示每周2节，另双周再安排一节。"
        ws.cell(row=row+4, column=1).value = "4、课时数为空或者为0，则表示该班不开设此课程。"
        ws.cell(row=row+5, column=1).value = "5、首行的学科名称和首列的班级名称必须完全一致和对应。"
        
        # 给教师表添加说明
        ws = wb['教师安排']
        row = len(classes) + 3
        ws.cell(row=row, column=1).value = "说明:"
        ws.cell(row=row+1, column=1).value = "1、教师名为空，表示该班不开设此门课或该门课还未安排教师。"
        ws.cell(row=row+2, column=1).value = "2、首行的学科名称和首列的班级名称必须完全一致和对应。"
        ws.cell(row=row+3, column=1).value = "3、带*号的表示合班上课"
        
        wb.save(filepath)
    except Exception as e:
        print(f"添加说明信息失败: {str(e)}")
    
    return send_file(
        filepath,
        as_attachment=True,
        download_name=filename,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@selfstudy_bp.route('/plans/matrix_template')
@login_required
def matrix_template():
    """下载早晚自习授课计划矩阵式模板"""
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('selfstudy.plans'))
    
    # 创建示例数据
    class_names = ['高一(1)班', '高一(2)班', '高一(3)班', '初一(1)班', '初一(2)班', '初一(3)班']
    
    # 从数据库获取所有学科，按名称排序
    subjects = Subject.query.order_by(Subject.name).all()
    subject_names = [subject.name for subject in subjects]
    
    # 如果数据库中没有学科，使用默认列表
    if not subject_names:
        subject_names = ['语文', '数学', '英语', '物理', '化学', '生物', '政治', '历史', '地理']
    
    # 创建示例课时数据
    hours_data = np.zeros((len(class_names), len(subject_names)), dtype=int)
    
    # 为示例数据设置一些默认值（适应新的学科列表）
    # 对所有班级，每个学科默认1节课
    hours_data[:, :] = 1
    
    # 主科多一些课时
    for i, subject in enumerate(subject_names):
        if subject in ['语文', '数学', '英语']:
            hours_data[:, i] = 4  # 主科4节课
        elif subject in ['物理', '化学', '生物']:
            hours_data[:, i] = 2  # 理科2节课
    
    hours_df = pd.DataFrame(hours_data, columns=subject_names)
    hours_df.insert(0, '班级', class_names)
    
    # 创建示例教师数据（所有学科使用占位教师名）
    teacher_matrix = np.empty((len(class_names), len(subject_names)), dtype=object)
    
    # 填充示例教师名
    for i in range(len(class_names)):
        for j in range(len(subject_names)):
            if i % 3 == 2 and j % 5 == 1:  # 每三行的第三行，每五列的第二列添加合班标记
                teacher_matrix[i, j] = f"示例教师_{j+1}*"
            else:
                teacher_matrix[i, j] = f"示例教师_{j+1}"
    
    teacher_df = pd.DataFrame(teacher_matrix, columns=subject_names)
    teacher_df.insert(0, '班级', class_names)
    
    # 创建临时目录保存模板文件
    temp_dir = tempfile.mkdtemp()
    temp_dirs.append(temp_dir)
    
    filepath = os.path.join(temp_dir, '早晚自习授课计划矩阵模板.xlsx')
    
    # 创建Excel写入器
    writer = pd.ExcelWriter(filepath, engine='openpyxl')
    
    # 写入两个工作表
    hours_df.to_excel(writer, sheet_name='课时安排', index=False)
    teacher_df.to_excel(writer, sheet_name='教师安排', index=False)
    
    # 保存文件
    writer.close()
    
    # 添加说明信息
    try:
        from openpyxl import load_workbook
        wb = load_workbook(filepath)
        
        # 给课时表添加说明
        ws = wb['课时安排']
        row = len(class_names) + 3
        ws.cell(row=row, column=1).value = "说明:"
        ws.cell(row=row+1, column=1).value = "1、s表示单周, d表示双周, f表示随机, 随机表示由系统确定单周还是双周。"
        ws.cell(row=row+2, column=1).value = "2、d1表示双周安排一节课, s2表示单周安排二节课"
        ws.cell(row=row+3, column=1).value = "3、4s1表示每周4节课，另外单周再安排1节, 2d1表示每周2节，另双周再安排一节。"
        ws.cell(row=row+4, column=1).value = "4、课时数为空或者为0，则表示该班不开设此课程。"
        ws.cell(row=row+5, column=1).value = "5、首行的学科名称和首列的班级名称必须完全一致和对应。"
        
        # 给教师表添加说明
        ws = wb['教师安排']
        row = len(class_names) + 3
        ws.cell(row=row, column=1).value = "说明:"
        ws.cell(row=row+1, column=1).value = "1、教师名为空，表示该班不开设此门课或该门课还未安排教师。"
        ws.cell(row=row+2, column=1).value = "2、首行的学科名称和首列的班级名称必须完全一致和对应。"
        ws.cell(row=row+3, column=1).value = "3、带*号的表示合班上课"
        
        wb.save(filepath)
    except Exception as e:
        print(f"添加说明信息失败: {str(e)}")
    
    return send_file(
        filepath,
        as_attachment=True,
        download_name='早晚自习授课计划矩阵模板.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@selfstudy_bp.route('/plans/matrix_import', methods=['GET', 'POST'])
@login_required
def matrix_import():
    """导入矩阵式早晚自习授课计划"""
    if current_user.role != 'admin':
        flash('您没有权限进行此操作!', 'danger')
        return redirect(url_for('selfstudy.plans'))
    
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('没有选择文件!', 'danger')
            return redirect(request.url)
        
        if file and file.filename.endswith(('.xlsx', '.xls')):
            # 创建临时目录保存上传文件
            temp_dir = tempfile.mkdtemp()
            temp_dirs.append(temp_dir)
            
            try:
                filename = secure_filename(file.filename)
                filepath = os.path.join(temp_dir, filename)
                file.save(filepath)
                
                # 读取Excel文件的两个工作表
                try:
                    # 获取所有工作表名
                    xl = pd.ExcelFile(filepath)
                    sheets = xl.sheet_names
                    
                    if '课时安排' not in sheets or '教师安排' not in sheets:
                        flash('Excel文件必须包含"课时安排"和"教师安排"两个工作表!', 'danger')
                        return redirect(request.url)
                    
                    # 读取两个工作表
                    hours_df = pd.read_excel(filepath, sheet_name='课时安排')
                    teachers_df = pd.read_excel(filepath, sheet_name='教师安排')
                    
                    # 检查两个表的格式是否正确
                    if '班级' not in hours_df.columns or '班级' not in teachers_df.columns:
                        flash('工作表必须包含"班级"列!', 'danger')
                        return redirect(request.url)
                    
                    # 检查两个表的班级和学科是否一致
                    if not hours_df.columns.equals(teachers_df.columns):
                        flash('两个工作表的列名（学科）必须完全一致!', 'danger')
                        return redirect(request.url)
                    
                    # 对班级名称进行标准化处理
                    # 排除掉可能是说明文本的行（通常以数字、中文顿号开头的行）
                    def is_valid_class_name(name):
                        if not isinstance(name, str):
                            return True
                        name = name.strip()
                        # 排除以数字加、顿号或点号开头的说明文本
                        if name and (name[0].isdigit() and len(name) > 1 and (name[1] == '、' or name[1] == '.')):
                            return False
                        return True
                    
                    # 解析课时数据，支持特殊格式如'd1', 's2', '4s1', '2d1'等
                    def parse_hours(hours_value):
                        """
                        解析课时数据，支持各种单双周格式
                        返回一个字典：
                        {
                            'hours': 基础课时数,
                            'week_type': 'all'|'s'|'d'|'f', # all=每周, s=单周, d=双周, f=随机
                            'extra_hours': 额外课时数,
                            'extra_week_type': 额外课时的周类型
                        }
                        """
                        if pd.isna(hours_value) or hours_value == '':
                            return {'hours': 0, 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                        
                        if isinstance(hours_value, (int, float)):
                            return {'hours': int(hours_value), 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                            
                        # 尝试解析特殊格式
                        hours_str = str(hours_value).strip().lower()
                        
                        # 简单格式: 纯数字
                        if hours_str.isdigit():
                            return {'hours': int(hours_str), 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                            
                        # 处理带单双周标记的格式
                        # 例如: 'd1'=双周1节, 's2'=单周2节
                        import re
                        
                        # 单周或双周的基本格式：s1, d2等
                        simple_pattern = r'^([sd])(\d+)$'
                        simple_match = re.match(simple_pattern, hours_str)
                        if simple_match:
                            week_type = simple_match.group(1)  # 's'=单周, 'd'=双周
                            hours = int(simple_match.group(2))  # 课时数
                            return {'hours': hours, 'week_type': week_type, 'extra_hours': None, 'extra_week_type': None}
                            
                        # 处理复合格式: 如'4s1'=每周4节+单周1节; '2d1'=每周2节+双周1节
                        complex_pattern = r'^(\d+)([sd])(\d+)$'
                        complex_match = re.match(complex_pattern, hours_str)
                        if complex_match:
                            base_hours = int(complex_match.group(1))  # 基本课时
                            extra_week_type = complex_match.group(2)  # 's'=单周, 'd'=双周
                            extra_hours = int(complex_match.group(3))  # 额外课时
                            return {
                                'hours': base_hours, 
                                'week_type': 'all',
                                'extra_hours': extra_hours,
                                'extra_week_type': extra_week_type
                            }
                        
                        # 随机单双周格式: 例如 'f2' = 随机单双周各2节
                        random_pattern = r'^f(\d+)$'
                        random_match = re.match(random_pattern, hours_str)
                        if random_match:
                            hours = int(random_match.group(1))
                            return {'hours': hours, 'week_type': 'f', 'extra_hours': None, 'extra_week_type': None}
                            
                        # 其他情况或无法解析时
                        try:
                            return {'hours': int(float(hours_str)), 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                        except:
                            # 默认返回1节课
                            flash(f"无法解析课时格式: {hours_str}，默认设置为1节课", "warning")
                            return {'hours': 1, 'week_type': 'all', 'extra_hours': None, 'extra_week_type': None}
                    
                    # 筛选有效的班级行
                    valid_rows = []
                    for i, class_name in enumerate(hours_df['班级']):
                        if is_valid_class_name(class_name):
                            valid_rows.append(i)
                    
                    # 只比较有效行
                    hours_classes = hours_df.iloc[valid_rows]['班级'].apply(lambda x: str(x).strip())
                    teachers_classes = teachers_df.iloc[valid_rows]['班级'].apply(lambda x: str(x).strip())
                    
                    if not hours_classes.equals(teachers_classes):
                        # 打印不匹配的班级名，便于调试
                        diff_classes = []
                        for i, (c1, c2) in enumerate(zip(hours_classes, teachers_classes)):
                            if c1 != c2:
                                # 使用原始索引+2（Excel行号）
                                diff_classes.append(f"行{valid_rows[i]+2}: '{c1}' vs '{c2}'")
                        
                        error_msg = '两个工作表的班级名称不一致!<br>具体差异:<br>' + '<br>'.join(diff_classes[:5])
                        if len(diff_classes) > 5:
                            error_msg += '<br>...(更多差异已省略)'
                        
                        flash(error_msg, 'danger')
                        return redirect(request.url)
                    
                    # 开始导入数据
                    success = 0  # 新增记录
                    updated = 0  # 更新记录
                    errors = 0
                    error_messages = []
                    
                    # 获取所有班级、学科和教师的映射关系
                    classes_dict = {c.name: c for c in Class.query.all()}
                    subjects_dict = {s.name: s for s in Subject.query.all()}
                    teachers_dict = {t.name: t for t in Teacher.query.all()}
                    teachers_dict.update({t.name + '*': t for t in Teacher.query.all()})  # 带星号也能识别
                    
                    # 获取所有合班设置
                    combinations_dict = {}
                    from models import ClassCombination
                    for combo in ClassCombination.query.all():
                        for subject in combo.subject.name:
                            for class_obj in combo.classes:
                                key = (class_obj.name, subject)
                                combinations_dict[key] = combo
                    
                    # 首先检查并删除已有的早晚自习授课计划
                    if request.form.get('clear_existing') == 'yes':
                        SelfStudyPlan.query.delete()
                        db.session.commit()
                        flash('已清除所有现有早晚自习授课计划!', 'warning')
                    
                    # 先处理学科列表（表头），自动创建不存在的学科
                    subject_columns = [col for col in hours_df.columns if col != '班级']
                    for subject_name in subject_columns:
                        if subject_name not in subjects_dict:
                            # 创建新学科
                            new_subject = Subject(name=subject_name)
                            db.session.add(new_subject)
                            db.session.commit()
                            subjects_dict[subject_name] = new_subject
                            flash(f"已自动创建学科: {subject_name}", "info")
                    
                    # 遍历每行，创建授课计划
                    for idx, row in hours_df.iterrows():
                        class_name = row['班级']
                        
                        if class_name not in classes_dict:
                            error_msg = f"第 {idx + 2} 行: 班级 '{class_name}' 不存在"
                            error_messages.append(error_msg)
                            errors += 1
                            continue
                        
                        # 获取相应的教师行
                        teacher_row = teachers_df.iloc[idx]
                        
                        # 对每个学科进行处理
                        for subject_name in hours_df.columns:
                            if subject_name == '班级':
                                continue
                                
                            subject = subjects_dict[subject_name]
                            
                            # 获取课时和教师
                            hours_value = row[subject_name]
                            teacher_value = teacher_row[subject_name]
                            
                            # 解析课时值
                            hours_info = parse_hours(hours_value)
                            
                            # 跳过无课时或无教师的情况
                            if hours_info['hours'] == 0 or pd.isna(teacher_value) or teacher_value == '':
                                continue
                            
                            # 处理教师名
                            is_combined = False
                            if isinstance(teacher_value, str) and teacher_value.endswith('*'):
                                is_combined = True
                                teacher_name = teacher_value.rstrip('*')
                            else:
                                teacher_name = teacher_value
                            
                            # 检查教师是否存在，不存在则创建
                            if teacher_name not in teachers_dict and teacher_name not in [t.name for t in Teacher.query.all()]:
                                # 生成新教师工号
                                current_year = datetime.datetime.now().year
                                latest_teacher = Teacher.query.filter(Teacher.staff_id.like(f'T{current_year}%')).order_by(Teacher.staff_id.desc()).first()
                                
                                if latest_teacher and latest_teacher.staff_id.startswith(f'T{current_year}'):
                                    try:
                                        seq_num = int(latest_teacher.staff_id[5:]) + 1
                                    except (ValueError, IndexError):
                                        seq_num = 1
                                else:
                                    seq_num = 1
                                    
                                staff_id = f'T{current_year}{seq_num:03d}'
                                
                                # 创建新教师
                                new_teacher = Teacher(
                                    name=teacher_name,
                                    staff_id=staff_id,
                                    gender='未知'
                                )
                                db.session.add(new_teacher)
                                db.session.commit()
                                
                                # 更新教师字典
                                teachers_dict[teacher_name] = new_teacher
                                flash(f"已自动创建教师: {teacher_name} (工号: {staff_id})", "info")
                            
                            # 获取教师对象
                            teacher = teachers_dict.get(teacher_name) or Teacher.query.filter_by(name=teacher_name).first()
                            
                            # 确保教师具有该学科的教授权限
                            if subject not in teacher.subjects:
                                teacher.subjects.append(subject)
                                db.session.commit()
                                flash(f"已为教师 {teacher_name} 分配学科 {subject_name}", "info")
                            
                            # 获取班级对象
                            class_obj = classes_dict[class_name]
                            
                            # 检查是否已存在相同班级和学科的授课计划
                            # 只有在没有选择清除所有计划的情况下才检查是否存在
                            if request.form.get('clear_existing') != 'yes':
                                existing_plan = SelfStudyPlan.query.filter_by(
                                    class_id=class_obj.id, 
                                    subject_id=subject.id
                                ).first()
                                
                                if existing_plan:
                                    # 如果选择覆盖现有数据，则更新而非跳过
                                    if request.form.get('override_existing') == 'yes':
                                        # 更新现有计划
                                        existing_plan.teacher_id = teacher.id
                                        existing_plan.hours_per_week = hours_info['hours']
                                        existing_plan.is_combined = is_combined
                                        existing_plan.combination_id = combination_id
                                        existing_plan.week_type = hours_info['week_type']
                                        existing_plan.extra_hours = hours_info['extra_hours']
                                        existing_plan.extra_week_type = hours_info['extra_week_type']
                                        updated += 1
                                        continue
                                    else:
                                        # 不覆盖，报告冲突
                                        error_msg = f"行 {idx + 2}, {class_name}-{subject_name}: 已有早晚自习授课计划"
                                        error_messages.append(error_msg)
                                        errors += 1
                                        continue
                            
                            # 处理合班情况
                            combination_id = None
                            if is_combined:
                                # 查找匹配的合班设置
                                match_found = False
                                for combo in ClassCombination.query.filter_by(subject_id=subject.id).all():
                                    # 需要检查班级对象而不是班级名称
                                    class_in_combo = False
                                    for combo_class in combo.classes:
                                        if combo_class.id == class_obj.id:
                                            class_in_combo = True
                                            break
                                    
                                    if class_in_combo:
                                        combination_id = combo.id
                                        match_found = True
                                        break
                                
                                if not match_found:
                                    error_msg = f"行 {idx + 2}, {class_name}-{subject_name}: 找不到合适的合班设置"
                                    error_messages.append(error_msg)
                                    errors += 1
                                    continue
                            
                            # 创建授课计划
                            try:
                                plan = SelfStudyPlan(
                                    class_id=class_obj.id,
                                    subject_id=subject.id,
                                    teacher_id=teacher.id,
                                    hours_per_week=hours_info['hours'],
                                    is_combined=is_combined,
                                    combination_id=combination_id,
                                    # 添加单双周信息
                                    week_type=hours_info['week_type'],
                                    extra_hours=hours_info['extra_hours'],
                                    extra_week_type=hours_info['extra_week_type']
                                )
                                
                                db.session.add(plan)
                                success += 1
                            except Exception as e:
                                error_msg = f"行 {idx + 2}, {class_name}-{subject_name}: 处理出错 - {str(e)}"
                                error_messages.append(error_msg)
                                errors += 1
                    
                    # 提交所有更改
                    db.session.commit()
                    
                    if errors > 0:
                        error_summary = '<br>'.join(error_messages[:20])
                        if len(error_messages) > 20:
                            error_summary += '<br>...(更多错误已省略)'
                        flash(f'导入完成，新增: {success}，更新: {updated}，失败: {errors}<br>{error_summary}', 'warning')
                    else:
                        if updated > 0:
                            flash(f'成功导入早晚自习授课计划！新增: {success} 条，更新: {updated} 条', 'success')
                        else:
                            flash(f'成功导入 {success} 条早晚自习授课计划!', 'success')
                    
                    return redirect(url_for('selfstudy.plans'))
                
                except Exception as e:
                    flash(f'处理Excel文件出错: {str(e)}', 'danger')
                    return redirect(request.url)
                
            except Exception as e:
                flash(f'导入出错: {str(e)}', 'danger')
            finally:
                # 删除临时目录
                shutil.rmtree(temp_dir, ignore_errors=True)
        else:
            flash('请上传Excel文件(.xlsx或.xls格式)!', 'danger')
        
        return redirect(request.url)
    
    # GET请求，显示导入页面
    # 获取所有学科列表
    subjects = Subject.query.order_by(Subject.name).all()
    return render_template('selfstudy/matrix_import.html', subjects=subjects)

# 添加早晚自习课程安排路由
@selfstudy_bp.route('/schedule')
@selfstudy_bp.route('/schedule/<int:class_id>')
@login_required
def schedule(class_id=None):
    """早晚自习课程安排页面"""
    # 获取所有班级信息
    classes = Class.query.order_by(Class.grade, Class.name).all()
    
    selected_class = None
    plans = []
    schedule_data = {}
    scheduled_plan_counts = {} # 用于存储每个plan已安排的课时数
    
    if class_id:
        selected_class = Class.query.get_or_404(class_id)
        
        # 获取该班级的授课计划
        plans = SelfStudyPlan.query.filter_by(class_id=class_id).all()
        
        # 计算每个授课计划已安排的课时数
        for plan_item in plans:
            count = SelfStudySchedule.query.filter_by(plan_id=plan_item.id, is_common_course=False).count()
            scheduled_plan_counts[plan_item.id] = count
        
        # 查询现有课程安排
        # 包含早读1和晚修1的安排
        schedule_items = SelfStudySchedule.query.filter_by(class_id=class_id).all()
        
        # 查询应用于所有班级的公共课程
        all_classes_courses = SelfStudySchedule.query.filter_by(apply_to_all_classes=True).all()
        
        # 查询禁排设置
        block_items = SelfStudyBlock.query.filter_by(class_id=class_id).all()
        blocked_cells = {(item.day, item.period): True for item in block_items}
        
        # 将课程安排转换为JSON格式
        for item in schedule_items:
            if item.day not in schedule_data:
                schedule_data[item.day] = {}
            
            is_blocked = (item.day, item.period) in blocked_cells
            
            if item.is_common_course:
                # 公共课程
                schedule_data[item.day][item.period] = {
                    'is_common_course': True,
                    'common_course_title': item.common_course_title,
                    'common_course_desc': item.common_course_desc,
                    'apply_to_all_classes': item.apply_to_all_classes,
                    'is_blocked': is_blocked
                }
            else:
                # 普通课程
                schedule_data[item.day][item.period] = {
                    'subject': item.subject.name if item.subject else None,
                    'teacher': item.teacher.name if item.teacher else None,
                    'is_common_course': False,
                    'is_blocked': is_blocked
                }
        
        # 添加应用于所有班级的公共课程（如果该时段没有被本班级的课程占用）
        for item in all_classes_courses:
            # 跳过当前班级自己的课程
            if item.class_id == class_id:
                continue
                
            if item.day not in schedule_data:
                schedule_data[item.day] = {}
            
            # 只有在该时段没有课程且没有禁排的情况下，才显示应用于所有班级的公共课程
            if item.period not in schedule_data.get(item.day, {}) and not (item.day, item.period) in blocked_cells:
                schedule_data[item.day][item.period] = {
                    'is_common_course': True,
                    'common_course_title': item.common_course_title,
                    'common_course_desc': item.common_course_desc,
                    'apply_to_all_classes': True,
                    'is_blocked': False
                }
        
        # 添加仅有禁排设置但没有课程的单元格
        for day, period in blocked_cells:
            if day not in schedule_data:
                schedule_data[day] = {}
            
            if period not in schedule_data[day]:
                schedule_data[day][period] = {
                    'subject': None,
                    'teacher': None,
                    'is_common_course': False,
                    'is_blocked': True
                }
    
    return render_template('selfstudy/schedule.html', 
                           classes=classes,
                           selected_class=selected_class,
                           plans=plans,
                           schedule_data=schedule_data,
                           scheduled_plan_counts=scheduled_plan_counts) # 传递已安排课时数

@selfstudy_bp.route('/save_schedule', methods=['POST'])
@login_required
def save_schedule():
    """保存早晚自习课程安排"""
    if request.is_json:
        data = request.get_json()
        class_id = data.get('class_id')
        schedule_data = data.get('schedule_data', [])
        
        if not class_id:
            return jsonify({'success': False, 'message': '缺少班级ID'})
        
        try:
            # 获取该班级的现有课程安排
            existing_schedules = SelfStudySchedule.query.filter_by(class_id=class_id).all()
            existing_dict = {(item.day, item.period): item for item in existing_schedules}
            
            # 获取该班级的计划关联
            plans = SelfStudyPlan.query.filter_by(class_id=class_id).all()
            # 创建学科名称-教师名称到计划ID的映射
            subject_teacher_to_plan = {}
            for plan in plans:
                key = (plan.subject.name, plan.teacher.name)
                subject_teacher_to_plan[key] = plan.id
            
            # 处理新的课程安排
            for item in schedule_data:
                day = int(item.get('day'))
                period = item.get('period')
                item_type = item.get('type')
                
                # 检查是否存在现有记录
                key = (day, period)
                existing_item = existing_dict.get(key)
                
                # 根据类型处理
                if item_type == 'empty':
                    # 空单元格，删除现有课程
                    if existing_item:
                        db.session.delete(existing_item)
                
                elif item_type == 'blocked':
                    # 禁排单元格，确保已经有禁排设置，在 toggle_block 中处理
                    continue
                
                elif item_type == 'common':
                    # 公共课程
                    title = item.get('title', '')
                    desc = item.get('desc', '')
                    apply_to_all = item.get('applyToAll', False)
                    
                    if existing_item:
                        # 更新现有记录
                        existing_item.is_common_course = True
                        existing_item.common_course_title = title
                        existing_item.common_course_desc = desc
                        existing_item.apply_to_all_classes = apply_to_all
                    else:
                        # 创建新记录
                        new_schedule = SelfStudySchedule(
                            class_id=class_id,
                            day=day,
                            period=period,
                            is_common_course=True,
                            common_course_title=title,
                            common_course_desc=desc,
                            apply_to_all_classes=apply_to_all
                        )
                        db.session.add(new_schedule)
                
                elif item_type == 'regular':
                    # 常规课程
                    subject_name = item.get('subject', '')
                    teacher_name = item.get('teacher', '')
                    
                    # 查找对应的授课计划
                    plan_id = subject_teacher_to_plan.get((subject_name, teacher_name))
                    
                    if not plan_id:
                        # 找不到匹配的授课计划，尝试只按学科名匹配
                        for (subj, teach), pid in subject_teacher_to_plan.items():
                            if subj == subject_name:
                                plan_id = pid
                                break
                    
                    if plan_id:
                        if existing_item:
                            # 更新现有记录
                            existing_item.plan_id = plan_id
                            existing_item.is_common_course = False
                            existing_item.common_course_title = None
                            existing_item.common_course_desc = None
                            existing_item.apply_to_all_classes = False
                        else:
                            # 创建新记录
                            new_schedule = SelfStudySchedule(
                                class_id=class_id,
                                day=day,
                                period=period,
                                plan_id=plan_id,
                                is_common_course=False
                            )
                            db.session.add(new_schedule)
            
            # 提交更改
            db.session.commit()
            return jsonify({'success': True, 'message': '课程表保存成功'})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': f'保存失败: {str(e)}'})
    
    return jsonify({'success': False, 'message': '无效的请求格式'})

@selfstudy_bp.route('/toggle_block', methods=['POST'])
@login_required
def toggle_block():
    """设置或取消禁排"""
    if request.is_json:
        data = request.get_json()
        class_id = data.get('class_id')
        day = data.get('day')
        period = data.get('period')
        action = data.get('action', 'block')  # 'block' or 'unblock'
        apply_to_all = data.get('apply_to_all', False)  # 是否应用到全校所有班级
        
        if not all([day, period]):
            return jsonify({'success': False, 'message': '缺少必要参数'})
        
        # 全校禁排需要管理员权限
        if apply_to_all and current_user.role != 'admin':
            return jsonify({'success': False, 'message': '只有管理员才能设置全校禁排'})
        
        try:
            # 转换为整数
            day = int(day)
            
            if apply_to_all:
                # 获取所有班级
                classes = Class.query.all()
                affected_count = 0
                
                for class_obj in classes:
                    if action == 'block':
                        # 检查是否已存在禁排设置
                        existing_block = SelfStudyBlock.query.filter_by(
                            class_id=class_obj.id,
                            day=day,
                            period=period
                        ).first()
                        
                        if not existing_block:
                            # 创建新的禁排设置
                            new_block = SelfStudyBlock(
                                class_id=class_obj.id,
                                day=day,
                                period=period
                            )
                            db.session.add(new_block)
                            
                            # 如果此位置有课程安排，则删除
                            schedule_item = SelfStudySchedule.query.filter_by(
                                class_id=class_obj.id,
                                day=day,
                                period=period,
                                is_common_course=False  # 保留公共课程
                            ).first()
                            
                            if schedule_item:
                                db.session.delete(schedule_item)
                                
                            affected_count += 1
                    
                    elif action == 'unblock':
                        # 查找并删除禁排设置
                        block_item = SelfStudyBlock.query.filter_by(
                            class_id=class_obj.id,
                            day=day,
                            period=period
                        ).first()
                        
                        if block_item:
                            db.session.delete(block_item)
                            affected_count += 1
                
                db.session.commit()
                
                action_text = "禁排" if action == 'block' else "解除禁排"
                return jsonify({
                    'success': True, 
                    'message': f'已为全校{affected_count}个班级{action_text}',
                    'affected_count': affected_count
                })
            
            else:
                # 单班级禁排原有逻辑
                if not class_id:
                    return jsonify({'success': False, 'message': '缺少班级ID'})
                
                class_id = int(class_id)
                
                if action == 'block':
                    # 检查是否已存在禁排设置
                    existing_block = SelfStudyBlock.query.filter_by(
                        class_id=class_id,
                        day=day,
                        period=period
                    ).first()
                    
                    if not existing_block:
                        # 创建新的禁排设置
                        new_block = SelfStudyBlock(
                            class_id=class_id,
                            day=day,
                            period=period
                        )
                        db.session.add(new_block)
                        
                        # 如果此位置有课程安排，则删除
                        schedule_item = SelfStudySchedule.query.filter_by(
                            class_id=class_id,
                            day=day,
                            period=period
                        ).first()
                        
                        if schedule_item:
                            db.session.delete(schedule_item)
                        
                        db.session.commit()
                    
                    return jsonify({'success': True, 'message': '已设置禁排'})
                
                elif action == 'unblock':
                    # 查找并删除禁排设置
                    block_item = SelfStudyBlock.query.filter_by(
                        class_id=class_id,
                        day=day,
                        period=period
                    ).first()
                    
                    if block_item:
                        db.session.delete(block_item)
                        db.session.commit()
                    
                    return jsonify({'success': True, 'message': '已取消禁排'})
                
                else:
                    return jsonify({'success': False, 'message': '无效的操作类型'})
        
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': f'操作失败: {str(e)}'})
    
    return jsonify({'success': False, 'message': '无效的请求格式'})

# 自动排课辅助函数
def auto_generate_schedule(class_id, clear_existing=True, sunday_head_teacher=False):
    """自动生成早晚自习课程安排"""
    try:
        # 获取班级信息
        class_obj = Class.query.get_or_404(class_id)
        
        # 获取该班级的所有授课计划
        all_plans = SelfStudyPlan.query.filter_by(class_id=class_id).all()
        
        if not all_plans:
            return False, "该班级没有可用的授课计划，无法进行自动排课"
        
        # 过滤掉公共课程的授课计划
        plans = []
        for plan in all_plans:
            # 获取学科信息
            subject = Subject.query.get(plan.subject_id)
            
            # 跳过公共课程
            if not subject or "公共" in subject.name:
                continue
            
            plans.append(plan)
        
        if not plans:
            return False, "该班级仅有公共课程授课计划，无法进行自动排课"
        
        # 获取禁排设置
        block_items = SelfStudyBlock.query.filter_by(class_id=class_id).all()
        blocked_cells = {(item.day, item.period) for item in block_items}
        
        # 获取已设置为公共课程的单元格
        public_course_cells = set()
        existing_public_courses = SelfStudySchedule.query.filter_by(is_common_course=True).all()
        for course in existing_public_courses:
            # 公共课程（包括应用于所有班级的和班级自己的）
            if course.apply_to_all_classes or course.class_id == class_id:
                public_course_cells.add((course.day, course.period))
        
        # 如果选择清除现有课程，则删除非禁排的普通课程安排（保留公共课程）
        if clear_existing:
            # 删除该班级的普通课程安排，但保留禁排和公共课程
            existing_schedules = SelfStudySchedule.query.filter_by(
                class_id=class_id, 
                is_common_course=False
            ).all()
            
            for schedule in existing_schedules:
                if (schedule.day, schedule.period) not in blocked_cells:
                    db.session.delete(schedule)
            db.session.commit()
        
        # 统计各个学科的总课时数和已排课时数
        subject_hours = {}
        for plan in plans:
            subject_id = plan.subject_id
            if subject_id not in subject_hours:
                subject_hours[subject_id] = {
                    'total': 0,  # 总课时数
                    'scheduled': 0,  # 已排课时数
                    'plan': plan  # 授课计划
                }
            
            subject_hours[subject_id]['total'] += plan.hours_per_week or 0
            if plan.extra_hours:
                subject_hours[subject_id]['total'] += plan.extra_hours
        
        # 获取现有课程安排，用于统计已排课时
        existing_schedules = SelfStudySchedule.query.filter_by(class_id=class_id, is_common_course=False).all()
        for schedule in existing_schedules:
            if schedule.plan and schedule.plan.subject_id in subject_hours:
                subject_hours[schedule.plan.subject_id]['scheduled'] += 1
        
        # 计算需要排课的总课时数
        total_periods = 0
        for subject_data in subject_hours.values():
            remaining = subject_data['total'] - subject_data['scheduled']
            if remaining > 0:
                total_periods += remaining
        
        if total_periods == 0:
            return True, "班级课程已排满，无需再排"
        
        # 可用时段：早读1和晚修1，一周7天（周一到周日）
        available_periods = []
        for day in range(1, 8):  # 1-7表示周一到周日
            for period in ['早读1', '晚修1']:
                # 如果启用了星期天晚自习班主任上课，则跳过星期天晚修时段（从一开始就排除，避免重复排课）
                if sunday_head_teacher and day == 7 and period == '晚修1':
                    continue
                
                # 排除已禁排和已设置为公共课程的单元格
                if (day, period) not in blocked_cells and (day, period) not in public_course_cells:
                    # 检查该时段是否已有课程
                    existing = False
                    for schedule in existing_schedules:
                        if schedule.day == day and schedule.period == period:
                            existing = True
                            break
                    
                    if not existing:
                        available_periods.append((day, period))
        
        # 输出详细的可用时段和总课时信息用于调试
        print(f"班级: {class_obj.name}, 可用时段: {len(available_periods)}节, 需排课时: {total_periods}节")
        print(f"可用时段: {available_periods}")
        
        # 检查可用时段是否足够
        if len(available_periods) < total_periods:
            # 不再直接返回失败，而是给出警告并继续排课
            warning_message = f"警告：可用时段（{len(available_periods)}节）少于需要排课的总课时（{total_periods}节），将进行部分排课"
            print(warning_message)
            
            # 如果可用时段为0，则无法排课
            if len(available_periods) == 0:
                return False, "没有可用时段，无法进行排课"
        elif len(available_periods) == total_periods:
            print(f"班级: {class_obj.name} - 可用时段刚好等于需要排课的总课时，将尝试完全排满")
        else:
            print(f"班级: {class_obj.name} - 可用时段充足，共{len(available_periods)}节，需要排{total_periods}节")
        
        # 修改排课优先级算法，将所有授课计划学科都排上，而不是根据剩余课时优先排序
        # 按照优先级排序学科（把所有学科按照是否主科、名称排序，确保每门学科都有机会被排课）
        sorted_subjects = sorted(
            subject_hours.items(),
            key=lambda x: (
                # 优先保证每门科目至少排一节课
                1 if x[1]['scheduled'] == 0 else 0,
                # 然后按正常优先级排序
                x[1]['total'] - x[1]['scheduled'], 
                x[1]['total']
            ),
            reverse=True
        )
        
        # 开始排课
        schedules_created = 0
        subject_counts = {}  # 记录每个学科实际排了多少课
        
        # 第一轮：确保每门学科至少排一节课
        skipped_subjects = []  # 记录因时段不足而跳过的学科
        for subject_id, subject_data in sorted_subjects:
            plan = subject_data['plan']
            remaining = subject_data['total'] - subject_data['scheduled']
            subject_name = Subject.query.get(subject_id).name if Subject.query.get(subject_id) else "未知学科"
            
            # 初始化计数
            subject_counts[subject_id] = 0
            
            # 如果学科还需要排课，先安排一节确保覆盖
            if remaining > 0:
                if not available_periods:
                    print(f"警告: 无法为学科 '{subject_name}' 安排至少一节课，时段不足")
                    skipped_subjects.append(subject_id)
                    continue
                
                # 选择时段
                day, period = available_periods.pop(0)
                
                try:
                    # 创建课程安排
                    new_schedule = SelfStudySchedule(
                        class_id=class_id,
                        day=day,
                        period=period,
                        plan_id=plan.id,
                        is_common_course=False
                    )
                    
                    db.session.add(new_schedule)
                    schedules_created += 1
                    subject_counts[subject_id] += 1
                    
                    print(f"第一轮：已为学科 '{subject_name}' 在 {day}(周){period} 安排第1节课，确保覆盖")
                except Exception as e:
                    print(f"排课时出错: {str(e)}")
                    # 如果创建失败，将时段放回队列末尾
                    available_periods.append((day, period))
        
        # 第二轮：按优先级排序剩余课时
        for subject_id, subject_data in sorted_subjects:
            # 跳过已被放弃的学科
            if subject_id in skipped_subjects:
                continue
                
            plan = subject_data['plan']
            # 计算已排课后的剩余课时
            remaining = subject_data['total'] - subject_data['scheduled'] - subject_counts[subject_id]
            subject_name = Subject.query.get(subject_id).name if Subject.query.get(subject_id) else "未知学科"
            
            print(f"第二轮：为学科 '{subject_name}' 排课，剩余需要排{remaining}节课")
            
            for i in range(remaining):
                if not available_periods:
                    print(f"警告: 学科 '{subject_name}' 还需排{remaining-i}节课，但没有更多可用时段")
                    break
                    
                # 选择时段
                day, period = available_periods.pop(0)
                
                try:
                    # 创建课程安排
                    new_schedule = SelfStudySchedule(
                        class_id=class_id,
                        day=day,
                        period=period,
                        plan_id=plan.id,
                        is_common_course=False
                    )
                    
                    db.session.add(new_schedule)
                    schedules_created += 1
                    subject_counts[subject_id] += 1
                    
                    print(f"第二轮：已为学科 '{subject_name}' 在 {day}(周){period} 安排额外第{i+1}节课，剩余{remaining-i-1}节待排")
                except Exception as e:
                    print(f"排课时出错: {str(e)}")
                    # 如果创建失败，将时段放回队列末尾
                    available_periods.append((day, period))
        
        # 处理星期天晚自习班主任上课的情况 - 修改为避免重复计算课时
        if sunday_head_teacher:
            # 检查星期天晚自习是否已被禁排或设置为公共课程
            if (7, '晚修1') not in blocked_cells and (7, '晚修1') not in public_course_cells:
                # 检查是否已有课程安排
                existing_sunday_schedule = None
                for schedule in existing_schedules:
                    if schedule.day == 7 and schedule.period == '晚修1':
                        existing_sunday_schedule = schedule
                        break
                
                # 如果此时段已经安排了课程并且不需要清除现有课程，则不再重复安排
                if existing_sunday_schedule and not clear_existing:
                    print(f"星期天晚自习时段已有课程安排，保留现有安排")
                else:
                    # 获取班主任信息
                    head_teacher = class_obj.head_teacher
                    
                    if head_teacher:
                        # 1. 首先，检查这个班级的星期天晚自习是否已经排了课程
                        should_skip = False
                        if existing_sunday_schedule and existing_sunday_schedule.teacher and existing_sunday_schedule.teacher.id == head_teacher.id:
                            print(f"星期天晚自习已经安排了班主任 {head_teacher.name} 的课程，无需重新安排")
                            should_skip = True
                        
                        if not should_skip:    
                            # 2. 查找班主任是否有授课计划，优先使用班主任尚未排满课时的授课计划
                            head_teacher_plan = None
                            head_teacher_plans = []  # 收集班主任的所有授课计划
                            
                            # 首先收集班主任的所有授课计划
                            for plan in all_plans:
                                if plan.teacher_id == head_teacher.id:
                                    plan_info = {
                                        'plan': plan,
                                        'subject_id': plan.subject_id,
                                        'subject_name': Subject.query.get(plan.subject_id).name if Subject.query.get(plan.subject_id) else "未知科目",
                                        'current_count': 0,
                                        'total_plan': 0,
                                        'remaining': 0
                                    }
                                    
                                    # 计算已排课时和总计划课时
                                    if plan.subject_id in subject_counts and plan.subject_id in subject_hours:
                                        plan_info['current_count'] = subject_counts[plan.subject_id] + subject_hours[plan.subject_id]['scheduled']
                                        plan_info['total_plan'] = subject_hours[plan.subject_id]['total']
                                        plan_info['remaining'] = plan_info['total_plan'] - plan_info['current_count']
                                    
                                    head_teacher_plans.append(plan_info)
                            
                            # 按剩余课时从多到少排序，优先使用还有剩余课时的计划
                            head_teacher_plans.sort(key=lambda x: x['remaining'], reverse=True)
                            
                            # 优先选择有剩余课时的计划
                            for plan_info in head_teacher_plans:
                                if plan_info['remaining'] > 0:
                                    head_teacher_plan = plan_info['plan']
                                    subject_id = plan_info['subject_id']
                                    print(f"选择班主任 {head_teacher.name} 的 {plan_info['subject_name']} 课程，剩余课时：{plan_info['remaining']}")
                                    break
                            
                            # 如果所有科目都排满了，选择第一个科目（后面会特殊处理）
                            if not head_teacher_plan and head_teacher_plans:
                                head_teacher_plan = head_teacher_plans[0]['plan']
                                subject_id = head_teacher_plan.subject_id
                                print(f"班主任 {head_teacher.name} 的所有科目都排满了，使用 {head_teacher_plans[0]['subject_name']}")
                            
                            # 3. 如果没有合适的班主任授课计划，尝试查找班会课程
                            if not head_teacher_plan:
                                for plan in all_plans:
                                    subject = Subject.query.get(plan.subject_id)
                                    if subject and (subject.name == "班会" or "班会" in subject.name):
                                        head_teacher_plan = plan
                                        break
                            
                            # 4. 创建课程安排
                            if head_teacher_plan:
                                # 删除已有安排（如果存在）
                                if existing_sunday_schedule:
                                    db.session.delete(existing_sunday_schedule)
                                    
                                # 使用班主任的授课计划安排常规课程（非公共课程）
                                subject_name = Subject.query.get(head_teacher_plan.subject_id).name if Subject.query.get(head_teacher_plan.subject_id) else "未知学科"
                                subject_id = head_teacher_plan.subject_id
                                
                                # 关键：验证该科目没有超出计划课时
                                plan_already_full = False
                                if subject_id in subject_counts and subject_id in subject_hours:
                                    current_count = subject_counts[subject_id] + subject_hours[subject_id]['scheduled']
                                    total_plan = subject_hours[subject_id]['total']
                                    
                                    if current_count >= total_plan:
                                        plan_already_full = True
                                        print(f"警告：班主任 {head_teacher.name} 的 {subject_name} 已排满课时 ({current_count}/{total_plan})，改为安排班会")
                                
                                if not plan_already_full:
                                    head_teacher_course = SelfStudySchedule(
                                        class_id=class_id,
                                        day=7,  # 星期天
                                        period='晚修1',
                                        plan_id=head_teacher_plan.id,
                                        is_common_course=False  # 设为常规课程
                                    )
                                    
                                    db.session.add(head_teacher_course)
                                    schedules_created += 1
                                    
                                    # 统计到相应学科的课时中
                                    if subject_id in subject_counts:
                                        subject_counts[subject_id] += 1
                                        
                                    print(f"已为班级 {class_obj.name} 安排星期天晚自习由班主任 {head_teacher.name} 上 {subject_name} 课")
                                else:
                                    # 即使课时已满，仍然使用班主任的课程，而不是创建公共课程
                                    head_teacher_course = SelfStudySchedule(
                                        class_id=class_id,
                                        day=7,  # 星期天
                                        period='晚修1',
                                        plan_id=head_teacher_plan.id,
                                        is_common_course=False  # 设为常规课程
                                    )
                                    
                                    db.session.add(head_teacher_course)
                                    schedules_created += 1
                                    
                                    # 虽然超出课时，但仍然计入统计
                                    if subject_id in subject_counts:
                                        subject_counts[subject_id] += 1
                                        
                                    print(f"已为班级 {class_obj.name} 安排星期天晚自习由班主任 {head_teacher.name} 上 {subject_name} 课（注意：已超出计划课时）")
                            else:
                                # 如果找不到班主任的授课计划，尝试创建一个班会课程作为常规课程（不是公共课程）
                                if existing_sunday_schedule:
                                    db.session.delete(existing_sunday_schedule)
                                
                                # 查找或创建班会学科
                                class_meeting_subject = Subject.query.filter_by(name="班会").first()
                                if not class_meeting_subject:
                                    class_meeting_subject = Subject(name="班会")
                                    db.session.add(class_meeting_subject)
                                    db.session.flush()
                                
                                # 创建临时授课计划
                                temp_plan = SelfStudyPlan(
                                    class_id=class_id,
                                    subject_id=class_meeting_subject.id,
                                    teacher_id=head_teacher.id,
                                    hours_per_week=1
                                )
                                db.session.add(temp_plan)
                                db.session.flush()
                                
                                # 使用这个临时计划创建常规课程
                                head_teacher_course = SelfStudySchedule(
                                    class_id=class_id,
                                    day=7,  # 星期天
                                    period='晚修1',
                                    plan_id=temp_plan.id,
                                    is_common_course=False  # 设为常规课程，不是公共课程
                                )
                                
                                db.session.add(head_teacher_course)
                                schedules_created += 1
                                print(f"已为班级 {class_obj.name} 安排星期天晚自习班会课，由班主任 {head_teacher.name} 负责（创建临时班会授课计划）")
        
        # 提交前检查是否已经成功创建了课程安排
        if schedules_created == 0:
            db.session.rollback()
            return False, "排课失败，未能创建任何课程安排"
            
        try:
            db.session.commit()
            
            # 生成详细的排课结果报告
            subject_report = []
            total_needed = sum(subject_hours[subject_id]['total'] - subject_hours[subject_id]['scheduled'] for subject_id in subject_counts.keys())
            total_scheduled = sum(subject_counts.values())
            
            for subject_id, count in subject_counts.items():
                subject_name = Subject.query.get(subject_id).name if Subject.query.get(subject_id) else "未知学科"
                total = subject_hours[subject_id]['total'] - subject_hours[subject_id]['scheduled']
                if count < total:
                    subject_report.append(f"{subject_name}: 计划{total}节，实际排了{count}节")
                else:
                    subject_report.append(f"{subject_name}: 全部{total}节已排")
            
            report = "；".join(subject_report)
            
            # 添加班主任排课信息
            if sunday_head_teacher and class_obj.head_teacher:
                report += f"；另外已安排星期天晚自习由班主任{class_obj.head_teacher.name}上课"
            
            # 根据排课情况给出不同的消息
            if total_scheduled < total_needed:
                return True, f"自动排课部分完成，共需要排{total_needed}节课，成功安排了{total_scheduled}节。{report}"
            else:
                return True, f"自动排课完成，成功安排了{schedules_created}节课。{report}"
        except Exception as e:
            db.session.rollback()
            return False, f"提交排课数据时出错: {str(e)}"
    
    except Exception as e:
        db.session.rollback()
        error_info = traceback.format_exc()
        print(f"排课错误: {error_info}")
        return False, f"排课过程出错: {str(e)}"

@selfstudy_bp.route('/auto_schedule', methods=['POST'])
@login_required
def auto_schedule():
    """自动生成早晚自习课程安排"""
    if request.is_json:
        data = request.get_json()
        class_id = data.get('class_id')
        clear_existing = data.get('clear_existing', True)
        schedule_scope = data.get('schedule_scope', 'single')  # 'single' 或 'all'
        sunday_head_teacher = data.get('sunday_head_teacher', False)  # 星期天晚自习是否由班主任上课
        
        if schedule_scope == 'all':
            # 全校排课
            try:
                success, message = auto_generate_schedule_for_all_classes(clear_existing, sunday_head_teacher)
                
                return jsonify({
                    'success': success,
                    'message': message,
                    'redirect': url_for('selfstudy.schedule', class_id=class_id) if success else None
                })
            except Exception as e:
                db.session.rollback()
                return jsonify({'success': False, 'message': f'全校自动排课失败: {str(e)}'})
        else:
            # 单班级排课
            if not class_id:
                return jsonify({'success': False, 'message': '缺少班级ID'})
            
            try:
                success, message = auto_generate_schedule(class_id, clear_existing, sunday_head_teacher)
                
                return jsonify({
                    'success': success,
                    'message': message,
                    'redirect': url_for('selfstudy.schedule', class_id=class_id) if success else None
                })
            except Exception as e:
                db.session.rollback()
                return jsonify({'success': False, 'message': f'自动排课失败: {str(e)}'})
    
    return jsonify({'success': False, 'message': '无效的请求格式'})

# 全校自动排课函数
def auto_generate_schedule_for_all_classes(clear_existing=True, sunday_head_teacher=False):
    """为所有班级自动生成早晚自习课程安排"""
    # 获取所有班级
    classes = Class.query.order_by(Class.grade, Class.name).all()
    
    success_count = 0
    failure_count = 0
    results = []
    errors_by_reason = {}  # 按失败原因统计
    
    for class_obj in classes:
        try:
            # 检查该班级是否有授课计划
            has_plans = SelfStudyPlan.query.filter_by(class_id=class_obj.id).first() is not None
            
            if has_plans:
                # 调用单班级排课函数
                success, message = auto_generate_schedule(class_obj.id, clear_existing, sunday_head_teacher)
                
                if success:
                    success_count += 1
                else:
                    failure_count += 1
                    # 按失败原因分类统计
                    if message not in errors_by_reason:
                        errors_by_reason[message] = 0
                    errors_by_reason[message] += 1
            else:
                failure_count += 1
                reason = "没有可用的授课计划"
                if reason not in errors_by_reason:
                    errors_by_reason[reason] = 0
                errors_by_reason[reason] += 1
                message = reason
            
            results.append({
                'class_name': class_obj.name,
                'success': has_plans and success,
                'message': message
            })
        except Exception as e:
            failure_count += 1
            reason = f"处理出错: {str(e)}"
            if "通用错误" not in errors_by_reason:
                errors_by_reason["通用错误"] = 0
            errors_by_reason["通用错误"] += 1
            
            results.append({
                'class_name': class_obj.name,
                'success': False,
                'message': reason
            })
    
    # 生成结果消息
    if success_count == 0:
        failure_details = "，".join([f"{reason}: {count}个班级" for reason, count in errors_by_reason.items()])
        return False, f"没有班级成功完成自动排课。失败详情：{failure_details}"
    
    message = f"全校排课完成，成功: {success_count}个班级，失败: {failure_count}个班级"
    if failure_count > 0:
        failure_details = "，".join([f"{reason}: {count}个班级" for reason, count in errors_by_reason.items()])
        message += f"。失败详情：{failure_details}"
    
    if sunday_head_teacher:
        message += "。已安排所有班级的星期天晚自习由各班班主任上课"
    
    return True, message

@selfstudy_bp.route('/delete_all_schedules', methods=['POST'])
@login_required
def delete_all_schedules():
    """删除全校早晚自习课程安排"""
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': '只有管理员才能执行此操作'})
    
    try:
        # 获取是否保留禁排设置的选项
        keep_blocks = request.json.get('keep_blocks', False)
        
        # 统计删除的课程安排数量
        count = SelfStudySchedule.query.count()
        
        if keep_blocks:
            # 如果保留禁排设置，则单独删除课程安排
            SelfStudySchedule.query.delete()
        else:
            # 同时删除课程安排和禁排设置
            SelfStudySchedule.query.delete()
            block_count = SelfStudyBlock.query.count()
            SelfStudyBlock.query.delete()
            count += block_count
        
        db.session.commit()
        
        message = f"已成功删除全校课表，共清除{count}条记录。"
        if keep_blocks:
            message += "（已保留禁排设置）"
        
        return jsonify({
            'success': True, 
            'message': message
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False, 
            'message': f'删除失败: {str(e)}'
        })

@selfstudy_bp.route('/get_swappable_slots', methods=['POST'])
@login_required
def get_swappable_slots():
    """计算可交换课程的单元格"""
    if not request.is_json:
        return jsonify({'success': False, 'message': '无效的请求格式'})
    
    data = request.get_json()
    class_id = data.get('class_id')
    source_day = data.get('day')
    source_period = data.get('period')
    source_subject = data.get('subject')
    source_teacher = data.get('teacher')
    
    if not all([class_id, source_day, source_period]):
        return jsonify({'success': False, 'message': '缺少必要参数'})
    
    try:
        # 转换数据类型
        class_id = int(class_id)
        source_day = int(source_day)
        
        # 获取源单元格的课程信息
        source_schedule = SelfStudySchedule.query.filter_by(
            class_id=class_id, 
            day=source_day, 
            period=source_period,
            is_common_course=False # 只考虑常规自习
        ).first()
        
        if not source_schedule or not source_schedule.plan_id:
            return jsonify({'success': False, 'message': '源单元格无有效课程'})
        
        # 获取源课程的计划和教师信息
        source_plan = SelfStudyPlan.query.get(source_schedule.plan_id)
        if not source_plan:
            return jsonify({'success': False, 'message': '找不到源课程的计划信息'})
        
        source_teacher_id = source_plan.teacher_id
        
        # 获取禁排设置
        blocked_cells = SelfStudyBlock.query.filter_by(class_id=class_id).all()
        blocked_slots = {(block.day, block.period) for block in blocked_cells}
        
        # 计算可交换的单元格
        swappable_slots = []
        
        # 遍历所有可能的单元格
        for day in range(1, 8):  # 1-7表示周一到周日
            # 只处理与源单元格相同时段的单元格（早读1只能和早读1换，晚修1只能和晚修1换）
            period = source_period
            
            # 排除源单元格本身和禁排单元格
            if (day == source_day and period == source_period) or (day, period) in blocked_slots:
                continue
            
            # 检查该单元格是否有公共课程
            common_course = SelfStudySchedule.query.filter_by(
                day=day, 
                period=period, 
                is_common_course=True
            ).first()
            if common_course:
                # 跳过公共课程
                continue
            
            # 检查当前单元格的课程信息
            target_schedule = SelfStudySchedule.query.filter_by(
                class_id=class_id, 
                day=day, 
                period=period,
                is_common_course=False
            ).first()
            
            # ============= 关键修改：检查教师冲突 =============
            # 检查目标日期当前时段，源教师是否已有其他课程
            if source_teacher_id:
                teacher_conflict = SelfStudySchedule.query.join(SelfStudyPlan).filter(
                    SelfStudySchedule.day == day,
                    SelfStudySchedule.period == period,
                    SelfStudyPlan.teacher_id == source_teacher_id,
                    SelfStudySchedule.class_id != class_id  # 排除当前班级
                ).first()
                
                if teacher_conflict:
                    # 源教师在目标日期时段已有课程，不可交换
                    continue
            
            # 如果目标单元格有课程，还需检查目标教师在源日期时段是否有冲突
            if target_schedule and target_schedule.plan_id:
                target_plan = SelfStudyPlan.query.get(target_schedule.plan_id)
                if target_plan and target_plan.teacher_id:
                    target_teacher_id = target_plan.teacher_id
                    
                    # 检查目标教师在源单元格时段是否已有其他课程
                    target_teacher_conflict = SelfStudySchedule.query.join(SelfStudyPlan).filter(
                        SelfStudySchedule.day == source_day,
                        SelfStudySchedule.period == source_period,
                        SelfStudyPlan.teacher_id == target_teacher_id,
                        SelfStudySchedule.class_id != class_id  # 排除当前班级
                    ).first()
                    
                    if target_teacher_conflict:
                        # 目标教师在源日期时段已有课程，不可交换
                        continue
            # ============= 关键修改结束 =============
            
            # 添加到可交换列表
            slot_info = {
                'day': day,
                'period': period,
                'has_subject': False,
                'conflict_level': 0  # 0=无冲突, 1=轻微冲突, 2=严重冲突
            }
            
            if target_schedule:
                # 有常规课程的单元格
                slot_info['has_subject'] = True
                
                target_plan = SelfStudyPlan.query.get(target_schedule.plan_id) if target_schedule.plan_id else None
                
                if target_plan:
                    slot_info['subject'] = target_plan.subject.name if target_plan.subject else '未知学科'
                    slot_info['teacher'] = target_plan.teacher.name if target_plan.teacher else '未知教师'
                    
                    # 添加其他冲突逻辑...
            
            swappable_slots.append(slot_info)
        
        # 返回可交换的单元格列表
        return jsonify({
            'success': True,
            'source': {
                'day': source_day,
                'period': source_period,
                'subject': source_subject,
                'teacher': source_teacher
            },
            'swappable_slots': swappable_slots
        })
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'计算可交换单元格失败: {str(e)}'})

@selfstudy_bp.route('/add_lesson', methods=['POST'])
@login_required
def add_selfstudy_lesson():
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': '您没有权限进行此操作!'})

    class_id = request.form.get('class_id', type=int)
    plan_id = request.form.get('plan_id', type=int)
    day = request.form.get('day', type=int)
    period = request.form.get('period', type=str) # 早晚自习的period是字符串

    if not all([class_id, plan_id, day, period]):
        return jsonify({'success': False, 'message': '参数不完整!'})

    # 获取早晚自习授课计划
    plan = SelfStudyPlan.query.get_or_404(plan_id)
    if plan.class_id != class_id:
        return jsonify({'success': False, 'message': '授课计划与班级不匹配!'})

    # 检查该时段是否已被本班占用 (早晚自习)
    existing_selfstudy = SelfStudySchedule.query.filter_by(class_id=class_id, day=day, period=period).first()
    if existing_selfstudy:
        if existing_selfstudy.is_common_course:
            return jsonify({'success': False, 'message': f"该时段已安排公共活动: {existing_selfstudy.common_course_title}"})
        else:
            return jsonify({'success': False, 'message': '该时段已有早晚自习安排!'})

    # 检查该时段是否有禁排设置
    block = SelfStudyBlock.query.filter_by(class_id=class_id, day=day, period=period).first()
    if block:
        return jsonify({'success': False, 'message': '该时段已禁排!'})
        
    # 检查应用于所有班级的公共课程 (例如全校统一的早读或晚自习活动)
    # 注意: SelfStudySchedule 中 is_common_course 和 apply_to_all_classes 字段
    common_selfstudy_all_classes = SelfStudySchedule.query.filter_by(
        day=day, 
        period=period, 
        is_common_course=True,
        apply_to_all_classes=True
    ).first()
    if common_selfstudy_all_classes:
        # 如果这个公共课程不是当前班级自己设置的（虽然 apply_to_all_classes=True 通常意味着不是特定班级设置的）
        # 但为了保险起见，可以检查 common_selfstudy_all_classes.class_id (如果 class_id 对全体公共课无意义则不需要)
        return jsonify({'success': False, 'message': f'该时段已设置为全校公共活动 "{common_selfstudy_all_classes.common_course_title}"!'})

    # (可选) 检查教师在该时段是否已有其他正课或早晚自习
    # 假设早晚自习也需要考虑教师冲突
    # 需要将早晚自习的 day (1-7) 和 period ('早读1', '晚修1') 对应到正课的 day_of_week 和 period (整数)
    # 这是一个复杂点，如果早晚自习的时段与正课时段不直接对应或重叠，此检查可能不需要或需要特定逻辑转换。
    # 暂时简化，先不检查教师在正课中的冲突，只检查教师在其他班级或其他类型的早晚自习中的冲突（如果适用）。
    
    # 检查教师在同一天的同一类型自习时段（早读/晚修）是否已经有安排 (跨班级)
    # 例如，一个老师不能同时在两个班的同一个早读时段。
    # 注意: SelfStudyPlan 关联了 teacher_id
    teacher_conflict_selfstudy = SelfStudySchedule.query.join(SelfStudyPlan).filter(
        SelfStudySchedule.day == day,
        SelfStudySchedule.period == period,
        SelfStudyPlan.teacher_id == plan.teacher_id,
        SelfStudySchedule.class_id != class_id # 排除当前班级自身（虽然前面已经检查过）
    ).first()
    if teacher_conflict_selfstudy:
        conflicting_class = Class.query.get(teacher_conflict_selfstudy.class_id)
        return jsonify({'success': False, 'message': f'教师 {plan.teacher.name} 在该时段已在班级 {conflicting_class.name} 有早晚自习安排!'})

    # 检查计划的课时数是否已满
    scheduled_count = SelfStudySchedule.query.filter_by(plan_id=plan.id, is_common_course=False).count()
    total_hours = plan.hours_per_week + (plan.extra_hours or 0)
    if scheduled_count >= total_hours:
        return jsonify({'success': False, 'message': f'{plan.subject.name} 的计划课时已满!'})

    # 创建早晚自习课表记录
    new_selfstudy_schedule = SelfStudySchedule(
        class_id=class_id,
        plan_id=plan.id, # 关联到 SelfStudyPlan
        day=day,
        period=period,
        is_common_course=False # 手动添加的是常规自习
    )
    db.session.add(new_selfstudy_schedule)
    db.session.commit()

    # 更新已排课时数
    current_scheduled_count = SelfStudySchedule.query.filter_by(plan_id=plan.id, is_common_course=False).count()

    return jsonify({
        'success': True,
        'message': '添加早晚自习成功!',
        'subject_name': plan.subject.name,
        'teacher_name': plan.teacher.name,
        'scheduled_count': current_scheduled_count,
        'total_hours': total_hours,
        'schedule_id': new_selfstudy_schedule.id # 返回新创建的记录ID，方便前端更新
    })

@selfstudy_bp.route('/remove_lesson', methods=['POST'])
@login_required
def remove_selfstudy_lesson():
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': '您没有权限进行此操作!'})

    class_id = request.form.get('class_id', type=int)
    day = request.form.get('day', type=int)
    period = request.form.get('period', type=str) # 早晚自习的period是字符串
    # schedule_id = request.form.get('schedule_id', type=int) # 也可以通过schedule_id删除

    if not all([class_id, day, period]):
        return jsonify({'success': False, 'message': '参数不完整!'})

    # 查找要删除的早晚自习记录
    # 只删除常规自习，不删除公共活动或禁排标志
    schedule_item = SelfStudySchedule.query.filter_by(
        class_id=class_id, 
        day=day, 
        period=period,
        is_common_course=False # 确保删除的是常规自习，而不是公共课程
    ).first()

    if not schedule_item:
        # 也可能该单元格是公共课程或禁排，不应通过此接口删除
        # 或者 simply not there
        existing_other = SelfStudySchedule.query.filter_by(class_id=class_id, day=day, period=period).first()
        if existing_other and existing_other.is_common_course:
            return jsonify({'success': False, 'message': '不能在此处删除公共活动，请在公共活动管理中操作!'})
        
        block = SelfStudyBlock.query.filter_by(class_id=class_id, day=day, period=period).first()
        if block:
            return jsonify({'success': False, 'message': '不能在此处删除禁排时段，请在禁排管理中操作!'})
            
        return jsonify({'success': False, 'message': '该时段没有可删除的早晚自习安排!'})
    
    plan_id = schedule_item.plan_id
    db.session.delete(schedule_item)
    db.session.commit()

    remaining_hours = 0
    total_hours = 0
    subject_name = ""
    if plan_id:
        plan = SelfStudyPlan.query.get(plan_id)
        if plan:
            subject_name = plan.subject.name
            scheduled_count = SelfStudySchedule.query.filter_by(plan_id=plan_id, is_common_course=False).count()
            total_hours = plan.hours_per_week + (plan.extra_hours or 0)
            remaining_hours = total_hours - scheduled_count
        
    return jsonify({
        'success': True, 
        'message': '删除早晚自习成功!',
        'plan_id': plan_id,
        'subject_name': subject_name,
        'remaining_hours': remaining_hours, # 剩余课时
        'total_hours': total_hours
    })

@selfstudy_bp.route('/calculate_available_selfstudy_slots', methods=['POST'])
@login_required
def calculate_available_selfstudy_slots():
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': '您没有权限进行此操作!'})

    class_id = request.form.get('class_id', type=int)
    plan_id = request.form.get('plan_id', type=int)

    if not all([class_id, plan_id]):
        return jsonify({'success': False, 'message': '参数不完整 (需要 class_id 和 plan_id)!'})

    plan = SelfStudyPlan.query.get_or_404(plan_id)
    if plan.class_id != class_id:
        return jsonify({'success': False, 'message': '授课计划与班级不匹配!'})

    # 检查计划课时是否已满
    scheduled_count = SelfStudySchedule.query.filter_by(plan_id=plan.id, is_common_course=False).count()
    total_hours_for_plan = plan.hours_per_week + (plan.extra_hours or 0)
    if scheduled_count >= total_hours_for_plan:
        return jsonify({
            'success': True, 
            'available_slots': [], 
            'plan_id': plan_id,
            'message': '该计划的课时已排满。'
        })

    available_slots = []
    valid_periods = ['早读1', '晚修1'] # 定义有效的早晚自习时段名称
    days_of_week = range(1, 8) # 周一到周日

    for day in days_of_week:
        for period_str in valid_periods:
            # 1. 班级自身占用检查
            existing_class_schedule = SelfStudySchedule.query.filter_by(
                class_id=class_id, day=day, period=period_str
            ).first()
            if existing_class_schedule:
                continue

            # 2. 班级禁排检查
            is_blocked = SelfStudyBlock.query.filter_by(
                class_id=class_id, day=day, period=period_str
            ).first()
            if is_blocked:
                continue

            # 3. 全校公共活动检查 (非本班设置的)
            common_all_classes_schedule = SelfStudySchedule.query.filter(
                SelfStudySchedule.day == day, 
                SelfStudySchedule.period == period_str, 
                SelfStudySchedule.is_common_course == True,
                SelfStudySchedule.apply_to_all_classes == True
            ).first()
            if common_all_classes_schedule:
                continue
            
            # 4. 教师冲突检查 (在其他班级的同一早晚自习时段)
            if plan.teacher_id:
                teacher_conflict = SelfStudySchedule.query.join(SelfStudyPlan, SelfStudySchedule.plan_id == SelfStudyPlan.id).filter(
                    SelfStudySchedule.day == day,
                    SelfStudySchedule.period == period_str,
                    SelfStudyPlan.teacher_id == plan.teacher_id,
                    SelfStudySchedule.class_id != class_id # 确保是其他班级
                ).first()
                if teacher_conflict:
                    continue
            
            available_slots.append({'day': day, 'period': period_str})

    return jsonify({
        'success': True, 
        'available_slots': available_slots,
        'plan_id': plan_id
    })

@selfstudy_bp.route('/swap_lesson', methods=['POST'])
@login_required
def swap_selfstudy_lesson():
    """交换/移动早晚自习课程"""
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': '您没有权限进行此操作!'})
    
    try:
        data = request.get_json()
        class_id = data.get('class_id')
        source_day = data.get('source_day')
        source_period = data.get('source_period')
        target_day = data.get('target_day')
        target_period = data.get('target_period')
        
        if not all([class_id, source_day, source_period, target_day, target_period]):
            return jsonify({'success': False, 'message': '参数不完整!'})
        
        # 转换为整数
        class_id = int(class_id)
        source_day = int(source_day)
        target_day = int(target_day)
        
        # 获取源单元格的课程信息
        source_schedule = SelfStudySchedule.query.filter_by(
            class_id=class_id,
            day=source_day,
            period=source_period,
            is_common_course=False  # 只交换常规课程
        ).first()
        
        if not source_schedule or not source_schedule.plan_id:
            return jsonify({'success': False, 'message': '源单元格没有有效的课程!'})
        
        # 获取目标单元格状态
        target_schedule = SelfStudySchedule.query.filter_by(
            class_id=class_id,
            day=target_day,
            period=target_period
        ).first()
        
        # 检查目标单元格是否被禁排
        is_blocked = SelfStudyBlock.query.filter_by(
            class_id=class_id,
            day=target_day,
            period=target_period
        ).first()
        
        if is_blocked:
            return jsonify({'success': False, 'message': '目标单元格已被禁排!'})
        
        # 检查目标单元格是否是公共课程
        if target_schedule and target_schedule.is_common_course:
            return jsonify({'success': False, 'message': '不能与公共课程交换!'})
        
        # 获取源课程的教师
        source_plan = SelfStudyPlan.query.get(source_schedule.plan_id)
        source_teacher_id = source_plan.teacher_id if source_plan else None
        
        # 获取目标课程的教师（如果有）
        target_teacher_id = None
        if target_schedule and target_schedule.plan_id:
            target_plan = SelfStudyPlan.query.get(target_schedule.plan_id)
            target_teacher_id = target_plan.teacher_id if target_plan else None
        
        # 检查教师冲突 - 源教师在目标时段是否已有其他课程
        if source_teacher_id:
            source_teacher_conflict = SelfStudySchedule.query.join(SelfStudyPlan).filter(
                SelfStudySchedule.day == target_day,
                SelfStudySchedule.period == target_period,
                SelfStudyPlan.teacher_id == source_teacher_id,
                SelfStudySchedule.class_id != class_id  # 排除当前班级
            ).first()
            
            if source_teacher_conflict:
                conflict_class = Class.query.get(source_teacher_conflict.class_id)
                class_name = conflict_class.name if conflict_class else "未知班级"
                return jsonify({
                    'success': False, 
                    'message': f'教师冲突: 源课程教师在目标时段已有其他班级（{class_name}）的课程安排!'
                })
        
        # 如果目标单元格有课程，还需检查目标教师在源时段是否有冲突
        if target_teacher_id:
            target_teacher_conflict = SelfStudySchedule.query.join(SelfStudyPlan).filter(
                SelfStudySchedule.day == source_day,
                SelfStudySchedule.period == source_period,
                SelfStudyPlan.teacher_id == target_teacher_id,
                SelfStudySchedule.class_id != class_id  # 排除当前班级
            ).first()
            
            if target_teacher_conflict:
                conflict_class = Class.query.get(target_teacher_conflict.class_id)
                class_name = conflict_class.name if conflict_class else "未知班级"
                return jsonify({
                    'success': False, 
                    'message': f'教师冲突: 目标课程教师在源时段已有其他班级（{class_name}）的课程安排!'
                })
        
        # 执行交换
        if target_schedule and target_schedule.plan_id:
            # 交换两个课程
            source_plan_id = source_schedule.plan_id
            target_plan_id = target_schedule.plan_id
            
            source_schedule.plan_id = target_plan_id
            target_schedule.plan_id = source_plan_id
        else:
            # 移动课程（目标单元格为空）
            if target_schedule:
                # 更新现有记录
                target_schedule.plan_id = source_schedule.plan_id
                target_schedule.is_common_course = False
                db.session.delete(source_schedule)
            else:
                # 创建新记录
                new_schedule = SelfStudySchedule(
                    class_id=class_id,
                    day=target_day,
                    period=target_period,
                    plan_id=source_schedule.plan_id,
                    is_common_course=False
                )
                db.session.add(new_schedule)
                db.session.delete(source_schedule)
        
        db.session.commit()
        
        # 获取更新后的课程信息用于返回
        source_info = {}
        target_info = {}
        
        # 更新源单元格信息
        updated_source = SelfStudySchedule.query.filter_by(
            class_id=class_id,
            day=source_day,
            period=source_period
        ).first()
        
        if updated_source and updated_source.plan_id:
            updated_source_plan = SelfStudyPlan.query.get(updated_source.plan_id)
            source_info = {
                'has_subject': True,
                'subject': updated_source_plan.subject.name if updated_source_plan and updated_source_plan.subject else None,
                'teacher': updated_source_plan.teacher.name if updated_source_plan and updated_source_plan.teacher else None
            }
        
        # 更新目标单元格信息
        updated_target = SelfStudySchedule.query.filter_by(
            class_id=class_id,
            day=target_day,
            period=target_period
        ).first()
        
        if updated_target and updated_target.plan_id:
            updated_target_plan = SelfStudyPlan.query.get(updated_target.plan_id)
            target_info = {
                'has_subject': True,
                'subject': updated_target_plan.subject.name if updated_target_plan and updated_target_plan.subject else None,
                'teacher': updated_target_plan.teacher.name if updated_target_plan and updated_target_plan.teacher else None
            }
        
        return jsonify({
            'success': True,
            'message': '课程交换成功!',
            'source': source_info,
            'target': target_info
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'课程交换失败: {str(e)}'})